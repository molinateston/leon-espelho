#!/usr/bin/env python3
"""Mede o tamanho dos turnos nas sessoes do Codex app-server (~/.codex/sessions/**.jsonl).

Uso: medir-tokens.py [dir_sessoes] [horas] [--json]

Sem --json imprime o painel legivel (mediana e p90 de entrada, cache, saida, raciocinio, mais o
credito estimado por turno). Com --json imprime UMA linha de numeros, que e o que a ponte manda
pra central junto do pulso de versao.

CREDITO ESTIMADO: entrada nova custa cheio, o que veio do cache custa 10 por cento da cota do
plano, a saida custa cheio. E a mesma conta que o /cota mostra no chat, pra o numero do dono
bater com o numero que a central recebe.

Le SO os campos de contagem do rollout. Nenhum texto de conversa e lido, contado ou impresso:
o que sai daqui e numero. Sem dependencia fora da stdlib, de proposito, porque o runtime do
cliente so leva os nativos.
"""
import json
import os
import statistics as st
import sys
import time


def coleta(root, horas):
    """Junta o last_token_usage de cada turno das sessoes tocadas na janela pedida."""
    corte = time.time() - horas * 3600
    turnos = []
    sessoes = 0
    for dirpath, _dirnames, filenames in os.walk(root):
        for nome in filenames:
            if not nome.endswith(".jsonl"):
                continue
            caminho = os.path.join(dirpath, nome)
            try:
                if os.path.getmtime(caminho) < corte:
                    continue
            except OSError:
                continue
            sessoes += 1
            try:
                arquivo = open(caminho, errors="ignore")
            except OSError:
                continue
            with arquivo:
                for linha in arquivo:
                    # Filtro barato antes do parse: a maioria das linhas do rollout e conversa,
                    # e desserializar todas custaria mais do que a medicao inteira.
                    if '"last_token_usage"' not in linha:
                        continue
                    try:
                        evento = json.loads(linha)
                    except ValueError:
                        continue
                    achado = _acha_uso(evento)
                    if achado:
                        turnos.append(achado)
    return turnos, sessoes


def _acha_uso(evento):
    """Acha o last_token_usage em qualquer profundidade, sem saber o formato do evento."""
    pilha = [evento]
    while pilha:
        atual = pilha.pop()
        if isinstance(atual, dict):
            if "last_token_usage" in atual:
                uso = atual["last_token_usage"]
                return uso if isinstance(uso, dict) else None
            pilha.extend(atual.values())
        elif isinstance(atual, list):
            pilha.extend(atual)
    return None


def p90(valores):
    if not valores:
        return 0
    ordenado = sorted(valores)
    return ordenado[min(len(ordenado) - 1, int(len(ordenado) * 0.9))]


def resumo(turnos, sessoes, horas):
    def coluna(chave):
        return [int(t.get(chave) or 0) for t in turnos]

    entrada = coluna("input_tokens")
    cache = coluna("cached_input_tokens")
    saida = coluna("output_tokens")
    raciocinio = coluna("reasoning_output_tokens")
    credito = [round((i - c) + 0.1 * c + o) for i, c, o in zip(entrada, cache, saida)]
    return {
        "turnos_7d": len(turnos),
        "sessoes": sessoes,
        "janela_horas": round(horas),
        "tokens_turno_mediana": round(st.median(entrada)),
        "tokens_turno_p90": round(p90(entrada)),
        "cache_mediana": round(st.median(cache)),
        "saida_mediana": round(st.median(saida)),
        "raciocinio_mediana": round(st.median(raciocinio)),
        "credito_mediana": round(st.median(credito)),
        "credito_p90": round(p90(credito)),
    }


def main(argv):
    args = [a for a in argv[1:] if a != "--json"]
    saida_json = "--json" in argv[1:]
    root = args[0] if len(args) > 0 else os.path.expanduser("~/.codex/sessions")
    horas = float(args[1]) if len(args) > 1 else 168.0

    turnos, sessoes = coleta(root, horas)
    if not turnos:
        # Casa nova ou sem turno na janela nao e erro: a ponte le o vazio e simplesmente nao
        # manda o campo no pulso. Sair com codigo 1 aqui encheria o log de falha inventada.
        if saida_json:
            print(json.dumps({"turnos_7d": 0}))
        else:
            print("sem contagem de token nas sessoes da janela")
        return 0

    r = resumo(turnos, sessoes, horas)
    if saida_json:
        print(json.dumps(r))
        return 0

    print(f"turnos {r['turnos_7d']} | sessoes {r['sessoes']} | janela {r['janela_horas']}h")
    print(f"entrada     mediana {r['tokens_turno_mediana']:>9}  p90 {r['tokens_turno_p90']:>9}")
    print(f"cache       mediana {r['cache_mediana']:>9}")
    print(f"saida       mediana {r['saida_mediana']:>9}  raciocinio mediana {r['raciocinio_mediana']}")
    print(f"credito/turno estimado  mediana {r['credito_mediana']:>9}  p90 {r['credito_p90']:>9}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
