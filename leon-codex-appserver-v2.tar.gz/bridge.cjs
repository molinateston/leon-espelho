'use strict';
// LEON 2.0, release 2.7.4: porta de entrada. O código mora em leon2/, igual ao do dono.
require('./leon2/leon.cjs');
