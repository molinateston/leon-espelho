'use strict';
// lib-motores/provedor-api.cjs — O ADAPTADOR UNICO DE MOTOR POR API (A1/A3, 21/09/2026).
//
// O QUE ISTO SUBSTITUI. Ate hoje cada provedor OpenAI-compatible virava um arquivo
// copiado (lib-motores/deepseek.cjs), com base_url, wire_api e nome da chave cravados
// no codigo. Motor novo pedia arquivo novo, e as tres listas da casa (MOTORES_CONHECIDOS,
// LEAF_ALLOWED_SECRET_ENV e o teclado do /motor) precisavam ser editadas a mao, uma a uma.
// Agora o provedor e UMA LINHA de config/provedores.json e este arquivo e o unico adaptador:
// o DeepSeek passou a ser uma linha da tabela como qualquer outro.
//
// POR QUE O CHASSI CONTINUA O CODEX. O protocolo do app-server do Codex CLI e quem ja e dono
// de ferramentas, sessao, dossie incremental, permissoes, cancelamento e eventos. Trocar de
// provedor e so trocar quem atende a inferencia; reescrever o chassi seria jogar fora tudo
// isso. E o mesmo padrao que o gateway de referência documenta no perfil custom de provedor
// (model_provider + [model_providers.<id>] com name/base_url/wire_api/env_key).
//
// A3 — CASA PROPRIA, E POR QUE ISSO CONSERTA O DEFEITO NA RAIZ. O deepseek.cjs herdava o
// CODEX_HOME do DONO e mandava --strict-config. Qualquer campo que o CLI da casa nao
// conhecesse no ~/.codex/config.toml do dono (foi o caso do preferred_auth_method em 21/09)
// derrubava o motor inteiro, e o conserto virava "comenta a linha no config do dono" — uma
// casa mexendo no arquivo da outra. Aqui cada motor por API ganha um CODEX_HOME PROPRIO,
// com um config.toml MINIMO gerado por nos, que so declara o provedor. O config do dono
// deixa de estar no caminho: --strict-config passa a validar so o que nos escrevemos.
// Kill-switch LEON_PROVEDOR_CASA_PROPRIA=0 volta a herdar o home do dono (comportamento de
// hoje) pra uma casa que precise do config dela por algum motivo.

const fs = require('node:fs');
const path = require('node:path');

const codexAppServer = require('./codex-appserver.cjs');
const { linhasTomlSaida } = require('./saida-ferramenta.cjs');
const { linhaDoProvedor, provedores } = require('./provedores-tabela.cjs');

const JEV_MCP_SERVER = path.resolve(__dirname, '..', 'lib', 'jev', 'mcp-server.cjs');

// ===== A5 · O JEV SO ENTRA EM PEDIDO DE TRABALHO QUE CITE NAVEGADOR (22/09) =====
// O MCP do jev e declarado nos args do app-server (providerArgs), ou seja, no NASCIMENTO do
// processo: o adaptador e um so por motor e vive entre turnos, entao nao da pra tirar a
// declaracao por turno sem respawn. O que E por turno e a configuracao da THREAD (o mesmo
// lugar onde o chassi ja desliga MCP inteiro pra folha, codex-appserver.cjs:958
// `mcp_servers: {}` em threadConfigFor). Entao a porta aqui e a config da thread: um overlay
// que desliga o servidor jev no turno que nao pede navegador.
//
// POR QUE ISSO E ENVELOPE, E NAO SO CAPACIDADE: o schema da tool viaja no prompt do turno. Num
// "ok" de conversa o jev_browser_run e token pago por uma ferramenta que o turno nunca vai
// chamar — exatamente o corte que o gateway de referência faz pelo promptMode (system-prompt.ts:1022) e a
// Skin fazia pelo SYS_MAX.
//
// A REGUA, em duas condicoes que somam: (1) o turno e de TRABALHO (classe do gate: nem leve nem
// conversa) E (2) a fala cita navegador/site/pagina. Conversa que cita site nao abre navegador;
// trabalho que nao cita, tambem nao. Sem classe plumbada (chamador antigo) o turno conta como
// trabalho, e a citacao sozinha decide: fail-safe pro lado de manter a ferramenta.
const JEV_RE = /\b(?:navegador|browser|chrome|chromium|playwright|site|website|sites|p[aá]gina|paginas|p[aá]ginas|url|link|links|landing|dom[ií]nio|web|internet|screenshot|print\s+da\s+tela|formul[aá]rio|abrir?\s+o\s+site|acess[ae]r?\s+o\s+site)\b/i;
function pedidoCitaNavegador(texto) {
  return JEV_RE.test(String(texto || ''));
}
function jevNesteTurno(entrada) {
  const classe = String((entrada && entrada.classe) || '').toLowerCase().trim();
  const ehTrabalho = !(classe === 'leve' || classe === 'conversa');
  if (!ehTrabalho) return false;
  return pedidoCitaNavegador((entrada && entrada.falaDono) || '');
}

// O contrato de capacidades e o do chassi Codex, menos o effort: nenhuma destas APIs
// publica uma regua compativel com o reasoning effort do Codex, e mandar um valor de
// outro provedor seria inventar. O declarado e o que a casa cumpre.
const capacidades = Object.freeze({
  ...codexAppServer.capacidades,
  effort: false,
  jevBrowser: true,
});

function createMotor(options = {}) {
  const source = options.envSource || process.env;
  const nome = String(options.nome || options.nomeMotor || '').toLowerCase().trim();
  const linha = linhaDoProvedor(nome);
  if (!linha) throw new Error(`provedor "${nome}" nao existe em config/provedores.json`);

  const credentialFile = resolveCredentialFile(linha, options, source);
  const credential = readCredential(linha, credentialFile);
  const envSource = {
    ...source,
    [linha.variavel_chave]: credential.ok ? credential.value : '',
  };

  // A3: casa propria do motor. O home nasce ao lado do stateDir que o bridge ja passa
  // (homeDoMotor), mas com config MINIMO nosso — o do dono nunca e lido.
  const casaPropria = casaPropriaLigada(source);
  const codexHome = casaPropria ? resolveCasaDoProvedor(linha, options, source) : null;
  if (codexHome) escreveConfigMinimo(codexHome, linha, source);

  const adapterOptions = {
    ...(options.adapterOptions || {}),
    args: providerArgs(linha, options.adapterOptions && options.adapterOptions.args),
  };
  const threadConfig = configDeThread(linha, options.threadConfig);
  const allowedSecretEnv = [...new Set([
    ...(Array.isArray(options.allowedSecretEnv) ? options.allowedSecretEnv.map(String) : []),
    linha.variavel_chave,
  ])];

  const base = codexAppServer.createMotor({
    ...options,
    nomeMotor: nome,
    rotuloMotor: linha.rotulo,
    envSource,
    adapterOptions,
    threadConfig,
    allowedSecretEnv,
    // Com casa propria, o app-server nasce apontado pro NOSSO home: o sourceCodexHome do
    // chassi passa a ser o do provedor, nao o do dono.
    ...(codexHome ? { sourceCodexHome: codexHome } : {}),
  });

  async function responder(entrada = {}) {
    if (!credential.ok) {
      return {
        texto: '',
        custoUSD: null,
        sessaoId: entrada.sessaoId || null,
        erro: credential.error,
        cota: false,
        ctxTokens: null,
        uso: null,
      };
    }
    // A5 (22/09): o jev entra por turno. Desligado, a thread recebe o overlay
    // `mcp_servers.jev.enabled=false` — a MESMA porta que o chassi usa pra folha — e o schema da
    // tool nao viaja no prompt. Kill-switch LEON_API_ENVELOPE_MAGRO=0 devolve o jev a todo turno.
    const _jevLigado = !envelopeMagroLigado(source) || jevNesteTurno(entrada);
    const _threadConfigDoTurno = _jevLigado ? undefined : {
      ...threadConfig,
      mcp_servers: {
        ...(threadConfig && threadConfig.mcp_servers ? threadConfig.mcp_servers : {}),
        jev: { enabled: false },
      },
    };
    const out = await base.responder({
      ...entrada,
      modelo: String(entrada.modelo || linha.modelo_padrao),
      // effort:false no contrato: nao mandamos valor de outro provedor.
      effort: undefined,
      ...(_threadConfigDoTurno ? { threadConfig: _threadConfigDoTurno } : {}),
    });
    if (out && typeof out.erro === 'string') {
      return { ...out, erro: out.erro.replace(/\bno Codex\b/g, `no motor ${linha.rotulo}`) };
    }
    return out;
  }

  // sondar()/listarModelos(): e assim que o /motor TESTA A CHAVE na hora (A4). Sem isso o
  // dono so descobre que a chave esta errada quando o turno morre no meio da conversa.
  async function listarModelos(opts = {}) {
    if (!credential.ok) return null;
    const timeoutMs = positiveInt(opts.timeoutMs, 15_000);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    timer.unref?.();
    try {
      const response = await fetch(`${linha.base_url.replace(/\/+$/, '')}/models`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${credential.value}` },
        signal: controller.signal,
      });
      if (!response.ok) return null;
      const body = await response.json();
      const ids = Array.isArray(body && body.data)
        ? body.data.map((item) => String((item && item.id) || '')).filter(idDeModeloValido)
        : [];
      return [...new Set(ids)].map((id) => ({
        id,
        displayName: id,
        description: `Modelo disponivel na conta ${linha.rotulo}`,
        hidden: false,
        supportedReasoningEfforts: [],
      }));
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }

  async function sondar(opts = {}) {
    const modelos = await listarModelos(opts);
    return Array.isArray(modelos) && modelos.length > 0;
  }

  return {
    nome,
    rotulo: linha.rotulo,
    bin: base.bin,
    capacidades,
    disponivel() { return credential.ok && base.disponivel(); },
    responder,
    resetar: (...args) => base.resetar(...args),
    encerrar: (...args) => base.encerrar(...args),
    listarModelos,
    sondar,
    proximoModelo(atual) { return proximoModelo(linha, atual); },
    turnosAtivos: (...args) => base.turnosAtivos(...args),
    turnoVivo: (...args) => base.turnoVivo(...args),
    _adapter: (...args) => base._adapter(...args),
    _leafAdapter: (...args) => base._leafAdapter(...args),
    _casaPropria: codexHome,
  };
}

// A flag do envelope magro (A5). Nasce LIGADA (ausente = "1"), como no bridge: este arquivo so
// existe pra motor pago por token, onde o envelope gordo e fatura, nao assinatura.
function envelopeMagroLigado(envSource) {
  return String((envSource && envSource.LEON_API_ENVELOPE_MAGRO) || '1').trim() !== '0';
}

function casaPropriaLigada(envSource) {
  return String((envSource && envSource.LEON_PROVEDOR_CASA_PROPRIA) || '1').trim() !== '0';
}

// A casa do provedor e uma pasta NOSSA, nunca o ~/.codex do dono. Ordem: o que o bridge
// passou (stateDir, que ja e homeDoMotor(nome)), depois LEON_DATA_DIR/<motor>, depois uma
// pasta irma do home do dono. O nome carrega o provedor pra duas casas nunca colidirem.
function resolveCasaDoProvedor(linha, options, envSource) {
  if (options.codexHome) return path.resolve(String(options.codexHome));
  if (options.stateDir) return path.resolve(String(options.stateDir));
  const dados = envSource.LEON_DATA_DIR;
  if (dados) return path.resolve(String(dados), linha.nome);
  const dono = envSource.LEON_CODEX_HOME || envSource.CODEX_HOME
    || path.join(envSource.HOME || require('node:os').homedir(), '.codex');
  const raiz = path.resolve(String(dono));
  return path.join(path.dirname(raiz), `${path.basename(raiz)}-${linha.nome}`);
}

// CONFIG MINIMO (A3). So o que o provedor precisa, e so o que nos escrevemos — por isso o
// --strict-config passa. Reescrevemos a cada boot de proposito: a tabela e a fonte unica, e
// uma edicao a mao neste arquivo seria uma configuracao fantasma que ninguem sabe que existe.
// 23/09: com LEON_SAIDA_FERRAMENTA_TOKENS ligada entra tool_output_token_limit (chave de topo,
// antes da tabela do provedor), o mesmo numero do `-c` do nascimento; desligada, o arquivo sai
// byte a byte igual ao de antes.
function escreveConfigMinimo(codexHome, linha, envSource = {}) {
  try {
    fs.mkdirSync(codexHome, { recursive: true, mode: 0o700 });
    try { fs.chmodSync(codexHome, 0o700); } catch {}
    const alvo = path.join(codexHome, 'config.toml');
    const texto = [
      '# GERADO PELO LEON (lib-motores/provedor-api.cjs). NAO EDITE A MAO:',
      '# este arquivo e reescrito a cada boot a partir de config/provedores.json.',
      `model_provider = ${JSON.stringify(linha.nome)}`,
      `model = ${JSON.stringify(linha.modelo_padrao)}`,
      ...linhasTomlSaida(envSource),
      '',
      `[model_providers.${linha.nome}]`,
      `name = ${JSON.stringify(linha.rotulo)}`,
      `base_url = ${JSON.stringify(linha.base_url)}`,
      `env_key = ${JSON.stringify(linha.variavel_chave)}`,
      `wire_api = ${JSON.stringify(linha.wire_api)}`,
      'request_max_retries = 2',
      'stream_max_retries = 2',
      'stream_idle_timeout_ms = 120000',
      '',
    ].join('\n');
    const tmp = `${alvo}.tmp`;
    fs.writeFileSync(tmp, texto, { mode: 0o600 });
    fs.renameSync(tmp, alvo);
    return alvo;
  } catch {
    // Casa sem permissao de escrita nao pode derrubar o boot: o motor ainda sobe com os
    // args -c abaixo, que dizem a mesma coisa por outro caminho.
    return null;
  }
}

// Onde a chave mora. NUNCA no .env do programa e nunca na tabela: arquivo proprio, modo 600.
function resolveCredentialFile(linha, options, envSource) {
  if (options.credentialFile) return path.resolve(String(options.credentialFile));
  const chaveEnv = linha.env_arquivo_credencial;
  if (chaveEnv && envSource[chaveEnv]) return path.resolve(String(envSource[chaveEnv]));
  // 21/09: NENHUM caminho de casa cravado. O default vinha copiado do adaptador antigo
  // com a casa de um usuario NOMEADO dentro dele, e so valia na maquina de quem escreveu:
  // numa casa de cliente (usuario dedicado, HOME proprio) o motor procurava a chave na
  // pasta de outro dono e aparecia como "credencial ausente no cofre", sem dizer por que.
  // O padrao passa a derivar do HOME do processo — mesmo caminho relativo (<home>/trabalho),
  // so que agora ele acerta em qualquer casa. LEON_WORK_AREA continua mandando quando
  // definida. A auditoria de vazamento do pacote recusa casa nomeada aqui, e com razao.
  const home = envSource.HOME || require('node:os').homedir();
  const workArea = envSource.LEON_WORK_AREA || path.join(home, 'trabalho');
  return path.resolve(workArea, linha.credencial);
}

function readCredential(linha, file) {
  const rotulo = linha.rotulo;
  let stat;
  try { stat = fs.statSync(file); }
  catch { return { ok: false, value: null, error: `credencial ${rotulo} ausente no cofre` }; }
  if (!stat.isFile()) return { ok: false, value: null, error: `credencial ${rotulo} invalida no cofre` };
  // Modo 600 e exigencia, nao recomendacao: chave de API legivel por outro usuario da maquina
  // e chave vazada. Recusar aqui e melhor que descobrir depois.
  if ((stat.mode & 0o077) !== 0) {
    return { ok: false, value: null, error: `credencial ${rotulo} com permissao insegura; esperado modo 600` };
  }
  let text;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch { return { ok: false, value: null, error: `credencial ${rotulo} sem leitura no cofre` }; }
  const re = new RegExp(`^\\s*${escapaRegex(linha.variavel_chave)}\\s*=\\s*(.+?)\\s*$`, 'm');
  const match = text.match(re);
  const value = match ? semAspas(match[1]) : '';
  if (!value) return { ok: false, value: null, error: `${linha.variavel_chave} ausente no cofre` };
  return { ok: true, value, error: null };
}

function escapaRegex(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function semAspas(value) {
  const text = String(value || '').trim();
  if (text.length >= 2 && ((text.startsWith('"') && text.endsWith('"'))
      || (text.startsWith("'") && text.endsWith("'")))) {
    return text.slice(1, -1);
  }
  return text;
}

// Os args -c continuam saindo daqui mesmo com a casa propria: eles sao a fonte que o
// app-server le em ultima instancia, e valem tambem quando a escrita do config falha.
function providerArgs(linha, existing) {
  const base = Array.isArray(existing) && existing.length ? existing.map(String) : ['app-server'];
  const perfil = [
    `name="${linha.rotulo}"`,
    `base_url="${linha.base_url}"`,
    `env_key="${linha.variavel_chave}"`,
    `wire_api="${linha.wire_api}"`,
    'request_max_retries=2',
    'stream_max_retries=2',
    'stream_idle_timeout_ms=120000',
  ].join(',');
  return [
    ...base,
    '--strict-config',
    '-c', `model_provider="${linha.nome}"`,
    '-c', `model_providers.${linha.nome}={${perfil}}`,
    '-c', `mcp_servers.jev={command=${JSON.stringify(process.execPath)},args=[${JSON.stringify(JEV_MCP_SERVER)}],enabled=true,enabled_tools=["jev_browser_run"],default_tools_approval_mode="prompt",startup_timeout_sec=10,tool_timeout_sec=180}`,
  ];
}

// A chave nunca entra no ambiente do shell que as tools rodam: a inferencia usa a chave, o
// comando que o agente dispara nao precisa dela. Os curingas cobrem o proximo provedor sem
// alguem lembrar de vir aqui.
function configDeThread(linha, existing) {
  const base = existing && typeof existing === 'object' ? existing : {};
  const oldPolicy = base.shell_environment_policy && typeof base.shell_environment_policy === 'object'
    ? base.shell_environment_policy : {};
  const oldFilters = oldPolicy.filters && typeof oldPolicy.filters === 'object'
    ? oldPolicy.filters : {};
  return {
    ...base,
    shell_environment_policy: {
      ...oldPolicy,
      inherit: oldPolicy.inherit || 'core',
      ignore_default_excludes: false,
      filters: {
        ...oldFilters,
        [linha.variavel_chave]: 'exclude',
        '*KEY*': 'exclude',
        '*TOKEN*': 'exclude',
        '*SECRET*': 'exclude',
        '*PASSWORD*': 'exclude',
        '*CREDENTIAL*': 'exclude',
        '*AUTH*': 'exclude',
      },
    },
  };
}

function idDeModeloValido(value) {
  return /^[a-z0-9][a-z0-9._\-\/]+$/i.test(String(value || ''));
}

function proximoModelo(linha, atual) {
  const lista = linha.modelos;
  const index = lista.indexOf(String(atual || ''));
  if (index < 0) return lista[0] || null;
  return lista[index + 1] || null;
}

function positiveInt(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback;
}

module.exports = {
  createMotor,
  capacidades,
  provedores,
  JEV_MCP_SERVER,
  _readCredential: readCredential,
  _resolveCredentialFile: resolveCredentialFile,
  _resolveCasaDoProvedor: resolveCasaDoProvedor,
  _escreveConfigMinimo: escreveConfigMinimo,
  _providerArgs: providerArgs,
  _configDeThread: configDeThread,
  _proximoModelo: proximoModelo,
  _casaPropriaLigada: casaPropriaLigada,
  _envelopeMagroLigado: envelopeMagroLigado,
  _jevNesteTurno: jevNesteTurno,
  _pedidoCitaNavegador: pedidoCitaNavegador,
};
