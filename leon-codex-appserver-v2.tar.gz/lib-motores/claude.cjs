'use strict';
// lib-motores/claude.cjs — o segundo motor da casa.
//
// CONTRATO: expõe EXATAMENTE a mesma interface de lib-motores/codex-appserver.cjs
// (nome, bin, capacidades, disponivel, responder, resetar, encerrar, turnosAtivos,
// _adapter), pra que o bridge troque de motor sem trocar uma linha de encanamento.
// A entrada de responder() é a mesma ({ sessaoId, dossie, fala, contexto, modelo,
// effort, cwd, diretorios, timeoutMs, onEvento, ... }) e a saída é o mesmo shape
// padronizado ({ texto, custoUSD, sessaoId, erro, cota, ctxTokens }).
//
// A máquina por baixo é outra: aqui não há app-server nem thread nativa. O turno é um
// spawn do CLI com --output-format stream-json. O nome da sessão é IMPOSTO pelo bridge
// (--session-id <uuid> na primeira fala) e reaproveitado por --resume depois, sempre
// conferindo antes que o transcript daquela sessão existe no ~/.claude da casa. Quem
// chama nunca precisa saber disso: o sessaoId é opaco pro bridge nos dois motores.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { randomUUID } = require('node:crypto');

const SEP_FALA = '===== FALA DO DONO =====';
const DEFAULT_TIMEOUT_MS = numberFromEnv('CLAUDE_TIMEOUT_SEG', 600) * 1_000;
const WORKER_LEAF_ALLOWED_TOOLS = Object.freeze([
  'Read', 'Write', 'Edit', 'Glob', 'Grep', 'LS', 'NotebookEdit',
]);
const WORKER_LEAF_WEB_TOOLS = Object.freeze(['WebSearch', 'WebFetch']);
const WORKER_CAPABILITIES = Object.freeze(['web_search', 'image_generation']);
const WORKER_LEAF_DENIED_TOOLS = Object.freeze([
  'Bash', 'SendMessage', 'Task', 'TaskOutput', 'Skill', 'Agent', 'TeamCreate', 'TeamDelete',
]);
const PLANNER_LEAF_DENIED_TOOLS = Object.freeze([
  'Write', 'Edit', 'NotebookEdit', 'Bash', 'WebFetch', 'WebSearch',
  'SendMessage', 'Task', 'TaskOutput', 'Skill',
]);
const REVIEWER_LEAF_ALLOWED_TOOLS = Object.freeze(['Read', 'Glob', 'Grep', 'LS']);
const REVIEWER_LEAF_DENIED_TOOLS = Object.freeze([
  'Write', 'Edit', 'NotebookEdit', 'Bash', 'WebFetch', 'WebSearch',
  'SendMessage', 'Task', 'TaskOutput', 'Skill',
]);
const COORDINATOR_HEAD_DENIED_TOOLS = Object.freeze([
  'Read', 'Write', 'Edit', 'Glob', 'Grep', 'LS', 'NotebookEdit', 'Bash',
  'WebFetch', 'WebSearch', 'SendMessage', 'Task', 'TaskOutput', 'Skill',
  'Agent', 'TeamCreate', 'TeamDelete',
]);

// BUG-02 · KILL-SWITCH da leitura estruturada de limite do Claude. 1 (default) liga o
// ramo `rate_limit_event` e os campos limiteAte/limiteTipo/limiteStatus na saída; 0
// volta ao booleano `cota` puro por regex de texto, como antes deste bug. Também mora
// nas duas allowlists NÚCLEO (lib/integracoes.cjs) pra não derrubar o .env. Lido a cada
// turno (não cacheado no boot) pra o teste virar a chave sem reiniciar o motor.
function claudeLimiteLer() {
  return String(process.env.CLAUDE_LIMITE_LER ?? '1').trim() !== '0';
}

// O dossiê NUNCA viaja por argumento. Vai por --append-system-prompt-file, num arquivo
// 0600 no state dir da casa: some o teto de ~128KB do MAX_ARG_STRLEN (que obrigava a
// cortar o dossiê pelo meio), some o risco de E2BIG no spawn e o dossiê do dono chega
// inteiro. O arquivo é apagado no fim do turno, dê certo ou dê errado.
const DOSSIE_PREFIXO = 'leon-dossie-';

const capacidades = Object.freeze({
  promptSistemaSeparado: true,   // --append-system-prompt-file
  dossieIncremental: false,      // o CLI recebe um arquivo de sistema integral por turno
  retomaSessao: true,            // --session-id imposto + --resume
  tetoCustoNativo: true,         // --max-budget-usd
  reportaCusto: true,            // total_cost_usd no evento result
  saidaEstruturada: true,        // --output-format stream-json
  controlePermissao: true,       // --permission-mode
  modeloSelecionavel: true,      // --model
  effort: true,                  // --effort
  diretoriosExtras: true,        // --add-dir
  // ORQUESTRA (5-C): o CLI do Claude restringe a caixa de ferramentas por turno
  // com --allowedTools / --disallowedTools. É o que faz o envelope do subagente
  // MORDER: pedir uma ferramenta fora da lista não roda. Sem esta capacidade o
  // gate fail-closed recusa subir o subagente neste motor.
  restringeFerramentas: true,    // --allowedTools / --disallowedTools
  compactacaoNativa: true,       // o CLI compacta a própria janela
  // Aqui o corte MATA O PROCESSO do turno (killTree no process group). Nao existe
  // `turn/interrupt`: a sessao que estava sendo escrita fica pela metade, e retomar por
  // --resume nela reabre um transcript truncado. Por isso o /para DESCARTA o sid neste
  // motor, preservando o resumo — a conversa continua pelo priorSummary, nao pelo id.
  cancelaPreservandoSessao: false,
});

// CATÁLOGO DE MODELOS DA CASA CLAUDE (2.4.42). O CLI do Claude não expõe um RPC `model/list`
// como o app-server do Codex, então o catálogo aqui é a lista curada dos modelos que a conta
// oferece — os MESMOS ids da escada de lib-motores/index.cjs (MODELOS_POR_MOTOR.claude), sem
// inventar nome novo. listarModelos() abaixo devolve isto no shape cru que o seletor do bridge
// já sabe normalizar ({id, displayName, description}); assim o /modelo numa casa Claude reporta
// `fonte:"motor"` em vez de cair na escada estática, e o dono nunca vê nome de outro motor.
const MODELOS_CLAUDE = Object.freeze([
  Object.freeze({ id: 'claude-opus-4-8', displayName: 'Claude Opus 4.8', description: 'O mais forte — raciocínio e trabalho complexo.' }),
  Object.freeze({ id: 'claude-sonnet-5', displayName: 'Claude Sonnet 5', description: 'Rápido e econômico — o trabalho do dia a dia.' }),
]);

// Hooks de processo. Sem injeção vale o comportamento local; o bridge injeta os dele
// (trackKid/killTree) no boot pra que nenhum turno deste motor deixe órfão num restart.
let _trackKid = (proc) => proc;
let _killTree = (proc, signal) => {
  try { process.kill(-proc.pid, signal); } catch {}
  try { proc.kill(signal); } catch {}
};

function setHooks(hooks) {
  if (hooks && typeof hooks.trackKid === 'function') _trackKid = hooks.trackKid;
  if (hooks && typeof hooks.killTree === 'function') _killTree = hooks.killTree;
}

function createMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const command = options.command || resolveClaudeBin(envSource);
  // Turnos vivos por sessão: o mesmo mapa que o codex-appserver mantém, pra que
  // turnosAtivos() e encerrar(sessaoId) respondam igual nos dois motores.
  const activeTurns = new Map();
  const sessionLocks = new Map();
  // Onde mora a casa deste motor: o transcript da sessão e o arquivo do dossiê. O bridge
  // passa o state dir; sem ele vale o ~/.claude do próprio usuário do serviço.
  const stateDir = resolveStateDir(options, envSource);

  // O bridge manda o sessaoId que ele guardou. Aqui decidimos, ANTES de subir processo,
  // se aquela sessão ainda existe de verdade no disco:
  //   - sessão pedida com transcript no disco  -> --resume <id>, a conversa continua;
  //   - sessão pedida sem transcript no disco  -> nome NOVO imposto, sessão nova em silêncio
  //     nenhum: o motivo sai no log e o bridge semeia a conversa pelo banco;
  //   - sem sessão pedida                      -> nome NOVO imposto.
  // Impor o nome apaga a janela em que o turno existia sem sessão conhecida: o id já vale
  // desde a primeira linha do stream, então encerrar() e turnosAtivos() enxergam sempre.
  function decideSessao(entrada) {
    const pedida = stringOrNull(entrada.sessaoId);
    if (!pedida) return { sessaoId: randomUUID(), retomando: false, motivo: 'sessao-nova' };
    if (!transcriptExiste(stateDir, pedida)) {
      const nova = randomUUID();
      try {
        console.log(`[motor claude] sessão ${pedida} sem transcript no disco (motivo=transcript-ausente); abrindo ${nova}`);
      } catch {}
      return { sessaoId: nova, retomando: false, motivo: 'transcript-ausente' };
    }
    return { sessaoId: pedida, retomando: true, motivo: null };
  }

  async function responder(entrada = {}) {
    if (entrada.plannerLeaf === true && stringOrNull(entrada.sessaoId)) {
      return output({ erro: 'planner leaf nao retoma sessao persistente: turno recusado por seguranca' });
    }
    const plano = decideSessao(entrada);
    return withLock(sessionLocks, `session:${plano.sessaoId}`, () => rodaTurno(entrada, plano));
  }

  function rodaTurno(entrada, plano) {
    const sessaoDoTurno = plano.sessaoId;
    return new Promise((resolve) => {
      if (!claudeDisponivel(envSource, command)) {
        return resolve(output({ erro: `binário do motor ausente em ${command}`, sessaoId: sessaoDoTurno }));
      }
      const cwd = effectiveCwd(entrada, envSource);
      // O dossiê vira arquivo 0600 ANTES do spawn. Falha aqui é falha do turno: melhor
      // dizer que não deu do que rodar o motor sem a doutrina do dono.
      let dossiePF = null;
      let args;
      try {
        dossiePF = gravaDossie(stateDir, entrada.dossie, options);
        args = montaArgs(entrada, plano, cwd, dossiePF);
      } catch (error) {
        apagaDossie(dossiePF);
        return resolve(output({ erro: `preparação do turno falhou: ${error.message}`, sessaoId: sessaoDoTurno }));
      }

      const spawnFn = typeof options.spawnFn === 'function' ? options.spawnFn : spawn;
      let proc;
      try {
        // detached: a cabeça e os braços dela viram UM process group, então o
        // killTree(-pgid) do bridge não deixa neto órfão queimando cota.
        // M1 (porte do mestre L6920): assinatura de origem no env de TODO filho de turno.
        // entrada.origem = {LEON_ORIGEM_CHAT, LEON_ORIGEM_THREAD, LEON_ORIGEM_T0} (ou vazio).
        // Spread por cima do options.env sem mutar o objeto de options do chamador.
        const coordinatorHead = entrada && entrada.coordinatorHead === true;
        const _origem = !coordinatorHead && entrada && entrada.origem && typeof entrada.origem === 'object'
          ? entrada.origem : {};
        const _optsComOrigem = Object.keys(_origem).length
          ? { ...options, env: { ...(options && options.env), ..._origem } }
          : options;
        proc = _trackKid(spawnFn(command, args, {
          cwd,
          // A cabeça coordenadora não ganha variáveis arbitrárias do bridge.
          // O token OAuth/API estritamente necessário ao próprio CLI ainda
          // vem da allowlist fixa de childEnv, mas nenhuma ferramenta existe
          // para expô-lo ou usá-lo fora do motor.
          env: childEnv(envSource, coordinatorHead ? null : _optsComOrigem),
          detached: true,
          stdio: ['pipe', 'pipe', 'pipe'],
        }));
      } catch (error) {
        apagaDossie(dossiePF);
        return resolve(output({ erro: error.message || 'não consegui rodar o motor', sessaoId: sessaoDoTurno }));
      }

      // A interrupcao so termina quando o SO confirma `close`. SIGTERM apenas
      // solicita a parada; remover o turno do mapa antes desse evento fazia o
      // scheduler acreditar que havia uma vaga enquanto o CLI (e possiveis
      // descendentes) ainda podiam continuar trabalhando. SIGKILL e a segunda
      // etapa, nao uma confirmacao inventada.
      let closeResolve;
      let closeObserved = false;
      let killTimer = null;
      const closePromise = new Promise((resolveClose) => { closeResolve = resolveClose; });
      const confirmaClose = () => {
        if (closeObserved) return;
        closeObserved = true;
        if (killTimer) clearTimeout(killTimer);
        closeResolve(true);
      };
      proc.once('close', confirmaClose);
      const handle = {
        proc,
        sessaoId: sessaoDoTurno,
        get closed() { return closeObserved; },
        interrupt() {
          if (closeObserved) return closePromise;
          try { _killTree(proc, 'SIGTERM'); } catch {}
          if (!killTimer) {
            killTimer = setTimeout(() => { try { _killTree(proc, 'SIGKILL'); } catch {} }, 5_000);
            if (killTimer.unref) killTimer.unref();
          }
          return closePromise;
        },
      };
      activeTurns.set(sessaoDoTurno, handle);
      // Mesmo contrato do Codex: só anuncia a SID depois que existe processo
      // real no mapa de turnos ativos. O bridge usa isso apenas como prova de
      // vida; não muda retomada nem conteúdo da sessão.
      if (typeof entrada.onSessao === 'function') {
        try { entrada.onSessao(sessaoDoTurno); } catch {}
      }

      const CLAUDE_LIMITE_LER = claudeLimiteLer();
      let buffer = '';
      let stderrBuffer = '';
      let finalResult = null;
      let finalIsErr = false;
      let sessionId = sessaoDoTurno;
      let finalUsage = null;
      let mainUsage = null;
      let custo = null;
      let settled = false;
      let timedOut = false;
      // BUG-02: evidência ESTRUTURADA de limite do Claude, colhida em banda do próprio
      // stream-json do CLI (o mesmo dado unificado que o agente de referencia lê do header
      // anthropic-ratelimit-unified-reset, provider-usage.fetch.claude.ts:44-61). O CLI
      // emite `rate_limit_event` com `rate_limit_info` (status, resetsAt em epoch SEGUNDOS
      // UTC, rateLimitType, overageStatus). Fica null quando o evento não vem — aí a
      // retaguarda de texto (isLimitMessage) decide, sem inventar prazo.
      let ultimoLimite = null;
      const t0 = Date.now();

      const soltaTurno = () => {
        if (activeTurns.get(sessaoDoTurno) === handle) activeTurns.delete(sessaoDoTurno);
        if (sessionId && activeTurns.get(sessionId) === handle) activeTurns.delete(sessionId);
      };

      const done = (payload) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        clearTimeout(idleTimer);
        apagaDossie(dossiePF);
        soltaTurno();
        resolve(payload);
      };

      const timeoutMs = timeoutFor(entrada);
      const timer = setTimeout(() => {
        timedOut = true;
        handle.interrupt();
      }, timeoutMs);

      // Idle-stall: o mesmo freio do app-server. Turno que para de emitir evento por
      // tempo demais morre aqui, em vez de segurar o slot até o teto duro.
      const idleMs = Number(entrada.idleTimeoutMs) > 0 ? Number(entrada.idleTimeoutMs) : 0;
      let idleTimer = null;
      const tocaIdle = () => {
        if (!idleMs) return;
        clearTimeout(idleTimer);
        idleTimer = setTimeout(() => {
          timedOut = true;
          handle.interrupt();
        }, idleMs);
      };
      tocaIdle();

      const onEventoExterno = typeof entrada.onEvento === 'function' ? entrada.onEvento : null;
      const onDelta = typeof entrada.onDelta === 'function' ? entrada.onDelta : null;

      proc.stderr.on('data', (chunk) => {
        stderrBuffer += chunk;
        if (stderrBuffer.length > 20_000) stderrBuffer = stderrBuffer.slice(-20_000);
      });

      proc.stdout.on('data', (chunk) => {
        tocaIdle();
        buffer += chunk;
        let nl;
        while ((nl = buffer.indexOf('\n')) >= 0) {
          const line = buffer.slice(0, nl).trim();
          buffer = buffer.slice(nl + 1);
          if (!line) continue;
          let evento;
          try { evento = JSON.parse(line); } catch { continue; }
          if (onEventoExterno) { try { onEventoExterno(evento); } catch {} }
          // A sessão já nasceu com nome imposto. Se o CLI devolver outro id (versão que
          // ignora --session-id), o mapa passa a valer pelos dois nomes até o turno fechar.
          if (evento.session_id && evento.session_id !== sessionId) {
            sessionId = evento.session_id;
            handle.sessaoId = sessionId;
            activeTurns.set(sessionId, handle);
          }
          if (evento.type === 'assistant' && evento.message) {
            // usage da sessão PRINCIPAL: o usage de sub-agente (sidechain) envenena a
            // conta do contexto, então só o do fio principal conta.
            if (evento.message.usage && !evento.isSidechain && !evento.parent_tool_use_id && !evento.message.parent_tool_use_id) {
              mainUsage = evento.message.usage;
            }
            if (onDelta) {
              const texto = textoDaMensagem(evento.message);
              if (texto) { try { onDelta(texto); } catch {} }
            }
          }
          if (evento.type === 'result') {
            finalResult = evento.result;
            finalIsErr = Boolean(evento.is_error);
            sessionId = evento.session_id || sessionId;
            finalUsage = evento.usage || null;
            if (Number.isFinite(evento.total_cost_usd)) custo = evento.total_cost_usd;
          }
          // BUG-02: ramo do `rate_limit_event` (CLAUDE_LIMITE_LER=1). Guarda o horário
          // de reset estruturado; o último evento vence (o CLI reemite ao longo do turno).
          // Só entra atrás do kill-switch: com 0, o motor volta ao booleano `cota` puro.
          if (CLAUDE_LIMITE_LER && evento.type === 'rate_limit_event') {
            const info = (evento.rate_limit_info && typeof evento.rate_limit_info === 'object')
              ? evento.rate_limit_info : {};
            const resetsSeg = Number(info.resetsAt);
            ultimoLimite = {
              status: stringOrNull(info.status),                 // allowed | allowed_warning | rejected
              resetsAtMs: Number.isFinite(resetsSeg) ? resetsSeg * 1000 : null,
              tipo: stringOrNull(info.rateLimitType),            // five_hour | seven_day* | overage
              overageStatus: stringOrNull(info.overageStatus),
            };
          }
        }
      });

      proc.on('error', (error) => {
        done(output({
          erro: stderrBuffer || (error && error.message) || 'não consegui rodar o motor',
          sessaoId: sessionId,
        }));
      });

      proc.on('close', (code, signal) => {
        const usage = mainUsage || finalUsage;
        const ctxTokens = usage
          ? (num(usage.input_tokens) + num(usage.cache_read_input_tokens) + num(usage.cache_creation_input_tokens))
          : null;
        // uso no MESMO shape que o bridge le do Codex: entrada = total de entrada do turno (o que o
        // threadEstourou compara com o teto de crescimento). cache/saida pra telemetria e /cota da sala.
        const usoTurno = usage ? {
          entrada: num(usage.input_tokens) + num(usage.cache_read_input_tokens) + num(usage.cache_creation_input_tokens),
          cache: num(usage.cache_read_input_tokens),
          saida: num(usage.output_tokens),
          total: num(usage.input_tokens) + num(usage.cache_read_input_tokens) + num(usage.cache_creation_input_tokens) + num(usage.output_tokens),
        } : null;
        const duracao = Math.round((Date.now() - t0) / 1_000);
        // BUG-02: os campos de limite viajam em TODA saída deste turno (spread `...lim`).
        // `cotaEstrutural` é a evidência acima da regex: o CLI disse `status:'rejected'`
        // (e o overage não salva), então é cota mesmo que o texto não case isLimitMessage.
        const lim = campoLimite(ultimoLimite);
        const cotaEstrutural = lim.limiteStatus === 'rejected'
          && (ultimoLimite == null || !ultimoLimite.overageStatus || ultimoLimite.overageStatus === 'rejected');
        if (timedOut) {
          return done(output({
            // piso de 1s: "timeout de 0s" não diz nada pro dono.
            erro: `timeout de ${Math.max(1, Math.ceil(timeoutMs / 1_000))}s no motor`,
            sessaoId: sessionId,
            custoUSD: custo,
            ctxTokens,
            ...lim,
          }));
        }
        if (finalResult != null) {
          const texto = String(finalResult || '');
          // Mensagem de limite que volta COMO RESULTADO é cota, nunca texto pro dono. A
          // evidência ESTRUTURADA (cotaEstrutural) vem primeiro; a regex isLimitMessage
          // fica como retaguarda pro CLI que não emitiu o evento.
          if (cotaEstrutural || isLimitMessage(texto)) {
            return done(output({ erro: texto || 'limite do provedor', cota: true, sessaoId: sessionId, custoUSD: custo, ctxTokens, ...lim }));
          }
          if (finalIsErr) {
            return done(output({ erro: texto || 'resultado marcado como erro', sessaoId: sessionId, custoUSD: custo, ctxTokens, ...lim }));
          }
          return done(output({ texto, sessaoId: sessionId, custoUSD: custo, ctxTokens, uso: usoTurno, ...lim }));
        }
        const diagnostico = (stderrBuffer || buffer)
          || `o motor fechou sem resposta (exit=${code == null ? '?' : code} signal=${signal || 'none'} depois de ${duracao}s).`;
        done(output({
          erro: diagnostico,
          cota: cotaEstrutural || isLimitMessage(stderrBuffer),
          sessaoId: sessionId,
          custoUSD: custo,
          ctxTokens,
          ...lim,
        }));
      });

      // O corpo (contexto + fala) vai por STDIN; o dossiê vai pelo prompt de sistema.
      try {
        proc.stdin.write(buildUserInput(entrada));
        proc.stdin.end();
      } catch {}
    });
  }

  // Sessão deste motor é um arquivo de rollout do próprio CLI: não existe RPC de
  // apagar. resetar() garante que nenhum turno daquela sessão siga vivo e devolve
  // o mesmo contrato do codex-appserver; o bridge esquece o sessaoId e o próximo
  // turno abre sessão nova.
  async function resetar(sessionId) {
    const target = stringOrNull(sessionId);
    if (!target) return { ok: true, sessaoId: null };
    const ativo = activeTurns.get(target);
    if (ativo) {
      try { await ativo.interrupt(); } catch {}
    }
    return { ok: true, sessaoId: target };
  }

  async function encerrar(handle) {
    if (handle && typeof handle.interrupt === 'function') {
      try { await handle.interrupt(); } catch {}
      return;
    }
    if (typeof handle === 'string') {
      const ativo = activeTurns.get(handle);
      if (ativo) {
        try { await ativo.interrupt(); } catch {}
      }
      return;
    }
    // Sem argumento: derruba tudo que este motor tem de pé (paridade com o
    // encerrar() do app-server, que fecha a conexão inteira).
    await Promise.allSettled([...new Set(activeTurns.values())].map((turno) => turno.interrupt()));
  }

  // CATÁLOGO DE MODELOS (2.4.42). Contrato NEUTRO de motor, o mesmo do codex-appserver:
  // devolve o array cru de itens, ou null quando não sabe listar. Aqui a lista é curada
  // (o CLI do Claude não tem RPC de catálogo), então é síncrona na prática — mas mantém a
  // assinatura async e o fail-soft do irmão, pra que o bridge trate os dois igual.
  async function listarModelos() {
    try {
      return MODELOS_CLAUDE.map((m) => ({ ...m }));
    } catch (error) {
      return null;
    }
  }

  return {
    nome: 'claude',
    bin: command,
    capacidades,
    disponivel() { return claudeDisponivel(envSource, command); },
    responder,
    resetar,
    encerrar,
    listarModelos,
    turnosAtivos() { return new Set(activeTurns.values()).size; },
    turnoVivo(sid) { return typeof sid === 'string' && activeTurns.has(sid); },
    _adapter() { return null; },
  };
}

// Monta a lista de args do turno. A ordem é estável de propósito: o teste de spawn
// falso confere posição por posição.
//
// bypassPermissions é o literal permitido nesta base: o cliente roda com acesso total,
// igual ao mestre, e a flag de desligar aprovação e sandbox de uma vez não entra aqui.
function montaArgs(entrada, plano, cwd, dossiePF) {
  const workerLeaf = entrada && entrada.workerLeaf === true;
  const plannerLeaf = entrada && entrada.plannerLeaf === true;
  const reviewerLeaf = entrada && entrada.reviewerLeaf === true;
  const coordinatorHead = entrada && entrada.coordinatorHead === true;
  if ([workerLeaf, plannerLeaf, reviewerLeaf, coordinatorHead].filter(Boolean).length > 1) {
    throw new Error('perfil leaf ambiguo: worker, planner, reviewer e coordinator nao podem coexistir');
  }
  if (plannerLeaf) assertPlannerCwd(entrada, cwd);
  if (reviewerLeaf) assertReviewerCwd(entrada, cwd);
  const workerCapabilities = workerLeaf ? normalizeWorkerCapabilities(entrada.workerCapabilities) : [];
  const workerWeb = workerCapabilities.includes('web_search');
  if (workerLeaf && workerCapabilities.includes('image_generation')) {
    throw new Error('capacidade de imagem indisponivel no worker Claude; use uma sala Codex para este trabalho');
  }
  const workerTools = workerLeaf
    ? [...WORKER_LEAF_ALLOWED_TOOLS, ...(workerWeb ? WORKER_LEAF_WEB_TOOLS : [])]
    : [];
  const args = ['-p', '--output-format', 'stream-json', '--verbose', '--permission-mode',
    (plannerLeaf || reviewerLeaf || coordinatorHead) ? 'plan' : (workerLeaf ? 'dontAsk' : 'bypassPermissions')];
  if (workerLeaf || plannerLeaf || reviewerLeaf || coordinatorHead) args.push('--permission-prompts', 'none');
  if (workerLeaf || plannerLeaf || reviewerLeaf || coordinatorHead) {
    // Defesa em profundidade: `plan` veda mutacao; `restricted` ignora settings
    // locais; safe-mode remove skills/plugins/hooks/agentes/workflows; e
    // strict-mcp sem --mcp-config impede carregar MCPs da casa. O worker
    // recebe somente file tools locais e, quando concedido explicitamente,
    // pesquisa web somente-leitura. A sessao do worker continua persistente
    // para a unica retomada duravel; planner/reviewer sao descartaveis.
    args.push('--restricted', '--safe-mode', '--strict-mcp-config', '--tools',
      workerLeaf ? workerTools.join(',')
        : (reviewerLeaf ? REVIEWER_LEAF_ALLOWED_TOOLS.join(',') : ''));
    // A cabeça mantém a thread para memória conversacional. Somente as folhas
    // descartáveis de planejamento/revisão desligam persistência.
    if (plannerLeaf || reviewerLeaf) args.push('--no-session-persistence');
  }
  const modelo = stringOrNull(entrada.modelo);
  if (modelo) args.push('--model', modelo);
  const rootsDeclaradas = coordinatorHead ? [] : (workerLeaf && Array.isArray(entrada.workerWritableRoots)
    ? entrada.workerWritableRoots
    : (reviewerLeaf && Array.isArray(entrada.reviewerReadRoots)
      ? entrada.reviewerReadRoots : (plannerLeaf ? [] : entrada.diretorios)));
  const diretorios = normalizeDirectories(rootsDeclaradas, cwd);
  if (workerLeaf) {
    if (!diretorios.length) throw new Error('worker leaf sem writableRoots: turno recusado por seguranca');
    const dentro = diretorios.some((root) => cwd === root || cwd.startsWith(`${root}${path.sep}`));
    if (!dentro) throw new Error('cwd do worker leaf fora de writableRoots: turno recusado por seguranca');
  }
  const somenteLeitura = workerLeaf
    ? normalizeDirectories(entrada.workerReadRoots, cwd)
      .filter((root) => !diretorios.includes(root))
    : [];
  for (const dir of [...diretorios, ...somenteLeitura]) args.push('--add-dir', dir);
  const effort = stringOrNull(entrada.effort);
  if (effort) args.push('--effort', effort);
  if (Number.isFinite(entrada.tetoUSD) && entrada.tetoUSD > 0) args.push('--max-budget-usd', String(entrada.tetoUSD));
  if (Number.isFinite(entrada.maxTurnos) && entrada.maxTurnos > 0) args.push('--max-turns', String(entrada.maxTurnos));
  // ORQUESTRA (5-C): a caixa de ferramentas do subagente. `entrada.ferramentas`
  // é a allowlist do envelope efetivo (interseccão das três, já ordenada). Só sai
  // a flag quando a lista existe — o turno normal (sem envelope) roda byte a byte
  // igual a antes, sem --allowedTools. `disallowedTools` recebe o complemento
  // explícito, pra fechar a porta por dois lados.
  if (plannerLeaf) {
    args.push('--disallowedTools', PLANNER_LEAF_DENIED_TOOLS.join(','));
  } else if (reviewerLeaf) {
    args.push('--allowedTools', REVIEWER_LEAF_ALLOWED_TOOLS.join(','));
    args.push('--disallowedTools', REVIEWER_LEAF_DENIED_TOOLS.join(','));
  } else if (coordinatorHead) {
    args.push('--allowedTools', '');
    args.push('--disallowedTools', COORDINATOR_HEAD_DENIED_TOOLS.join(','));
  } else if (workerLeaf || Array.isArray(entrada.ferramentas)) {
    const solicitadas = Array.isArray(entrada.ferramentas)
      ? entrada.ferramentas.map((x) => String(x).trim()).filter(Boolean)
      : workerTools;
    // Folha recebe uma interseccao fechada. Nomes desconhecidos (incluindo MCPs
    // de mensagem/publicacao) nao entram por acidente; Bash e WebFetch ficam
    // negados dos dois lados mesmo se um envelope futuro tentar pedi-los.
    const permit = workerLeaf
      ? solicitadas.filter((tool) => workerTools.includes(tool))
      : solicitadas;
    args.push('--allowedTools', permit.join(','));
    const nega = [...new Set([
      ...(workerLeaf ? WORKER_LEAF_DENIED_TOOLS : []),
      ...(workerLeaf && !workerWeb ? WORKER_LEAF_WEB_TOOLS : []),
      ...(Array.isArray(entrada.ferramentasNegadas)
        ? entrada.ferramentasNegadas.map((x) => String(x).trim()).filter(Boolean)
        : []),
    ])];
    if (nega.length) args.push('--disallowedTools', nega.join(','));
  }
  // Retomada só quando o transcript existe de verdade (decideSessao já conferiu); caso
  // contrário o nome novo é IMPOSTO e a sessão nasce limpa.
  if (plano.retomando) args.push('--resume', plano.sessaoId);
  else args.push('--session-id', plano.sessaoId);
  if (dossiePF) args.push('--append-system-prompt-file', dossiePF);
  return args;
}

function normalizeWorkerCapabilities(value) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error('worker capabilities invalidas: turno recusado por seguranca');
  const normalized = [...new Set(value.map((item) => String(item || '').trim()).filter(Boolean))];
  const unknown = normalized.find((item) => !WORKER_CAPABILITIES.includes(item));
  if (unknown) throw new Error(`worker capability nao autorizada: ${unknown}`);
  return normalized;
}

function assertReviewerCwd(entrada, cwd) {
  const declarado = stringOrNull(entrada && entrada.reviewerCwd);
  if (!declarado) throw new Error('reviewer leaf sem cwd imutavel: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do reviewer leaf diverge do snapshot imutavel: turno recusado por seguranca');
  }
  const roots = normalizeDirectories(entrada && entrada.reviewerReadRoots, cwd);
  if (!roots.length || !roots.some((root) => cwd === root || cwd.startsWith(`${root}${path.sep}`))) {
    throw new Error('reviewer leaf fora dos snapshots declarados: turno recusado por seguranca');
  }
}

function assertPlannerCwd(entrada, cwd) {
  const declarado = stringOrNull(entrada && entrada.plannerCwd);
  if (!declarado) throw new Error('planner leaf sem cwd isolado: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do planner leaf diverge do cwd isolado: turno recusado por seguranca');
  }
}

// Onde o CLI guarda o transcript das sessões desta casa. O bridge passa o state dir da
// instalação; sem ele vale o ~/.claude do usuário do serviço.
function resolveStateDir(options, envSource) {
  const informado = options && options.stateDir ? String(options.stateDir) : (envSource.CLAUDE_CONFIG_DIR || '');
  if (informado) return path.resolve(informado);
  const home = envSource.HOME || os.homedir() || process.cwd();
  return path.join(home, '.claude');
}

// O transcript de uma sessão é um .jsonl com o nome dela, em algum projeto do state dir.
// Conferir antes de retomar evita mandar --resume de um id que já não existe: em vez de
// sessão nova em silêncio, o motivo fica registrado e o bridge semeia pelo banco.
function transcriptExiste(stateDir, sessaoId) {
  const alvo = `${sessaoId}.jsonl`;
  const projetos = path.join(stateDir, 'projects');
  let dirs;
  try { dirs = fs.readdirSync(projetos, { withFileTypes: true }); } catch { return false; }
  for (const item of dirs) {
    if (!item.isDirectory()) continue;
    try {
      const info = fs.statSync(path.join(projetos, item.name, alvo));
      if (info.isFile() && info.size > 0) return true;
    } catch {}
  }
  return false;
}

// Grava o dossiê num arquivo 0600 dentro do state dir. Arquivo, e nunca argumento:
// argv aparece no ps de qualquer processo da máquina, e o dossiê carrega o contexto do
// dono. Sem dossiê não há arquivo nenhum, e o turno roda sem a flag.
function gravaDossie(stateDir, dossie, options) {
  const texto = String(dossie || '');
  if (!texto) return null;
  const dir = path.join(stateDir, 'leon-dossies');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const pf = path.join(dir, `${DOSSIE_PREFIXO}${process.pid}-${randomUUID()}.md`);
  const escreve = options && typeof options.writeFileFn === 'function' ? options.writeFileFn : fs.writeFileSync;
  escreve(pf, texto, { mode: 0o600 });
  return pf;
}

function apagaDossie(pf) {
  if (!pf) return;
  try { fs.unlinkSync(pf); } catch {}
}

// Mesma montagem de corpo do codex-appserver: contexto e depois a fala do dono, com
// o mesmo separador, pra o dossiê poliglota render igual nos dois motores.
function buildUserInput(entrada) {
  const parts = [];
  if (entrada.contexto) parts.push(String(entrada.contexto));
  parts.push(`${SEP_FALA}\n${String(entrada.fala || '')}`);
  return parts.join('\n\n');
}

function textoDaMensagem(message) {
  const content = message && Array.isArray(message.content) ? message.content : [];
  return content.filter((item) => item && item.type === 'text').map((item) => String(item.text || '')).join('');
}

// Env do filho: cópia enxuta, sem herdar segredo que o motor não precisa ver.
function childEnv(envSource, options) {
  const base = {};
  const permitidas = [
    'PATH', 'HOME', 'USER', 'LOGNAME', 'SHELL', 'LANG', 'LC_ALL', 'TZ', 'TERM',
    'TMPDIR', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_DATA_HOME',
    'CLAUDE_CODE_OAUTH_TOKEN', 'CLAUDE_CONFIG_DIR', 'ANTHROPIC_API_KEY',
  ];
  for (const nome of permitidas) {
    if (envSource[nome] != null) base[nome] = String(envSource[nome]);
  }
  const extras = options && options.env && typeof options.env === 'object' ? options.env : {};
  for (const [nome, valor] of Object.entries(extras)) {
    if (valor != null) base[nome] = String(valor);
  }
  return base;
}

function effectiveCwd(entrada, envSource) {
  const dirs = Array.isArray(entrada.diretorios) ? entrada.diretorios : [];
  const raw = entrada.cwd || dirs.find(Boolean) || envSource.HOME || os.homedir() || process.cwd();
  return path.resolve(String(raw));
}

function normalizeDirectories(value, cwd) {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || !item.trim()) continue;
    unique.add(path.resolve(cwd, item));
  }
  return [...unique];
}

// O binário pelo caminho ABSOLUTO quando dá: o serviço roda com PATH restrito.
function resolveClaudeBin(envSource) {
  // (a) CLAUDE_BIN do env, e SÓ se for executável de verdade (X_OK): é o atalho do dono e o
  // que a persistência alimenta pro próximo boot. Um valor obsoleto/não-executável não trava a
  // resolução — cai na lista fixa e, se preciso, no shell de login.
  const informado = envSource.CLAUDE_BIN;
  if (informado) {
    try { fs.accessSync(informado, fs.constants.X_OK); return informado; } catch {}
  }
  const home = envSource.HOME || os.homedir();
  // O prefixo Node dedicado da casa: o instalador põe o CLI em $HOME/.leon/node/releases/<versão>/bin
  // e exporta LEON_NODE_BIN_RESOLVED apontando pro node desse prefixo. O `claude` mora ao lado do node.
  // (Modelado da resolução por caminho absoluto do mestre; sem isso o serviço, com PATH restrito,
  // instala o Claude e depois não acha — bug pego na casa do cliente 08/09.)
  const dedicados = [];
  try {
    if (envSource.LEON_NODE_BIN_RESOLVED) {
      dedicados.push(path.join(path.dirname(envSource.LEON_NODE_BIN_RESOLVED), 'claude'));
    }
  } catch {}
  try {
    const releasesDir = path.join(home || '', '.leon', 'node', 'releases');
    for (const rel of fs.readdirSync(releasesDir)) {
      dedicados.push(path.join(releasesDir, rel, 'bin', 'claude'));
    }
  } catch {}
  const candidatos = [
    ...dedicados,
    path.join(home || '', '.npm-global', 'bin', 'claude'),
    path.join(home || '', '.local', 'bin', 'claude'),
    '/usr/local/bin/claude',
    '/usr/bin/claude',
    '/snap/bin/claude',
  ];
  for (const candidato of candidatos) {
    try { fs.accessSync(candidato, fs.constants.X_OK); return candidato; } catch {}
  }
  // FALLBACK ROBUSTO: nenhum caminho fixo casou. O serviço roda com PATH restrito, mas o CLI
  // pode estar num prefixo de usuário que só o SHELL DE LOGIN conhece (o npm respeita ~/.npmrc,
  // ~/.profile). Pergunta ao shell de login onde o `claude` está — pega qualquer prefixo, do jeito
  // que o dono acharia no terminal. Cacheado por processo (não roda bash a cada turno). Causa-raiz
  // 08/09: casa Codex instala o Claude à mão num prefixo fora da lista; disponivel() dizia "não achei".
  const achadoPeloShell = resolveClaudePeloLoginShell(envSource);
  if (achadoPeloShell) {
    try { persisteClaudeBinNoEnv(envSource, achadoPeloShell); } catch {}
    return achadoPeloShell;
  }
  return 'claude';
}

// Cache por processo do caminho resolvido pelo login shell (evita rodar bash a cada resolução).
let _claudeBinLoginCache; // undefined = não tentou; string|null = resultado
function resolveClaudePeloLoginShell(envSource) {
  if (_claudeBinLoginCache !== undefined) return _claudeBinLoginCache;
  _claudeBinLoginCache = null;
  try {
    const { spawnSync } = require('node:child_process');
    const env = { ...process.env };
    if (envSource && envSource.HOME) env.HOME = envSource.HOME;
    const r = spawnSync('bash', ['-lc', 'command -v claude'], { timeout: 5000, encoding: 'utf8', env });
    if (r && r.status === 0 && typeof r.stdout === 'string') {
      const p = r.stdout.trim().split('\n').filter(Boolean).pop();
      if (p && p.includes(path.sep)) {
        try { fs.accessSync(p, fs.constants.X_OK); _claudeBinLoginCache = p; } catch {}
      }
    }
  } catch {}
  return _claudeBinLoginCache;
}

// Grava CLAUDE_BIN no .env da casa (chave na allowlist do bridge) pra o próximo boot resolver
// instantâneo, sem rodar bash de novo. Substitui a linha se já existir, senão anexa — nunca
// deixa o dono editar a mão pra isso.
//
// Escrita IN-PLACE (fs.writeFileSync sobre o mesmo arquivo), NÃO tmp+rename: o rename troca o
// inode e o arquivo novo nasce com o umask/dono de quem escreve — e o serviço roda como o dono,
// mas uma cura por terminal roda como root, e root:root no .env derruba o serviço (lei de
// memória: "Edit troca dono"). writeFileSync sobre o arquivo existente mantém chmod e dono,
// exatamente como o trocarModeloAposFalha do bridge faz com CODEX_MODEL.
function persisteClaudeBinNoEnv(envSource, caminho) {
  // Vale JÁ nesta sessão: o segundo createMotor resolve pelo ramo (a) sem bash, e as sondas de
  // login/versão do bridge (que leem process.env.CLAUDE_BIN) acham o CLI sem PATH de serviço.
  try { if (envSource) envSource.CLAUDE_BIN = caminho; } catch {}
  const envPath = (envSource && envSource.LEON_ENV_FILE) || '';
  if (!envPath) return; // sem o caminho do .env (LEON_ENV_FILE) a persistência é no-op; a sessão já resolveu.
  // Guarda de sanidade: caminho com quebra de linha/nulo corromperia o .env (o leitor do bridge
  // recusaria o boot). Um caminho de binário nunca tem isso.
  if (/[\r\n\0]/.test(caminho) || caminho.length > 8192) return;
  try {
    let texto = '';
    try { texto = fs.readFileSync(envPath, 'utf8'); } catch {}
    texto = /^CLAUDE_BIN=/m.test(texto)
      ? texto.replace(/^CLAUDE_BIN=.*$/m, `CLAUDE_BIN=${caminho}`)
      : texto.replace(/\n?$/, `\nCLAUDE_BIN=${caminho}\n`);
    fs.writeFileSync(envPath, texto);   // sobrescreve conteúdo só; não mexe no chmod/dono do arquivo existente
  } catch (e) {
    try { console.error('[motor claude] não gravei CLAUDE_BIN no .env (segue só nesta sessão):', e && e.message); } catch {}
  }
}

// disponivel() e o guard do turno perguntam ao MESMO resolvedor (não a um binaryAvailable cru
// sobre o PATH do serviço, que era o que mentia "não achei" com o Claude num prefixo fora do
// PATH). Caminho absoluto já veio validado por X_OK na resolução → disponível. Só o "claude"
// degradado (nem env, nem lista fixa, nem login shell acharam) cai no PATH: se não está lá,
// disponivel() diz false — honesto, sem travar.
function claudeDisponivel(envSource, command) {
  const alvo = command || resolveClaudeBin(envSource || {});
  if (String(alvo).includes(path.sep)) {
    try { fs.accessSync(alvo, fs.constants.X_OK); return true; } catch { return false; }
  }
  return binaryAvailable(alvo, envSource && envSource.PATH);
}

// X_OK, não existsSync: o shell só roda o que tem bit de execução, e um arquivo `claude` sem
// +x num dir do PATH não é o CLI utilizável. Degrada pra false em qualquer erro.
function binaryAvailable(command, pathValue) {
  const executavel = (p) => { try { fs.accessSync(p, fs.constants.X_OK); return true; } catch { return false; } };
  if (String(command).includes(path.sep)) {
    return executavel(command);
  }
  return String(pathValue || '').split(path.delimiter).some((dir) => {
    if (!dir) return false;
    return executavel(path.join(dir, command));
  });
}

function timeoutFor(entrada) {
  return intOption(entrada.timeoutMs, DEFAULT_TIMEOUT_MS);
}

// Shape de saída idêntico ao do codex-appserver: quem consome não distingue motor.
// BUG-02: três campos NOVOS, sempre presentes (null quando não houve evento de limite),
// pra o bridge decidir a janela sem reparsear texto. O motor Codex não os emite; o
// bridge trata a ausência como "sem info", exatamente como hoje.
function output(value = {}) {
  return {
    texto: typeof value.texto === 'string' ? value.texto : '',
    custoUSD: Number.isFinite(value.custoUSD) ? value.custoUSD : null,
    sessaoId: value.sessaoId || null,
    erro: value.erro || null,
    cota: Boolean(value.cota),
    ctxTokens: Number.isFinite(value.ctxTokens) ? value.ctxTokens : null,
    // MEMORIA CLAUDE (14/09): o adapter passa a devolver `uso` (como o Codex, codex-appserver.cjs:622),
    // pra o bridge medir CRESCIMENTO da conversa (threadEstourou) e ter rede de handoff propria em sala
    // Claude, em vez de depender 100% do /compact silencioso do CLI. Sem isso o teto nunca disparava no Claude.
    uso: value.uso && typeof value.uso === 'object' ? value.uso : null,
    limiteAte: Number.isFinite(value.limiteAte) ? value.limiteAte : null,   // epoch ms UTC do reset
    limiteTipo: value.limiteTipo || null,                                   // five_hour | seven_day* | overage
    limiteStatus: value.limiteStatus || null,                               // allowed | allowed_warning | rejected
  };
}

// BUG-02: normaliza o `ultimoLimite` colhido no stream em campos da saída. Nunca chuta:
// sem evento (null) devolve os três campos nulos, e o bridge cai na retaguarda de texto.
function campoLimite(ultimoLimite) {
  if (!ultimoLimite || typeof ultimoLimite !== 'object') {
    return { limiteAte: null, limiteTipo: null, limiteStatus: null };
  }
  return {
    limiteAte: Number.isFinite(ultimoLimite.resetsAtMs) ? ultimoLimite.resetsAtMs : null,
    limiteTipo: ultimoLimite.tipo || null,
    limiteStatus: ultimoLimite.status || null,
  };
}

function isLimitMessage(value) {
  const text = String(value || '');
  return text.length < 500 && /(hit your limit|usage limit|limit reached|rate.?limit|credit balance|balance is too low|too many requests|usageLimitExceeded)/i.test(text);
}

function num(value) {
  return Number.isFinite(value) ? value : 0;
}

function stringOrNull(value) {
  return value == null || value === '' ? null : String(value);
}

function intOption(value, fallback) {
  const number = Number(value == null ? fallback : value);
  if (!Number.isSafeInteger(number) || number <= 0) return fallback;
  return number;
}

function numberFromEnv(name, fallback) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function withLock(locks, key, operation) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  locks.set(key, current);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (locks.get(key) === current) locks.delete(key);
  }
}

module.exports = {
  createMotor,
  setHooks,
  capacidades,
  _buildUserInput: buildUserInput,
  _montaArgs: montaArgs,
  _normalizeWorkerCapabilities: normalizeWorkerCapabilities,
  _normalizeDirectories: normalizeDirectories,
  _output: output,
  _transcriptExiste: transcriptExiste,
  _resolveStateDir: resolveStateDir,
  // Costuras de prova: resolver o CLI e a disponibilidade sem subir um motor inteiro, e
  // zerar o cache do login-shell entre cenários no mesmo processo.
  _resolveClaudeBin: resolveClaudeBin,
  _claudeDisponivel: claudeDisponivel,
  _resetBinLoginCache: () => { _claudeBinLoginCache = undefined; },
};
