'use strict';
// lib-motores/index.cjs — o SELETOR de motor da casa.
//
// Lei do dono: a casa tem sempre os dois motores, e o agente performa igual em
// qualquer um deles. Quem escolhe é o .env da instalação (ENGINE_DEFAULT ou ENGINE);
// sem nada declarado, vale o motor histórico desta base.
//
// O bridge cria UMA instância a partir daqui e chama exatamente os mesmos métodos de
// antes. Nada de rota escondida: não existe troca de motor por sala nem por mensagem;
// a troca é do dono, no .env, com restart.

const MOTOR_PADRAO = 'codex';
const MOTORES_CONHECIDOS = Object.freeze(['codex', 'claude']);

// Normaliza o que veio do .env. Valor ausente, vazio ou desconhecido cai no padrão,
// nunca em erro: motor errado no .env não pode deixar a casa muda.
function nomeDoMotor(envSource = process.env) {
  const bruto = String(envSource.ENGINE_DEFAULT || envSource.ENGINE || '').trim().toLowerCase();
  if (!bruto) return MOTOR_PADRAO;
  if (!MOTORES_CONHECIDOS.includes(bruto)) {
    try { console.error(`[motores] motor "${bruto}" não existe nesta base; subindo no ${MOTOR_PADRAO}`); } catch {}
    return MOTOR_PADRAO;
  }
  return bruto;
}

// Cria a instância do motor da casa. As options são as MESMAS que o bridge sempre
// passou; cada adaptador ignora sozinho o que não usa, então o chamador não precisa
// saber qual motor está de pé.
function criaMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const nome = options.nome ? String(options.nome).toLowerCase() : nomeDoMotor(envSource);
  if (nome === 'claude') {
    const { createMotor } = require('./claude.cjs');
    return createMotor(options);
  }
  const { createMotor } = require('./codex-appserver.cjs');
  return createMotor(options);
}

// Injeta os hooks de processo do chassi (trackKid/killTree) no motor que os aceita.
// O codex-appserver rastreia por conta própria dentro do adapter; o motor de spawn
// precisa dos hooks do bridge pra não deixar órfão num restart.
function aplicaHooks(hooks) {
  try {
    const { setHooks } = require('./claude.cjs');
    if (typeof setHooks === 'function') setHooks(hooks);
  } catch {}
}

// Os modelos que cada motor oferece ao dono. O /modelo lista a do motor de pé: oferecer a
// lista do outro faria o dono escolher um nome que o motor da casa nem conhece. O primeiro
// da lista é o padrão daquele motor.
// A lista Codex acompanha o fallback do runtime vivo. Os nomes legados ficam no fim
// para casas ainda pinadas neles, sem esconder o catalogo atual.
const MODELOS_POR_MOTOR = Object.freeze({
  codex: Object.freeze(['gpt-6-astra', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna', 'gpt-5.5', 'gpt-5.6', 'gpt-5.3-codex']),
  claude: Object.freeze(['claude-opus-4-8', 'claude-sonnet-5']),
});

const ESFORCOS_CODEX_COMPLETOS = Object.freeze(['low', 'medium', 'high', 'xhigh', 'max', 'ultra']);
const ESFORCOS_POR_MODELO = Object.freeze({
  'gpt-6-astra': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-sol': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-terra': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-luna': Object.freeze(['low', 'medium', 'high', 'xhigh', 'max']),
  'gpt-5.5': Object.freeze(['low', 'medium', 'high', 'xhigh']),
});

function modelosDe(nome) {
  const alvo = String(nome || '').toLowerCase();
  return MODELOS_POR_MOTOR[alvo] || MODELOS_POR_MOTOR[MOTOR_PADRAO];
}

function esforcosDe(nome, modelo) {
  const motor = String(nome || '').toLowerCase();
  const id = String(modelo || '').toLowerCase();
  if (motor === 'codex') return ESFORCOS_POR_MODELO[id] || Object.freeze(['low', 'medium', 'high', 'xhigh']);
  if (motor === 'claude') return Object.freeze(['low', 'medium', 'high']);
  return Object.freeze(['low', 'medium', 'high']);
}

// Capacidades do motor SEM criar instância (o instalador e os testes perguntam).
function capacidadesDe(nome) {
  const alvo = String(nome || '').toLowerCase();
  if (alvo === 'claude') return require('./claude.cjs').capacidades;
  if (alvo === 'codex') return require('./codex-appserver.cjs').capacidades;
  return null;
}

module.exports = {
  MOTOR_PADRAO,
  MOTORES_CONHECIDOS,
  MODELOS_POR_MOTOR,
  ESFORCOS_POR_MODELO,
  modelosDe,
  esforcosDe,
  nomeDoMotor,
  criaMotor,
  aplicaHooks,
  capacidadesDe,
};
