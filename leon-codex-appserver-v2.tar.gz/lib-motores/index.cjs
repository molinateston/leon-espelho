'use strict';
// lib-motores/index.cjs — o SELETOR de motor da casa.
//
// Lei do dono: a casa tem sempre os dois motores, e o agente performa igual em
// qualquer um deles. Quem escolhe é o .env da instalação (ENGINE_DEFAULT ou ENGINE);
// sem nada declarado, vale o motor histórico desta base.
//
// O bridge cria UMA instância a partir daqui e chama exatamente os mesmos métodos de
// antes. Nada de rota escondida: não existe troca de motor por sala nem por mensagem;
// a troca é do dono, no .env, com restart.

// A2 (21/09/2026): as listas da casa DERIVAM da tabela. Antes o DeepSeek estava cravado aqui
// como literal, e motor novo pedia edição em três lugares (esta lista, a lista de segredos do
// app-server e o teclado do /motor) — três chances de esquecer um. Agora motor novo é uma linha
// em config/provedores.json e uma chave no cofre; estes arrays se montam sozinhos.
const tabela = require('./provedores-tabela.cjs');

const MOTOR_PADRAO = 'codex';
// Os NATIVOS vêm primeiro e nunca saem: eles não dependem da tabela, e uma tabela ilegível não
// pode deixar a casa sem motor. Os da tabela entram depois, na ordem em que o dono os escreveu.
const MOTORES_NATIVOS = Object.freeze(['codex', 'claude']);
const MOTORES_CONHECIDOS = Object.freeze([
  ...MOTORES_NATIVOS,
  ...tabela.nomesDeProvedores().filter((nome) => !MOTORES_NATIVOS.includes(nome)),
]);

// Normaliza o que veio do .env. Valor ausente, vazio ou desconhecido cai no padrão,
// nunca em erro: motor errado no .env não pode deixar a casa muda.
function nomeDoMotor(envSource = process.env) {
  const bruto = String(envSource.ENGINE_DEFAULT || envSource.ENGINE || '').trim().toLowerCase();
  if (!bruto) return MOTOR_PADRAO;
  if (!MOTORES_CONHECIDOS.includes(bruto)) {
    try { console.error(`[motores] motor "${bruto}" não existe nesta base; subindo no ${MOTOR_PADRAO}`); } catch {}
    return MOTOR_PADRAO;
  }
  return bruto;
}

// Cria a instância do motor da casa. As options são as MESMAS que o bridge sempre
// passou; cada adaptador ignora sozinho o que não usa, então o chamador não precisa
// saber qual motor está de pé.
function criaMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const nome = options.nome ? String(options.nome).toLowerCase() : nomeDoMotor(envSource);
  if (nome === 'claude') {
    const { createMotor } = require('./claude.cjs');
    return createMotor(options);
  }
  // Qualquer motor da tabela sobe no MESMO adaptador genérico, parametrizado pela linha dele.
  if (tabela.ehProvedorApi(nome)) {
    const { createMotor } = require('./provedor-api.cjs');
    return createMotor({ ...options, nome });
  }
  const { createMotor } = require('./codex-appserver.cjs');
  return createMotor(options);
}

// Injeta os hooks de processo do chassi (trackKid/killTree) no motor que os aceita.
// O codex-appserver rastreia por conta própria dentro do adapter; o motor de spawn
// precisa dos hooks do bridge pra não deixar órfão num restart.
function aplicaHooks(hooks) {
  try {
    const { setHooks } = require('./claude.cjs');
    if (typeof setHooks === 'function') setHooks(hooks);
  } catch {}
}

// Os modelos que cada motor oferece ao dono. O /modelo lista a do motor de pé: oferecer a
// lista do outro faria o dono escolher um nome que o motor da casa nem conhece. O primeiro
// da lista é o padrão daquele motor.
// A lista Codex acompanha o fallback do runtime vivo. Os nomes legados ficam no fim
// para casas ainda pinadas neles, sem esconder o catalogo atual.
// O catálogo dos motores por API sai da tabela (A2): o DeepSeek deixou de ser literal aqui.
const MODELOS_POR_MOTOR = Object.freeze({
  codex: Object.freeze(['gpt-6-astra', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna', 'gpt-5.5', 'gpt-5.6', 'gpt-5.3-codex']),
  // 2.6.8 (incidente 23/09): o Sonnet volta pra frente e e o PADRAO do Claude. Opus na frente
  // gastava a janela do plano em horas e o provedor passava a recusar por ritmo (429). O dono
  // que quer Opus escolhe pelo /modelo; os Opus seguem no catalogo, so deixam de ser o padrao.
  claude: Object.freeze(['claude-sonnet-5', 'claude-opus-5-5', 'claude-opus-5', 'claude-opus-4-8']),
  ...Object.fromEntries(tabela.nomesDeProvedores().map((nome) => (
    [nome, tabela.linhaDoProvedor(nome).modelos]
  ))),
});

const ESFORCOS_CODEX_COMPLETOS = Object.freeze(['low', 'medium', 'high', 'xhigh', 'max', 'ultra']);
const ESFORCOS_POR_MODELO = Object.freeze({
  'gpt-6-astra': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-sol': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-terra': ESFORCOS_CODEX_COMPLETOS,
  'gpt-5.6-luna': Object.freeze(['low', 'medium', 'high', 'xhigh', 'max']),
  'gpt-5.5': Object.freeze(['low', 'medium', 'high', 'xhigh']),
});

function modelosDe(nome) {
  const alvo = String(nome || '').toLowerCase();
  return MODELOS_POR_MOTOR[alvo] || MODELOS_POR_MOTOR[MOTOR_PADRAO];
}

function esforcosDe(nome, modelo) {
  const motor = String(nome || '').toLowerCase();
  const id = String(modelo || '').toLowerCase();
  if (motor === 'codex') return ESFORCOS_POR_MODELO[id] || Object.freeze(['low', 'medium', 'high', 'xhigh']);
  if (motor === 'claude') return Object.freeze(['low', 'medium', 'high']);
  const linha = tabela.linhaDoProvedor(motor);
  if (linha) return linha.efforts;
  return Object.freeze(['low', 'medium', 'high']);
}

// Capacidades do motor SEM criar instância (o instalador e os testes perguntam).
function capacidadesDe(nome) {
  const alvo = String(nome || '').toLowerCase();
  if (alvo === 'claude') return require('./claude.cjs').capacidades;
  if (alvo === 'codex') return require('./codex-appserver.cjs').capacidades;
  if (tabela.ehProvedorApi(alvo)) return require('./provedor-api.cjs').capacidades;
  return null;
}

// O nome bonito que o dono lê no /motor. Os nativos são os dois de sempre; os da tabela trazem
// o rótulo da própria linha, então motor novo já nasce com o nome certo no teclado (A2).
const ROTULOS_NATIVOS = Object.freeze({ codex: 'Codex', claude: 'Claude' });
function rotuloDe(nome) {
  const alvo = String(nome || '').toLowerCase().trim();
  if (ROTULOS_NATIVOS[alvo]) return ROTULOS_NATIVOS[alvo];
  const linha = tabela.linhaDoProvedor(alvo);
  if (linha) return linha.rotulo;
  return alvo ? `${alvo.charAt(0).toUpperCase()}${alvo.slice(1)}` : '';
}

module.exports = {
  MOTOR_PADRAO,
  MOTORES_NATIVOS,
  MOTORES_CONHECIDOS,
  rotuloDe,
  MODELOS_POR_MOTOR,
  ESFORCOS_POR_MODELO,
  modelosDe,
  esforcosDe,
  nomeDoMotor,
  criaMotor,
  aplicaHooks,
  capacidadesDe,
};
