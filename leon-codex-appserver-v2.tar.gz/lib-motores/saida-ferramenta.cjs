'use strict';
// lib-motores/saida-ferramenta.cjs — UMA JANELA DE SAIDA DE FERRAMENTA PROS TRES MOTORES.
//
// 25/09 (economia, mesmo caminho pra dono e cliente): 4000 tokens fixos, perto de 16 mil
// caracteres, a regua E3 do molde claw (src/agents/tool-result-limits.ts:31 `maxChars =
// maxTokens * 4`), que aplica UM teto de resultado de ferramenta a todo provedor. Nao le mais
// LEON_SAIDA_FERRAMENTA_TOKENS nem o sinonimo LEON_CODEX_SAIDA_FERRAMENTA: as duas viram chave
// morta aceita (lib/integracoes.cjs), e o mestre deixa de rodar numero diferente do cliente.
//
// Onde o limite entra, por motor (o mecanismo difere, o numero e um so):
//   - Codex (lib-motores/codex-appserver.cjs): `-c tool_output_token_limit=N` no nascimento do
//     app-server, cabeca e folha. Unidade: tokens.
//   - Motor por API (lib-motores/provedor-api.cjs): o mesmo `-c` e a linha
//     `tool_output_token_limit = N` no config.toml da casa propria.
//   - Claude (lib-motores/claude.cjs): env do filho MAX_MCP_OUTPUT_TOKENS=N (tokens) e
//     BASH_MAX_OUTPUT_LENGTH=N*4 (caracteres), mais `--settings {"bashOutputMaxChars":N*4}`
//     (quem corta a saida INLINE do Bash no CLI 2.1.280 e a chave de settings).

const SAIDA_FERRAMENTA_TOKENS = 4000;
const CARACTERES_POR_TOKEN = 4;

function saidaFerramentaTokens() {
  return SAIDA_FERRAMENTA_TOKENS;
}

function saidaFerramentaCaracteres() {
  return SAIDA_FERRAMENTA_TOKENS * CARACTERES_POR_TOKEN;
}

// Claude: variaveis do filho.
function envClaudeSaida() {
  return {
    MAX_MCP_OUTPUT_TOKENS: String(SAIDA_FERRAMENTA_TOKENS),
    BASH_MAX_OUTPUT_LENGTH: String(saidaFerramentaCaracteres()),
  };
}

// Claude: args do turno.
function argsClaudeSaida() {
  return ['--settings', JSON.stringify({ bashOutputMaxChars: saidaFerramentaCaracteres() })];
}

// Chassi Codex (nativo e API): o `-c` do nascimento do app-server.
function argsCodexSaida() {
  return ['-c', `tool_output_token_limit=${SAIDA_FERRAMENTA_TOKENS}`];
}

// Motor por API: a linha do config.toml gerado. Chave de topo (antes de qualquer tabela).
function linhasTomlSaida() {
  return [`tool_output_token_limit = ${SAIDA_FERRAMENTA_TOKENS}`];
}

module.exports = {
  SAIDA_FERRAMENTA_TOKENS,
  CARACTERES_POR_TOKEN,
  saidaFerramentaTokens,
  saidaFerramentaCaracteres,
  envClaudeSaida,
  argsClaudeSaida,
  argsCodexSaida,
  linhasTomlSaida,
};
