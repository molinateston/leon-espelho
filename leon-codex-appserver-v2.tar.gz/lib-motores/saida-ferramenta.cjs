'use strict';
// lib-motores/saida-ferramenta.cjs — SAIDA DE FERRAMENTA MENOR NOS TRES MOTORES (23/09).
//
// MEDIDO no mestre em 23/09: numa thread retomada do Codex, a saida de ferramenta era 47% da
// entrada (283 KB em 26 saidas) e as 17 chamadas de uma fala subiram de 94 mil para 154 mil
// tokens de entrada cada. O corte 4 (22/09) so encurtava o Codex; o Claude e o motor por API
// ficavam no padrao de cada um. Aqui mora a UMA flag de produto que vale pros tres.
//
// VALOR DA FROTA (2.6.8, 23/09, pedido do dono): LEON_SAIDA_FERRAMENTA_TOKENS AUSENTE (ou vazia)
// = 4400 (LIGADA). O padrao mora aqui no codigo porque o .env do cliente nunca e reescrito pelo
// /atualiza: so o padrao chega na frota. "=0" desliga (padrao de cada motor, e com 0 nada muda:
// args, env e config.toml saem byte a byte iguais aos da 2.6.7). LEON_CODEX_SAIDA_FERRAMENTA
// (22/09) segue aceita como SINONIMO: vale quando a de produto esta ausente (e "=0" nela tambem
// desliga); quando as duas vierem, vale a de produto, inclusive o "0".
//
// Onde o limite entra, por motor (o mecanismo difere, o numero e um so):
//   - Codex (lib-motores/codex-appserver.cjs): `-c tool_output_token_limit=N` no nascimento do
//     app-server, cabeca e folha. Unidade: tokens.
//   - Motor por API (lib-motores/provedor-api.cjs): o mesmo `-c` (nasce pelo chassi Codex) E a
//     linha `tool_output_token_limit = N` no config.toml da casa propria (CODEX_HOME do provedor),
//     pra config gerada e argv dizerem a mesma coisa.
//   - Claude (lib-motores/claude.cjs): env do filho MAX_MCP_OUTPUT_TOKENS=N (tokens) e
//     BASH_MAX_OUTPUT_LENGTH=N*4 (caracteres), mais `--settings {"bashOutputMaxChars":N*4}`.
//     Nomes conferidos no binario instalado (@anthropic-ai/claude-code 2.1.280, grep no claude.exe):
//     nessa versao BASH_MAX_OUTPUT_LENGTH sozinho so dimensiona a janela de releitura; quem corta
//     a saida INLINE do Bash e a chave de settings bashOutputMaxChars (padrao 30000, o CLI prende
//     entre 4000 e 128000). Por isso vao os dois.
//
// CONVERSAO tokens -> caracteres: 4 caracteres por token (CARACTERES_POR_TOKEN), a mesma
// estimativa do molde claw (src/agents/tool-result-limits.ts:31 `maxChars = maxTokens * 4`;
// src/agents/agent-tools.read.ts:80 CHARS_PER_TOKEN_ESTIMATE = 4), que tambem aplica UM teto de
// resultado de ferramenta a todo provedor. Piso: valor ligado abaixo de 500 tokens sobe pra 500.
// Mudar exige restart (args e env sao do nascimento do processo).
//
// SEM ESTADO, SEM DISCO: funcoes puras sobre o envSource.

const FLAG = 'LEON_SAIDA_FERRAMENTA_TOKENS';
const SINONIMO_CODEX = 'LEON_CODEX_SAIDA_FERRAMENTA';
const SAIDA_FERRAMENTA_PISO = 500;
const CARACTERES_POR_TOKEN = 4;
const SAIDA_FERRAMENTA_PADRAO_FROTA = 4400;

// Parser das flags de tokens (nasceu em codex-appserver.cjs no corte 1/4 de 22/09): so digitos,
// inteiro seguro e positivo, senao 0 (desligado); ligado sobe ao piso. `padrao` (2.6.8, da linha
// do mestre: LEON_CODEX_COMPACTA_EM nasce 150000 na frota) vale so quando a chave esta AUSENTE ou
// vazia; "0" explicito desliga. Sem `padrao`, igual ao parser de 22/09.
function flagTokens(envSource, nome, piso, padrao = 0) {
  const cru = envSource ? envSource[nome] : undefined;
  const bruto = (cru == null || String(cru).trim() === '') ? String(padrao) : String(cru).trim();
  if (!/^\d+$/.test(bruto)) return 0;
  const n = Number(bruto);
  if (!Number.isSafeInteger(n) || n <= 0) return 0;
  return Math.max(n, piso);
}

function _presente(envSource, nome) {
  const v = envSource ? envSource[nome] : undefined;
  return v != null && String(v).trim() !== '';
}

// Ordem: a de produto escrita decide (0 desliga); senao o sinonimo escrito decide (0 desliga);
// senao o padrao da frota (4400).
function saidaFerramentaTokens(envSource = process.env) {
  if (_presente(envSource, FLAG)) return flagTokens(envSource, FLAG, SAIDA_FERRAMENTA_PISO);
  if (_presente(envSource, SINONIMO_CODEX)) return flagTokens(envSource, SINONIMO_CODEX, SAIDA_FERRAMENTA_PISO);
  return flagTokens(envSource, FLAG, SAIDA_FERRAMENTA_PISO, SAIDA_FERRAMENTA_PADRAO_FROTA);
}

function saidaFerramentaCaracteres(envSource = process.env) {
  return saidaFerramentaTokens(envSource) * CARACTERES_POR_TOKEN;
}

// Claude: variaveis do filho. Vazio com a flag desligada.
function envClaudeSaida(envSource = process.env) {
  const tokens = saidaFerramentaTokens(envSource);
  if (!tokens) return {};
  return {
    MAX_MCP_OUTPUT_TOKENS: String(tokens),
    BASH_MAX_OUTPUT_LENGTH: String(tokens * CARACTERES_POR_TOKEN),
  };
}

// Claude: args do turno. Vazio com a flag desligada.
function argsClaudeSaida(envSource = process.env) {
  const chars = saidaFerramentaCaracteres(envSource);
  if (!chars) return [];
  return ['--settings', JSON.stringify({ bashOutputMaxChars: chars })];
}

// Chassi Codex (nativo e API): o `-c` do nascimento do app-server.
function argsCodexSaida(envSource = process.env) {
  const tokens = saidaFerramentaTokens(envSource);
  return tokens ? ['-c', `tool_output_token_limit=${tokens}`] : [];
}

// Motor por API: a linha do config.toml gerado. Chave de topo (antes de qualquer tabela).
function linhasTomlSaida(envSource = process.env) {
  const tokens = saidaFerramentaTokens(envSource);
  return tokens ? [`tool_output_token_limit = ${tokens}`] : [];
}

module.exports = {
  FLAG,
  SINONIMO_CODEX,
  SAIDA_FERRAMENTA_PISO,
  SAIDA_FERRAMENTA_PADRAO_FROTA,
  CARACTERES_POR_TOKEN,
  flagTokens,
  saidaFerramentaTokens,
  saidaFerramentaCaracteres,
  envClaudeSaida,
  argsClaudeSaida,
  argsCodexSaida,
  linhasTomlSaida,
};
