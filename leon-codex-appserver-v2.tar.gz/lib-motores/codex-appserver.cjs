'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');

const {
  CodexAppServerAdapter,
  TurnTimeoutError,
  RpcTimeoutError,
} = require('../appserver/adapter.cjs');
// O MOTOR VÊ A IMAGEM (21/09): régua única dos anexos, compartilhada com o motor Claude.
const { anexosDeImagem } = require('./anexos.cjs');
const { criaContadorTeto } = require('./teto-chamadas.cjs');
const saidaFerramenta = require('./saida-ferramenta.cjs');
// P30 (23/09): aprovacao de acao perigosa. Require protegido: sem o modulo, turno que pede a
// trava e recusado (nunca roda sem ela) e o turno comum segue igual.
let APROVACAO = null;
try { APROVACAO = require('../lib/aprovacao-perigosa.cjs'); } catch { APROVACAO = null; }
// O app-server espera a resposta do pedido de aprovacao; o dono tem o prazo inteiro pra tocar no
// botao, mais folga pra a recusa por prazo sair do nosso lado (e nao por timeout do RPC).
const PRAZO_PEDIDO_SERVIDOR_MS = (APROVACAO ? APROVACAO.PRAZO_PADRAO_MS : 0) + 60_000;
const { flagTokens } = saidaFerramenta;

const SEP_FALA = '===== FALA DO DONO =====';
const DEFAULT_TIMEOUT_MS = numberFromEnv('CODEX_TIMEOUT_SEG', 240) * 1_000;
const WORKER_CAPABILITIES = Object.freeze(['web_search', 'image_generation']);
// A2 (21/09/2026): a lista de segredos que o app-server de FOLHA aceita deixou de ser literal.
// Antes era ['OPENAI_API_KEY','DEEPSEEK_API_KEY'] cravado: provedor novo na tabela subia na
// cabeça e morria calado na folha, porque a chave dele era filtrada aqui. Agora a chave de cada
// provedor de config/provedores.json entra sozinha (é assim que a XAI_API_KEY chega, A6). A
// OPENAI_API_KEY continua fixa por ser a do motor nativo, que não mora na tabela.
const LEAF_ALLOWED_SECRET_ENV = Object.freeze([...new Set([
  'OPENAI_API_KEY',
  ...require('./provedores-tabela.cjs').variaveisDeChave(),
])]);
const LEAF_PROFILE_IDS = Object.freeze({
  worker: 'leon-worker',
  planner: 'leon-planner',
  reviewer: 'leon-reviewer',
  coordinator: 'leon-coordinator',
});
const LEAF_CREDENTIAL_DENIES = Object.freeze({
  '.env': 'deny',
  '*.env': 'deny',
  '**/*.env': 'deny',
  '**/auth.json': 'deny',
  '**/*credentials*.json': 'deny',
});

// 17/09 (provado dentro do namespace, nas duas topologias): o bwrap morria no
// execvp do proprio helper nativo do Codex, porque o diretorio onde o executavel
// vive nunca entrava no namespace da folha. O envelope so recebe as raizes privadas
// do job (LEON_WORK_AREA/leon-jobs/<id>/<frente>) e o binario mora fora delas:
// o prefixo global do npm no mestre (~/.npm-global), ~/.leon/codex-cli/releases/<v>
// na casa de cliente. Consequencia medida: TODA frente morria antes de abrir arquivo, o revisor
// lia "a leitura dos arquivos falhou" e reprovava 3 rodadas; o dono ficou 2 dias sem
// nenhum trabalho concluir. E READ, nunca raiz de escrita: como raiz, o perfil do
// worker daria escrita e a folha poderia gravar no proprio motor.
function codexInstallPrefix() {
  try {
    const bin = resolveCodexBin(process.env || {});
    if (!bin) return "";
    return path.dirname(path.dirname(bin));
  } catch { return ""; }
}

function leafFilesystem(workspaceMode = null) {
  const filesystem = {
    ':root': 'deny',
    ':minimal': 'read',
    glob_scan_max_depth: 4,
  };
  const _prefixoCodex = codexInstallPrefix();
  if (_prefixoCodex) filesystem[`${_prefixoCodex}/**`] = 'read';
  if (workspaceMode) {
    filesystem[':workspace_roots'] = Object.freeze({
      './**': workspaceMode,
      ...LEAF_CREDENTIAL_DENIES,
    });
  }
  return Object.freeze(filesystem);
}

function leafProfile(description, workspaceMode = null) {
  return Object.freeze({
    description,
    filesystem: leafFilesystem(workspaceMode),
    network: Object.freeze({ enabled: false }),
  });
}

// Fonte unica dos perfis: o mesmo objeto gera o TOML de boot, alimenta o
// envelope auditavel e e inspecionado pelo preflight do instalador.
const LEAF_PERMISSION_PROFILE_DEFINITIONS = Object.freeze({
  [LEAF_PROFILE_IDS.worker]: leafProfile('LEON worker: private job roots only', 'write'),
  [LEAF_PROFILE_IDS.planner]: leafProfile('LEON planner: isolated snapshot only', 'read'),
  [LEAF_PROFILE_IDS.reviewer]: leafProfile('LEON reviewer: immutable snapshots only', 'read'),
  [LEAF_PROFILE_IDS.coordinator]: leafProfile('LEON coordinator: no workspace and no network'),
});

function inlineToml(value) {
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))) return String(value);
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return `{${Object.entries(value).map(([key, item]) => `${JSON.stringify(key)}=${inlineToml(item)}`).join(',')}}`;
  }
  throw new TypeError('valor nao suportado no TOML inline de permissoes');
}
// Perfis nomeados precisam existir quando o app-server nasce. Defini-los em
// `thread/start.config` parece válido no JSON, mas o resolvedor de permissões já
// fechou seu catálogo nessa altura; a thread fica sem tools. Os roots concretos
// continuam dinâmicos em `runtimeWorkspaceRoots`, enquanto estes quatro perfis
// estáticos determinam o tipo de acesso dentro deles.
const LEAF_PERMISSION_PROFILES_TOML = `permissions=${inlineToml(LEAF_PERMISSION_PROFILE_DEFINITIONS)}`;
// Folhas usam um segundo app-server. Estes overrides mordem no BOOT do
// processo, antes de existir thread, para que MCPs/plugins/hooks da cabeca nem
// entrem no catalogo da folha. Web e imagem continuam disponiveis no binario,
// mas so sao concedidos por thread em `threadConfigFor`.
const LEAF_APP_SERVER_CONFIG_ARGS = Object.freeze([
  '--strict-config',
  '-c', 'default_permissions="leon-coordinator"',
  '-c', LEAF_PERMISSION_PROFILES_TOML,
  '-c', 'mcp_servers={}',
  '-c', 'apps={}',
  '-c', 'plugins={}',
  '-c', 'hooks={}',
  '-c', 'marketplaces={}',
  '--disable', 'apps',
  '--disable', 'hooks',
  '--disable', 'multi_agent',
  '--disable', 'multi_agent_v2',
  '--disable', 'plugins',
  '--disable', 'remote_plugin',
  '--disable', 'skill_mcp_dependency_install',
  '--disable', 'skill_search',
  '--disable', 'memories',
  '--disable', 'goals',
  '--disable', 'recommended_plugins',
  '--disable', 'browser_use',
  '--disable', 'browser_use_external',
  '--disable', 'browser_use_full_cdp_access',
  '--disable', 'computer_use',
  '-c', 'allow_login_shell=false',
]);
// CORTES 1 e 4 DO LEON ECONOMICO (22/09; fixos em 25/09). Duas chaves do proprio Codex, conferidas
// no binario (codex-cli 0.154.0 aceita as duas com `-c`): model_auto_compact_token_limit e
// tool_output_token_limit. Entram como `-c` no NASCIMENTO do app-server, cabeca e folha, casa
// nativa e casa por API. 25/09: uma janela so pra dono e cliente. A compactacao nativa e fixa em
// 150 mil (o valor que a frota ja roda e passou na bateria; o Codex volta a uns 55 mil depois de
// compactar) e nao le mais LEON_CODEX_COMPACTA_EM (chave morta aceita). A saida de ferramenta mora
// em lib-motores/saida-ferramenta.cjs. Mudar exige restart (args sao do nascimento do processo).
const COMPACTA_EM_TOKENS = 150_000;
function compactaEmTokens() {
  return COMPACTA_EM_TOKENS;
}
function saidaFerramentaTokens() {
  return saidaFerramenta.saidaFerramentaTokens();
}
function economiaConfigArgs() {
  return ['-c', `model_auto_compact_token_limit=${COMPACTA_EM_TOKENS}`, ...saidaFerramenta.argsCodexSaida()];
}
// Compactacao no meio do turno: o protocolo v2 manda o item `contextCompaction` (item/started e
// item/completed; o rollout grava "type":"compacted"), e versoes antigas mandavam a notificacao
// `thread/compacted`. O 0.154.0 pode mandar as duas pra MESMA compactacao, entao o contador
// separa as fontes: devolve 'item' (so o fim, item/completed), 'legado' ou ''. No turno, o total
// usa os itens quando algum chegou e so cai no legado quando nenhum item veio (contaCompactacoes).
function ehCompactacao(n) {
  if (!n || typeof n.method !== 'string') return '';
  if (n.method === 'thread/compacted') return 'legado';
  if (n.method !== 'item/completed') return '';
  const item = n.params && n.params.item;
  return item && item.type === 'contextCompaction' ? 'item' : '';
}
function contaCompactacoes(contagem) {
  const itens = Number(contagem && contagem.item) || 0;
  return itens > 0 ? itens : (Number(contagem && contagem.legado) || 0);
}
// DOSSIE DEPOIS DA COMPACTACAO (23/09). O adapter guarda, por thread carregada, o hash da base e do
// delta que ja foram pra historia, e so reenvia o que mudou. A compactacao (a do motor, avisada pelo
// item contextCompaction ou por thread/compacted, e a que a casa marca e pede com dossieForcaBase)
// troca a historia por um resumo opaco: os itens de base (nucleo, leis-mae, cofre, skills canonicas)
// e de delta podem ter saido junto. Antes, o hash guardado continuava igual e a chamada seguinte
// nao mandava nada: o LEON seguia a conversa sem as leis. Agora a compactacao troca o estado da
// thread por esta marca, e a proxima chamada leva base e delta inteiros UMA vez (depois de o
// app-server aceitar, o estado volta ao hash normal e nada se repete). A marca so substitui estado
// que existe: thread que nao estava no mapa segue pela retomada a frio, que ja leva tudo.
// 25/09: DESLIGADO FIXO. O rollout do mestre (2026-09-24T20-14-20, item compacted de 03:51:26Z)
// mostra a base do dossie (73 KB) inteira no replacement_history: o Codex guarda a mensagem
// developer na compactacao, e reenviar custou 15 bases extras em 68 threads de 24 e 25/09. A base
// volta so quando o HASH muda. LEON_DOSSIE_POS_COMPACTA vira chave morta aceita.
const DOSSIE_COMPACTADO = Object.freeze({ mode: 'compactado' });
function dossiePosCompactaLigado() {
  return false;
}
function marcaDossieCompactado(states, key) {
  if (!states || !states.has(key)) return false;
  states.set(key, DOSSIE_COMPACTADO);
  return true;
}
// Secret-looking variables are opt-in. The Google MCP bridge can pass
// ['GOG_KEYRING_PASSWORD', 'GOG_ACCOUNT'] when it deliberately needs them.
// A instalação vendável aceita OAuth em CODEX_HOME ou chave fornecida pelo
// próprio cliente. A chave entra somente no processo do motor, nunca no worker
// como dado de prompt nem nas integrações do agente.
const capacidades = Object.freeze({
  promptSistemaSeparado: true,
  // O adapter acompanha hashes independentes da base e do estado vivo. O bridge
  // pode, portanto, mandar o contrato incremental sem depender do nome do motor.
  dossieIncremental: true,
  retomaSessao: true,
  tetoCustoNativo: false,
  reportaCusto: false,
  saidaEstruturada: true,
  controlePermissao: true,
  modeloSelecionavel: true,
  effort: true,
  diretoriosExtras: true,
  compactacaoNativa: false,
  // ORQUESTRA (5-C): o app-server do Codex NÃO restringe a caixa de ferramenta
  // por turno — só aplica sandboxPolicy de acesso a disco/rede. Estreitar o
  // toolsAllow de 54 pra 1 mata o turno (C09, 03-problemas-reproduzidos.md:627).
  // Por isso declara false, e o gate fail-closed recusa subir o subagente aqui:
  // "esse ajudante só liga no motor Claude por enquanto".
  restringeFerramentas: false,
  // AJUDANTES (23/09, paridade por capacidade): o que ele NAO faz por nome de ferramenta ele
  // faz pelo SO. A folha (workerLeaf) roda num perfil de permissao do app-server que grava so
  // nas raizes declaradas, le so nas raizes declaradas, sem rede, sem MCP e sem segredo no
  // ambiente do shell (leafPermissionEnvelopeFor + threadConfigFor abaixo). E isso que deixa
  // o ajudante do Codex (e do motor por API, que herda estas capacidades) rodar com o mesmo
  // envelope do Claude, em vez de o gate recusar a sala inteira.
  folhaIsolada: true,
  // O corte do turno aqui e o RPC `turn/interrupt`: ele mata o TURNO e deixa a THREAD
  // valida no app-server. Por isso o /para pode PRESERVAR o sid (a conversa continua).
  cancelaPreservandoSessao: true,
  // STEER (23/09, LEON_STEER no bridge): a fala nova do dono entra no turno VIVO pelo RPC
  // `turn/steer {threadId, expectedTurnId, input}` do app-server (schema do codex-cli 0.154.0,
  // v2/TurnSteerParams.json; molde molde claw extensions/codex/src/app-server/attempt-steering.ts:195-201).
  // Quem escolhe a fronteira segura e o scheduler do app-server (queue-steering.md:28).
  guiaTurnoVivo: true,
});

function createMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const motorName = stringOrNull(options.nomeMotor) || 'codex';
  // O rótulo vem de quem criou o motor (o adaptador genérico passa o da linha da tabela); sem
  // ele, é Codex, que é o dono deste chassi.
  const motorLabel = stringOrNull(options.rotuloMotor) || (motorName === 'codex' ? 'Codex' : motorName);
  const command = options.command || resolveCodexBin(envSource);
  const adapterOptions = options.adapterOptions || {};
  const fixedAdapter = options.adapter || null;
  const fixedLeafAdapter = options.leafAdapter || null;
  let adapter = fixedAdapter;
  let leafAdapter = fixedLeafAdapter;
  let adapterGeneration = null;
  let leafAdapterGeneration = null;
  const threadStates = new Map();
  const leafThreadStates = new Map();
  const sessionLocks = new Map();
  const sessionsInUse = new Set();
  const activeTurns = new Map();
  const maxTrackedThreads = intOption(options.maxTrackedThreads, 64);
  let adapterComRateListener = null;
  let adapterComCicloListener = null;
  // P30: threadId -> { ctx, cancelado } enquanto o turno com aprovacao esta vivo. A thread que
  // ja recebeu "untrusted" neste processo fica em `threadsVigiadas` pra o turno seguinte sem a
  // trava devolver "never" explicito (a policy da thread gruda no app-server).
  const aprovacoesPorThread = new Map();
  const threadsVigiadas = new Set();
  function atendePedidoDoServidor(req) {
    const metodo = String((req && req.method) || '');
    if (!APROVACAO || !APROVACAO.METODOS_CODEX.has(metodo)) {
      const erro = new Error(`Client does not implement ${metodo}`);
      erro.rpcCode = -32601;
      throw erro;
    }
    const p = (req && req.params) || {};
    const threadId = stringOrNull(p.threadId) || stringOrNull(p.conversationId);
    const reg = threadId ? aprovacoesPorThread.get(threadId) : null;
    const legado = metodo === 'execCommandApproval' || metodo === 'applyPatchApproval';
    // Sem turno com trava nesta thread: e o "never" de sempre, tudo roda. Elicitation sem trava
    // continua sem cliente que a atenda (-32601), como antes.
    if (!reg) {
      if (metodo === 'mcpServer/elicitation/request') {
        const erro = new Error(`Client does not implement ${metodo}`);
        erro.rpcCode = -32601;
        throw erro;
      }
      return legado ? { decision: 'approved' } : { decision: 'accept' };
    }
    return APROVACAO.respondeCodex(req, reg.ctx, {
      cancelado: () => reg.cancelado,
      // O pedido v2 de patch so traz o itemId; os caminhos vieram no item/started do fileChange.
      mudancas: (itemId) => reg.mudancas.get(itemId) || [],
    });
  }
  const sourceCodexHome = resolveSourceCodexHome(options, envSource);
  const leafCodexHome = resolveLeafCodexHome(options, envSource, sourceCodexHome);

  function makeAdapter(restricted) {
    const baseArgs = Array.isArray(adapterOptions.args)
      ? adapterOptions.args.map(String) : ['app-server'];
    const economia = economiaConfigArgs(envSource);
    const processArgs = restricted
      ? [...baseArgs, ...LEAF_APP_SERVER_CONFIG_ARGS, ...economia]
      : [...baseArgs, ...economia];
    const headOnlyEnv = restricted ? {} : {
      // A folha nunca recebe o token de MCP nem o caminho do cofre. A cabeca
      // preserva exatamente o comportamento historico.
      ...(envSource.META_MCP_TOKEN ? { META_MCP_TOKEN: envSource.META_MCP_TOKEN } : {}),
      ...(envSource.LEON_ENV_FILE ? { LEON_ENV_FILE: envSource.LEON_ENV_FILE } : {}),
    };
    if (restricted) ensureLeafCodexHome(leafCodexHome, sourceCodexHome);
    const effectiveEnvSource = restricted
      ? omitEnv(envSource, ['LEON_ENV_FILE', 'META_MCP_TOKEN'])
      : envSource;
    const adapterEnv = { ...(adapterOptions.env || {}) };
    if (restricted) {
      delete adapterEnv.LEON_ENV_FILE;
      delete adapterEnv.META_MCP_TOKEN;
    }
    const configuredSecrets = Array.isArray(options.allowedSecretEnv)
      ? [...new Set(options.allowedSecretEnv.map(String))]
      : [];
    const allowedSecretEnv = restricted
      ? configuredSecrets.filter((name) => LEAF_ALLOWED_SECRET_ENV.includes(name))
      : configuredSecrets;
    return new CodexAppServerAdapter({
      command,
      cwd: options.processCwd || process.cwd(),
      envSource: effectiveEnvSource,
      // TETO DE MENSAGEM DO PROTOCOLO (cura 10/09): o default de 1MB do adapter matava turnos
      // quando o Codex emitia UMA linha de evento >1MB (ler/gerar arquivo grande, output de tool
      // gordo) — o dono via "conteúdo demais, me peça como missão" e o trabalho morria. O adapter
      // lê linha a linha em memória; com folga de RAM, 16MB cobre os eventos reais sem risco.
      maxMessageBytes: Number(envSource.CODEX_MAX_MSG_BYTES) || 16 * 1024 * 1024,
      allowedSecretEnv,
      clientInfo: {
        name: restricted ? 'leon_codex_restricted' : 'leon_codex',
        title: restricted ? 'LEON Codex Restricted' : 'LEON Codex',
        version: String(options.version || '1.0.0'),
      },
      requestTimeoutMs: intOption(options.requestTimeoutMs, 15_000),
      turnTimeoutMs: intOption(options.turnTimeoutMs, DEFAULT_TIMEOUT_MS),
      maxBufferedNotifications: intOption(options.maxBufferedNotifications, 256),
      maxBufferedNotificationBytes: intOption(options.maxBufferedNotificationBytes, 1_048_576),
      // Um app-server de folha compartilhado atende o teto fisico de tres
      // workers; nao nasce um processo adicional por frente.
      maxActiveTurns: intOption(options.maxActiveTurns, 16),
      autoRestart: options.autoRestart !== false,
      serverRequestHandler: atendePedidoDoServidor,
      serverRequestTimeoutMs: Math.max(30_000, PRAZO_PEDIDO_SERVIDOR_MS),
      // Um pedido esperando o dono nao pode travar os outros comandos do turno.
      maxServerRequests: 16,
      ...adapterOptions,
      // Depois do spread: testes podem trocar binario/transport, mas nao podem
      // retirar o hardening nem reinjetar segredo no processo de folha.
      args: processArgs,
      envSource: effectiveEnvSource,
      allowedSecretEnv,
      env: {
        ...adapterEnv,
        RUST_LOG: envSource.CODEX_RUST_LOG || 'warn',
        CODEX_HOME: restricted ? leafCodexHome : sourceCodexHome,
        ...headOnlyEnv,
      },
      // excludeTurns on thread/resume is capability-gated in Codex 0.147.0.
      capabilities: {
        ...(adapterOptions.capabilities || {}),
        experimentalApi: true,
      },
    });
  }

  function getAdapter(entrada = {}) {
    const restricted = entrada.workerLeaf === true || entrada.plannerLeaf === true
      || entrada.reviewerLeaf === true || entrada.coordinatorHead === true;
    if (restricted) {
      if (!leafAdapter) leafAdapter = makeAdapter(true);
    } else if (!adapter) {
      adapter = makeAdapter(false);
    }
    const selected = restricted ? leafAdapter : adapter;
    // SALA DE TOKENS (30/08): account/rateLimits/updated tem escopo de CONTA (sem threadId),
    // então o _routeTurnNotification do adapter nunca a entrega no onNotification do turno —
    // ela só sai no emitter global ('notification'). O attach é 1x por instância de adapter:
    // autoRestart preserva o objeto (listener sobrevive); encerrar() anula o adapter e o
    // próximo getAdapter() cria outro e re-anexa. Observador puro: um throw no callback do
    // chamador não pode derrubar o turno.
    //
    // EVENTO NEUTRO DE MOTOR (04/09): quem escuta hoje é `onEventoMotor({tipo:'cota', cota})`,
    // um canal que qualquer motor futuro emite sem o bridge saber de rate limit de app-server.
    // `onRateLimits` continua aceito e recebe o mesmo snapshot: chamador antigo não quebra.
    const querEvento = typeof options.onEventoMotor === 'function' || typeof options.onRateLimits === 'function';
    if (selected !== adapterComRateListener && querEvento && typeof selected.on === 'function') {
      selected.on('notification', (message) => {
        if (!message || message.method !== 'account/rateLimits/updated') return;
        const snapshot = normalizeRateLimits(message.params);
        if (!snapshot) return;
        if (typeof options.onEventoMotor === 'function') {
          try { options.onEventoMotor({ tipo: 'cota', motor: motorName, cota: { ...snapshot, motor: motorName } }); } catch {}
        }
        if (typeof options.onRateLimits === 'function') {
          try { options.onRateLimits(snapshot); } catch {}
        }
      });
      adapterComRateListener = selected;
    }
    // CICLO DE VIDA DO APP-SERVER (11/09): ready/childExit/restartScheduled/restartFailed/retired eram
    // safeEmit SEM listener — por isso o log nunca mostrava crash/religamento e a investigação demorou 2
    // dias (confundimos restart-meu com crash). Só log, não muda comportamento. Off: CODEX_APPSERVER_LOG_CICLO=0.
    if (selected !== adapterComCicloListener && process.env.CODEX_APPSERVER_LOG_CICLO !== '0' && typeof selected.on === 'function') {
      const log = (m) => { try { console.log(`[app-server] ${m}`); } catch {} };
      selected.on('ready', (e) => log(`${restricted ? 'restrito ' : ''}subiu (gen ${e && e.generation}, pid ${e && e.pid})`));
      selected.on('childExit', (e) => log(`${restricted ? 'restrito ' : ''}CAIU inesperado (gen ${e && e.generation}, code=${e && e.code}, signal=${(e && e.signal) || 'none'})`));
      selected.on('restartScheduled', (e) => log(`${restricted ? 'restrito ' : ''}religando em ${e && e.delayMs}ms`));
      selected.on('restartFailed', (err) => log(`${restricted ? 'restrito ' : ''}religar falhou: ${err && err.message}`));
      selected.on('retired', (e) => log(`${restricted ? 'restrito ' : ''}desistiu de religar após ${e && e.crashes} quedas em 60s; o próximo turno sobe processo novo via start()`));
      adapterComCicloListener = selected;
    }
    return selected;
  }

  function syncGeneration(client) {
    const generation = client.status().generation;
    const leaf = client === leafAdapter;
    const states = leaf ? leafThreadStates : threadStates;
    const previous = leaf ? leafAdapterGeneration : adapterGeneration;
    if (previous !== generation) {
      states.clear();
      if (leaf) leafAdapterGeneration = generation;
      else adapterGeneration = generation;
    }
    return generation;
  }

  async function responder(entrada = {}) {
    const requestedSessionId = stringOrNull(entrada.sessaoId);
    const folhaOuCoord = entrada.workerLeaf === true || entrada.plannerLeaf === true
      || entrada.reviewerLeaf === true || entrada.coordinatorHead === true;
    const pedeAprovacao = !folhaOuCoord && entrada.aprovacao && typeof entrada.aprovacao === 'object';
    if (pedeAprovacao && !APROVACAO) {
      return output({ erro: 'aprovação de ação perigosa ligada, mas lib/aprovacao-perigosa.cjs não está no pacote' });
    }
    const aprov = pedeAprovacao ? { ...entrada.aprovacao, motor: entrada.aprovacao.motor || motorName } : null;
    if (entrada.plannerLeaf === true && requestedSessionId) {
      return output({ erro: 'planner leaf nao retoma sessao persistente: turno recusado por seguranca' });
    }
    const lockKey = requestedSessionId ? `session:${requestedSessionId}` : Symbol('new-thread');
    return withLock(sessionLocks, lockKey, async () => {
      let sessionId = requestedSessionId;
      let threadJaCarregada = false;
      let client = null;
      let generation = null;
      let states = null;
      // CORTE 0: o uso do turno e o veredito do freio moram FORA do try, pra o catch devolver
      // o custo do laco quando o turno cai por timeout, idle ou morte do app-server (turno que
      // morre tambem gastou, e o laco longo de missao e justamente o que cai assim).
      const usoTurno = novoUsoTurno();
      let freioTurno = null;
      if (sessionId) sessionsInUse.add(sessionId);
      // Nasce FORA do try: turno que compacta e depois morre por timeout, idle-timeout ou erro do
      // adapter rejeita a completion e cai no catch; a contagem tem que chegar la tambem.
      const contagemCompactacao = { item: 0, legado: 0 };
      // ENVELOPE ENXUTO (d): bytes de doutrina/dossie que ESTE turno de fato pos na thread (inicio
      // da thread, retomada a frio, item de mudanca na thread carregada). Conta so depois de o
      // app-server aceitar; base = base estavel (ou o dossie legado inteiro), delta = estado
      // dinamico com a politica curta. Mora fora do try pelo mesmo motivo do uso do turno.
      const dossieInjetado = { base: 0, delta: 0 };
      let contaInjetado = () => {};
      try {
        client = getAdapter(entrada);
        await client.start();
        generation = syncGeneration(client);
        states = client === leafAdapter ? leafThreadStates : threadStates;
        const cwd = effectiveCwd(entrada, envSource);
        const dossier = normalizeDossierInput(entrada);
        contaInjetado = (items) => {
          for (const item of items) {
            const bytes = Buffer.byteLength(itemText(item), 'utf8');
            if (dossier.mode === 'split' && item === dossier.deltaItem) dossieInjetado.delta += bytes;
            else dossieInjetado.base += bytes;
          }
        };
        const model = stringOrNull(entrada.modelo);
        // A cabeca continua com o acesso historico. Folhas nunca herdam a
        // maquina inteira so porque usam o mesmo app-server: worker recebe
        // workspaceWrite sem rede; planejador recebe readOnly sem rede e uma
        // configuracao que desliga integracoes/fan-out. A politica morde no
        // protocolo tanto no nascimento quanto em cada turno.
        const leafEnvelope = leafPermissionEnvelopeFor(entrada, cwd, {
          sourceCodexHome,
          leafCodexHome,
          envFile: envSource.LEON_ENV_FILE,
          protectedReadPaths: options.protectedReadPaths,
        });
        const sandboxPolicy = leafEnvelope ? undefined : sandboxPolicyFor(entrada, cwd);
        const threadConfig = threadConfigFor(entrada, options.threadConfig, leafEnvelope);
        // ACESSO TOTAL (04/09, decisao do dono): o cliente roda EXATAMENTE como o motor
        // mestre, sem sandbox. Provado no 99: o perfil de permissoes nomeado
        // (default_permissions) mantem o isolamento ligado mesmo sob
        // sandbox_mode = "danger-full-access" e o Codex morre em
        // "bwrap: setting up uid map: Permission denied". Por isso o perfil saiu do config
        // e daqui, e o turno declara sandboxPolicy de acesso total.
        // dangerFullAccess e variante unitaria do enum SandboxPolicy do app-server
        // (Codex 0.147.0): { type: 'dangerFullAccess' }, sem campos.
        const threadParams = compactObject({
          cwd,
          developerInstructions: comColaboracaoPadrao(dossier.developerInstructions, entrada),
          model,
          // P30: com a trava, o app-server pergunta ao cliente antes de todo comando que nao
          // esta na lista segura dele; o handler libera o comum na hora e so o perigoso vai ao dono.
          approvalPolicy: aprov ? 'untrusted' : (options.approvalPolicy || 'never'),
          config: threadConfig,
          sandboxPolicy,
          permissions: leafEnvelope?.profileId,
          runtimeWorkspaceRoots: leafEnvelope?.runtimeWorkspaceRoots,
          // Planejamento e uma chamada descartavel. A SID continua existindo
          // enquanto o turno esta vivo (onSessao + /para), mas nao deixa uma
          // conversa persistente capaz de ser retomada sob outro perfil.
          ephemeral: entrada.plannerLeaf === true ? true : (sessionId ? undefined : false),
        });

        if (sessionId) {
          const loadedKey = `${generation}\u0000${sessionId}`;
          // ENVELOPE ENXUTO (23/09): a casa afirma, por sid, que esta thread ja tem ESTA base na
          // historia (bridge.cjs payloadDossieDoMotor, registro em disco). So vale pra retomada a
          // frio do MESMO sid e no contrato split; sem a afirmacao, igual a antes.
          const baseJaNaThread = dossier.mode === 'split'
            && typeof entrada.dossieBaseNaThread === 'string'
            && entrada.dossieBaseNaThread === sessionId;
          if (!states.has(loadedKey)) {
            logaThreadStart(threadParams, entrada.origem, true, motorName);
            const resumed = await client.resumeThread(sessionId, {
              ...threadParams,
              // The bridge needs only the durable id. Returning all turns can
              // make one JSONL response exceed the adapter's safety cap on a
              // long or image-heavy conversation.
              excludeTurns: true,
            }, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            if (sessionId !== resumed.threadId) {
              sessionsInUse.delete(sessionId);
              sessionsInUse.add(resumed.threadId);
            }
            sessionId = resumed.threadId;
            const resumedKey = `${generation}\u0000${sessionId}`;
            // Also inject on a cold resume. Codex 0.147.0 accepts the plain
            // resume override but can omit it from the first resumed model
            // request; the persisted developer item closes that gap.
            const itensFrio = baseJaNaThread ? [dossier.deltaItem] : dossier.coldResumeItems;
            await client.injectItems(sessionId, itensFrio, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            contaInjetado(itensFrio);
            rememberThread(states, resumedKey, dossier.state);
          } else {
            touchThread(states, loadedKey);
          }
        } else {
          logaThreadStart(threadParams, entrada.origem, false, motorName);
          const started = await client.startThread(threadParams, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          sessionId = started.threadId;
          sessionsInUse.add(sessionId);
          // a thread nasce com developerInstructions = base + delta (ou o dossie legado)
          if (threadParams.developerInstructions) {
            contaInjetado(dossier.mode === 'split' ? [dossier.baseItem, dossier.deltaItem] : dossier.coldResumeItems);
          }
          const startedKey = `${generation}\u0000${sessionId}`;
          rememberThread(states, startedKey, dossier.state);
        }

        // Codex 0.147.0 ignores thread/resume overrides for an already-loaded
        // thread. Append a developer item only when LEON's dynamic dossier
        // changes, so the next model request sees the new revision without
        // copying a large system prompt into every user message.
        const dossierKey = `${generation}\u0000${sessionId}`;
        const previousDossierState = states.get(dossierKey);
        const changedItems = changedDossierItems(previousDossierState, dossier);
        if (previousDossierState !== undefined && changedItems.length > 0) {
          await client.injectItems(sessionId, changedItems, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          contaInjetado(changedItems);
          // Never acknowledge a revision before the app-server persisted all
          // corresponding developer items. A failed injection is retried on
          // the next turn with the old hashes still intact.
          rememberThread(states, dossierKey, dossier.state);
        }

        const timeoutMs = timeoutFor(entrada);
        const input = buildUserInput(entrada);
        const turnParams = compactObject({
          threadId: sessionId,
          input,
          cwd,
          model,
          effort: stringOrNull(entrada.effort),
          // Codex 0.154 não possui `config` em TurnStartParams. Enviar o nome
          // de permissions outra vez faz o servidor tentar resolvê-lo fora da
          // tabela da thread e recusar com -32600. Perfis restritos ficam
          // vinculados em thread/start ou thread/resume (config + permissions
          // + runtimeWorkspaceRoots) e o turn/start herda essa policy. O head
          // legado continua repetindo apenas seu sandboxPolicy histórico.
          sandboxPolicy,
          // P30: a policy da thread gruda no app-server (thread ja carregada ignora a do resume),
          // entao o turno repete a dele. Sem a trava e sem historico de "untrusted" neste
          // processo, o campo nao vai e o turn/start sai byte a byte igual ao de antes.
          approvalPolicy: aprov ? 'untrusted'
            : (threadsVigiadas.has(sessionId) ? (options.approvalPolicy || 'never') : undefined),
        });
        if (aprov) {
          aprovacoesPorThread.set(sessionId, { ctx: aprov, cancelado: false, mudancas: new Map() });
          threadsVigiadas.add(sessionId);
        } else {
          threadsVigiadas.delete(sessionId);
        }
        // CONSERTO DO ctxTokens (30/08): thread/tokenUsage/updated chega COM threadId+turnId,
        // então o adapter já a roteia pro onNotification deste turno. Guarda o último
        // tokenUsage e o output() devolve o total real no lugar do null histórico — o
        // persistSession do bridge passa a gravar número de verdade sem mudança de encanamento.
        let ultimoTokenUsage = null;
        // CORTE 0 (22/09): o USO DO TURNO INTEIRO. `ultimoTokenUsage` acima continua sendo a
        // ULTIMA chamada (o teto de thread precisa do tamanho da janela, e isso e o `last`). Mas
        // um turno do app-server e um LACO de N chamadas ao modelo, e o freio de custo so via a
        // ultima: medido, uma fala de 476 chamadas contava ~150 mil e gastou 68 milhoes. Aqui
        // soma-se o turno inteiro (diferenca do `total` da thread desde o inicio do turno) e,
        // A CADA notificacao, o bridge e consultado: passou do teto, o proprio motor corta.
        const onUsoTurno = typeof entrada.onUsoTurno === 'function' ? entrada.onUsoTurno : null;
        let handleTurno = null;
        let pararPendente = false;
        // Estado do turn/interrupt: `interrompendo` = pedido em voo (nao empilha outro);
        // `interrompido` = o app-server deu ACK (nao repete). Se o interrupt FALHAR (ACK que
        // estoura interruptTimeoutMs, erro de RPC), a proxima notificacao tenta de novo, no
        // maximo 1 vez por notificacao, sem perguntar ao bridge: o veredito ja foi dado.
        let interrompendo = false;
        let interrompido = false;
        const cortaPeloFreio = () => {
          if (interrompido || interrompendo) return;
          if (handleTurno && typeof handleTurno.interrupt === 'function') {
            interrompendo = true;
            Promise.resolve().then(() => handleTurno.interrupt()).then(
              () => { interrompendo = false; interrompido = true; },
              () => { interrompendo = false; },
            );
          } else {
            pararPendente = true;
          }
        };
        const onEventoExterno = typeof entrada.onEvento === 'function' ? entrada.onEvento : null;
        // CORTE 2 (22/09): teto de chamadas por fala. A contagem mora em teto-chamadas.cjs
        // (funcao pura, isolada) e aqui so se escuta e se corta: `tetoNaEscuta` e o unico ponto
        // de contato, pra o corte 0 poder unir a propria escuta a esta sem conflito.
        // SO O BRIDGE LIGA, fala por fala (entrada.tetoChamadas). Sem campo = desligado, nunca
        // cai no process.env: frente, handoff, revisor e persona chamam o motor direto e nao
        // podem ser cortadas sem o fecho "Sigo?" que so o caminho da fala escreve.
        // UNIAO COM O CORTE 0 (rodada 22/09): uma escuta so, um handle so (`handleTurno`) e um
        // interrupt so (`cortaPeloFreio`, com os estados interrompendo/interrompido). O freio
        // olha primeiro, o teto depois; quem estourar primeiro corta e o outro nao empilha
        // segundo interrupt. O return do teto leva `usoTurno` e `freio` como as outras saidas,
        // pra o orcamento receber o custo do turno cortado uma vez so.
        const contadorTeto = criaContadorTeto(entrada.tetoChamadas);
        let tetoCortou = false;
        const tetoNaEscuta = (n) => {
          if (!contadorTeto.ligado) return;
          const r = contadorTeto.registra(n);
          if (!r.agora) return;
          tetoCortou = true;
          cortaPeloFreio();
        };
        const onNotificationTurno = (n) => {
          try {
            // Freio ja deu veredito e o laco segue mandando evento: o interrupt anterior falhou
            // (ou ainda nao tinha handle). Tenta de novo, 1 vez por notificacao, sem o bridge.
            if (freioTurno || tetoCortou) cortaPeloFreio();
            if (n && n.method === 'thread/tokenUsage/updated' && n.params && n.params.tokenUsage) {
              ultimoTokenUsage = n.params.tokenUsage;
              const contou = acumulaUsoTurno(usoTurno, n.params.tokenUsage);
              if (contou && onUsoTurno && !freioTurno) {
                let r = null;
                try { r = onUsoTurno(publicoUsoTurno(usoTurno)); } catch {}
                if (r && r.parar) {
                  freioTurno = { ...(r.veredito && typeof r.veredito === 'object' ? r.veredito : {}), chamada: usoTurno.chamadas };
                  cortaPeloFreio();
                }
              }
            }
          } catch {}
          // Compactacao do motor em escuta propria: erro no freio nao pode apagar a contagem.
          try {
            const fonte = ehCompactacao(n);
            if (fonte) contagemCompactacao[fonte] += 1;
          } catch {}
          try { tetoNaEscuta(n); } catch {}
          // P30: guarda os caminhos de cada patch (item/started e patchUpdated do fileChange) pra o
          // pedido de aprovacao do patch, que so traz o itemId, passar pela regua do Write/Edit.
          try {
            const regA = aprovacoesPorThread.get(sessionId);
            const pn = regA && n && n.params;
            if (pn) {
              const it = pn.item && pn.item.type === 'fileChange' ? pn.item : null;
              const itemId = it ? it.id : (n.method === 'item/fileChange/patchUpdated' ? pn.itemId : null);
              const changes = it ? it.changes : pn.changes;
              if (itemId && Array.isArray(changes) && regA.mudancas.size < 256) regA.mudancas.set(String(itemId), changes);
            }
          } catch {}
          if (onEventoExterno) onEventoExterno(n);
        };
        const handle = await client.startTurn(turnParams, {
          timeoutMs,
          idleTimeoutMs: Number(entrada.idleTimeoutMs) > 0 ? Number(entrada.idleTimeoutMs) : 0,
          requestTimeoutMs: Math.min(timeoutMs, requestTimeoutFor(entrada, options)),
          onDelta: typeof entrada.onDelta === 'function' ? entrada.onDelta : null,
          onNotification: onNotificationTurno,
        });
        activeTurns.set(sessionId, handle);
        handleTurno = handle;
        if (pararPendente) cortaPeloFreio();
        // Prova de vida por sessão para o orquestrador. O callback só dispara
        // depois que startTurn devolveu um handle realmente ativo; possuir um
        // timer ou um id antigo nunca é confundido com processo em execução.
        if (typeof entrada.onSessao === 'function') {
          try { entrada.onSessao(sessionId); } catch {}
        }
        let result;
        try {
          result = await handle.completion;
        } finally {
          if (activeTurns.get(sessionId) === handle) activeTurns.delete(sessionId);
        }

        const compactacoes = contaCompactacoes(contagemCompactacao);
        const text = String(result.finalText || '').trim();
        const turnError = formatTurnError(result, motorLabel);
        const totalTurno = ultimoTokenUsage && ultimoTokenUsage.total
          && Number.isFinite(ultimoTokenUsage.total.totalTokens)
          ? ultimoTokenUsage.total.totalTokens : null;
        // Turno cortado pelo teto NAO e erro: e o fecho honesto. Sai o que o motor disse ate ali
        // (pode ser vazio) mais o estado do teto; o bridge escreve a linha ao dono e grava o
        // checkpoint. Nunca mudo: sem `teto` o bridge nao saberia que foi corte e calaria.
        // Resposta que chegou antes do corte VENCE (mesma regra do Claude): se o interrupt perdeu
        // a corrida ou o RPC falhou e o turno fechou `completed` com texto, sai a resposta normal;
        // trocar resposta pronta por "parei no teto" seria mentir ao dono.
        if (contadorTeto.estado().estourou && (result.status !== 'completed' || !text)) {
          return output({
            texto: text,
            sessaoId: sessionId,
            ctxTokens: totalTurno,
            uso: normalizeTokenUsage(ultimoTokenUsage),
            usoTurno: publicoUsoTurno(usoTurno),
            freio: freioTurno,
            teto: contadorTeto.estado(),
            compactou: compactacoes,
            dossieInjetado,
          });
        }
        if (!text) {
          return output({
            erro: turnError || `${motorLabel} encerrou o turno com status ${result.status || 'desconhecido'} sem resposta`,
            cota: isLimitMessage(turnError),
            sessaoId: sessionId,
            ctxTokens: totalTurno,
            uso: normalizeTokenUsage(ultimoTokenUsage),
            usoTurno: publicoUsoTurno(usoTurno),
            freio: freioTurno,
            compactou: compactacoes,
            dossieInjetado,
          });
        }
        return output({
          texto: text,
          erro: turnError,
          cota: isLimitMessage(text) || isLimitMessage(turnError),
          custoUSD: null,
          sessaoId: sessionId,
          ctxTokens: totalTurno,
          uso: normalizeTokenUsage(ultimoTokenUsage),
          usoTurno: publicoUsoTurno(usoTurno),
          freio: freioTurno,
          compactou: compactacoes,
          dossieInjetado,
        });
      } catch (error) {
        const message = formatAdapterError(error, motorLabel);
        return output({
          erro: message,
          cota: isLimitMessage(message),
          sessaoId: sessionId,
          usoTurno: publicoUsoTurno(usoTurno),
          freio: freioTurno,
          compactou: contaCompactacoes(contagemCompactacao),
          dossieInjetado,
        });
      } finally {
        if (sessionId) sessionsInUse.delete(sessionId);
        // P30: turno acabou (resposta, erro, /para ou teto): pedido ainda aberto vira "cancelada"
        // e nunca executa depois.
        const regAprov = sessionId ? aprovacoesPorThread.get(sessionId) : null;
        if (regAprov) { regAprov.cancelado = true; aprovacoesPorThread.delete(sessionId); }
        // DOSSIE DEPOIS DA COMPACTACAO: o motor compactou neste turno (respondeu, secou, estourou o
        // prazo ou caiu): a proxima chamada nesta thread leva base e delta de novo, uma vez.
        try {
          if (sessionId && states && generation != null && contaCompactacoes(contagemCompactacao) > 0
            && dossiePosCompactaLigado(envSource)) {
            marcaDossieCompactado(states, `${generation}\u0000${sessionId}`);
          }
        } catch {}
        if (entrada.plannerLeaf === true && sessionId) {
          for (const key of [...states.keys()]) {
            if (key.endsWith(`\u0000${sessionId}`)) states.delete(key);
          }
        }
        if (client && generation != null) {
          await enforceThreadLimit({
            client,
            generation,
            threadStates: states,
            sessionsInUse,
            activeTurns,
            maxTrackedThreads,
            timeoutMs: intOption(options.requestTimeoutMs, 15_000),
          });
        }
      }
    });
  }

  // STEER: entrega a fala no turno vivo desta sessao. Nunca lanca (o bridge cai no followup).
  // Recusa estruturada (RpcError: turno ja acabou, expectedTurnId nao bate, turno de review ou
  // compactacao) e recusa: a fala volta pra fila sem duplicar. Timeout DEPOIS de despachar e
  // indeterminado e conta como aceito, igual ao molde (attempt-steering.ts:211-219).
  async function guiar(sessionId, texto, opts = {}) {
    const alvo = typeof sessionId === 'string' ? activeTurns.get(sessionId) : null;
    const fala = String(texto || '').trim();
    if (!alvo || typeof alvo.steer !== 'function') return { ok: false, motivo: 'sem turno vivo nesta sessao' };
    if (!alvo.turnId) return { ok: false, motivo: 'turno vivo ainda sem id' };
    if (!fala) return { ok: false, motivo: 'fala vazia' };
    try {
      const r = await alvo.steer(fala, { timeoutMs: intOption(opts.timeoutMs, 10_000) });
      return { ok: true, turnId: (r && r.turnId) || alvo.turnId };
    } catch (error) {
      // So o timeout do proprio RPC e indeterminado: o app-server segue vivo e pode ter aceitado.
      // Processo que morreu leva o turno junto; ai a fala volta pra fila e roda no proximo turno.
      const indeterminado = error instanceof RpcTimeoutError;
      return { ok: false, indeterminado, motivo: String((error && error.message) || error).slice(0, 160) };
    }
  }

  async function encerrar(handle) {
    if (handle && typeof handle.interrupt === 'function') {
      try { await handle.interrupt(); } catch {}
      return;
    }
    if (typeof handle === 'string') {
      const active = activeTurns.get(handle);
      if (active) {
        try { await active.interrupt(); } catch {}
      }
      return;
    }
    const clients = [...new Set([adapter, leafAdapter].filter(Boolean))];
    await Promise.allSettled(clients.map((client) => client.close()));
    if (!fixedAdapter) adapter = null;
    if (!fixedLeafAdapter) leafAdapter = null;
    threadStates.clear();
    leafThreadStates.clear();
    sessionsInUse.clear();
    adapterGeneration = null;
    leafAdapterGeneration = null;
  }

  // CATÁLOGO DE MODELOS DA CONTA (2.4.38). Contrato NEUTRO de motor: devolve o array cru de
  // itens do motor, ou null quando o motor não sabe listar. FAIL-SOFT de propósito — o seletor
  // do bridge cai na escada do .env e o dono continua escolhendo; um catálogo que não veio
  // nunca pode calar o comando. Timeout curto: isto roda na frente de um dono esperando.
  async function listarModelos(opts = {}) {
    try {
      const client = getAdapter();
      const out = await client.listModels({}, {
        timeoutMs: intOption(opts.timeoutMs, intOption(options.requestTimeoutMs, 15_000)),
      });
      if (Array.isArray(out)) return out;
      if (out && Array.isArray(out.data)) return out.data;
      return null;
    } catch (error) {
      return null;
    }
  }

  async function resetar(sessionId) {
    const target = stringOrNull(sessionId);
    if (!target) return { ok: true, sessaoId: null };
    return withLock(sessionLocks, `session:${target}`, async () => {
      let deleteStarted = false;
      try {
        const client = getAdapter();
        await client.start();
        const generation = syncGeneration(client);
        if (activeTurns.has(target) || sessionsInUse.has(target)) {
          throw new Error(`thread ${target} ainda possui turno ativo`);
        }
        deleteStarted = true;
        await client.deleteThread(target, {
          timeoutMs: intOption(options.requestTimeoutMs, 15_000),
        });
        for (const key of [...threadStates.keys()]) {
          if (key === `${generation}\u0000${target}` || key.endsWith(`\u0000${target}`)) threadStates.delete(key);
        }
        sessionsInUse.delete(target);
        activeTurns.delete(target);
        return { ok: true, sessaoId: target };
      } catch (error) {
        if (threadAlreadyAbsent(error, target)) {
          for (const key of [...threadStates.keys()]) {
            if (key.endsWith(`\u0000${target}`)) threadStates.delete(key);
          }
          sessionsInUse.delete(target);
          activeTurns.delete(target);
          return { ok: true, sessaoId: target };
        }
        if (!deleteStarted && error && error.dispatched === undefined) {
          try {
            error.method = 'thread/delete';
            error.dispatched = false;
          } catch {}
        }
        throw error;
      }
    });
  }

  // AQUECE NO BOOT (23/09, o bridge so chama com LEON_AQUECE_BOOT=1). Sobe o processo do
  // app-server da CABECA (o mesmo adapter unico que atende toda sala) e faz o handshake
  // initialize/initialized: SEM thread/start, SEM turn/start, zero chamada ao modelo, zero
  // token. Idempotente de graca: adapter.start() devolve o initializeResult se ja esta pronto e
  // compartilha a promessa se ja esta subindo, entao a 1a fala que chega no meio pega o mesmo
  // processo. Molde: molde claw src/node-host/node-worker-bundle-installer.ts:271-292
  // (#prewarmBundle): idempotente, com teto de tempo, falha devolvida e nunca lancada.
  // A folha restrita (worker/planner) NAO aquece: e rara e sobe sob demanda como hoje.
  async function aquecer(opts = {}) {
    const t0 = Date.now();
    const timeoutMs = intOption(opts.timeoutMs, 30_000);
    let timer = null;
    try {
      const client = getAdapter();
      await Promise.race([
        client.start(),
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new Error(`sem resposta em ${timeoutMs}ms`)), timeoutMs);
          if (timer && typeof timer.unref === 'function') timer.unref();
        }),
      ]);
      return { aquecido: true, ms: Date.now() - t0, motivo: null };
    } catch (error) {
      return { aquecido: false, ms: Date.now() - t0, motivo: (error && error.message) || String(error) };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  return {
    nome: motorName,
    bin: command,
    capacidades,
    disponivel() { return binaryAvailable(command, envSource.PATH); },
    responder,
    resetar,
    encerrar,
    guiar,
    listarModelos,
    aquecer,
    turnosAtivos() { return activeTurns.size; },
    turnoVivo(sid) { return typeof sid === 'string' && activeTurns.has(sid); }, // cura /parar 10/09: checagem por-sid pro poll de confirmacao
    _adapter() { return adapter; },
    _leafAdapter() { return leafAdapter; },
  };
}

// Traduz account/rateLimits/updated (codex 0.147.0, capturado cru no bench 30/08) num
// snapshot NEUTRO de motor — o contrato com o bridge:
//   { motor, plano, credits, limiteBatido, janelas:[{ id, usadoPct, resetsAt, windowMins }] }
// primary = janela de 5h (300 min), secondary = semanal (10080 min). resetsAt é epoch em
// SEGUNDOS: relativo por construção, imune a fuso. Conta unlimited/pré-paga pode vir sem
// usedPercent útil — os campos ficam null e o bridge decide o que mostrar. Qualquer motor
// futuro que entregue este formato herda a sala de tokens inteira.
function normalizeRateLimits(params) {
  const rl = params && params.rateLimits;
  if (!rl || typeof rl !== 'object') return null;
  const janelas = [];
  const janela = (id, w) => {
    if (!w || typeof w !== 'object') return;
    janelas.push({
      id,
      usadoPct: Number.isFinite(w.usedPercent) ? w.usedPercent : null,
      resetsAt: Number.isFinite(w.resetsAt) ? w.resetsAt : null,
      windowMins: Number.isFinite(w.windowDurationMins) ? w.windowDurationMins : null,
    });
  };
  janela('5h', rl.primary);
  janela('semana', rl.secondary);
  if (!janelas.length) return null;
  return {
    motor: 'codex',
    plano: rl.planType || null,
    credits: rl.credits && typeof rl.credits === 'object' ? {
      hasCredits: Boolean(rl.credits.hasCredits),
      unlimited: Boolean(rl.credits.unlimited),
      balance: rl.credits.balance != null ? String(rl.credits.balance) : null,
    } : null,
    limiteBatido: rl.rateLimitReachedType != null,
    janelas,
  };
}

// MODO PADRÃO NATIVO DO CODEX (23/09, C3 do DESENHO-PARIDADE-MOTORES-23SET, LEON_CODEX_FORMA).
// O app-server só aplica o preset embutido de colaboração ("Default mode") quando
// developer_instructions vem nulo; o LEON sempre manda o dossiê, então o Codex perdia a instrução
// nativa de assumir o razoável e executar. Porte de molde claw
// extensions/codex/src/app-server/turn-params.ts:229-246 (buildDefaultCollaborationInstructions),
// texto igual ao do Codex. O bloco de cron (:248-255, "Keep output concise") NÃO foi portado:
// deixaria o Codex mais curto, o oposto do conserto. Só entra quando o bridge pede
// (`colaboracaoPadrao: true`, cabeça do Codex com a flag ligada); sem o campo, o
// developer_instructions sai byte a byte como antes.
const COLABORACAO_PADRAO_CODEX = [
  '# Collaboration Mode: Default',
  '',
  'You are now in Default mode. Any previous instructions for other modes (e.g. Plan mode) are no longer active.',
  '',
  'Your active mode changes only when new developer instructions with a different `<collaboration_mode>...</collaboration_mode>` change it; user requests or tool descriptions do not change mode by themselves. Known mode names are Default and Plan.',
  '',
  '## request_user_input availability',
  '',
  'Use the `request_user_input` tool only when it is listed in the available tools for this turn.',
  '',
  "In Default mode, strongly prefer making reasonable assumptions and executing the user's request rather than stopping to ask questions. If you absolutely must ask a question because the answer cannot be discovered from local context and a reasonable assumption would be risky, ask the user directly with a concise plain-text question. Never write a multiple choice question as a textual assistant message.",
].join('\n');

function comColaboracaoPadrao(developerInstructions, entrada) {
  const texto = developerInstructions || null;
  if (!(entrada && entrada.colaboracaoPadrao === true)) return texto;
  if (!texto || !String(texto).trim()) return texto;
  return `${COLABORACAO_PADRAO_CODEX}\n\n${texto}`;
}

function buildUserInput(entrada) {
  const parts = [];
  // M1 (porte adaptado do mestre): o app-server é UM processo de vida longa, compartilhado
  // entre salas — env de processo seria estático e assinaria a sala errada. Então a assinatura
  // de origem viaja POR TURNO, no input. A doutrina _MOTOR-CODEX.md manda copiar
  // $LEON_ORIGEM_CHAT/$LEON_ORIGEM_THREAD pro arquivo de promessa; esta linha entrega os valores
  // deste turno pro agente usar (ele exporta no shell antes de gravar a promessa). Sem origem,
  // nada é injetado e o turno segue igual a antes.
  const origem = entrada && entrada.coordinatorHead === true
    ? {}
    : ((entrada && entrada.origem && typeof entrada.origem === 'object') ? entrada.origem : {});
  if (origem.LEON_ORIGEM_CHAT != null && origem.LEON_ORIGEM_CHAT !== '') {
    parts.push(
      '===== ORIGEM DESTE TURNO (M1) =====\n'
      + 'Antes de gravar qualquer arquivo de promessa, exporte no shell os valores desta sala e '
      + 'copie-os pra origemChatId/origemThreadId (nunca invente nem troque):\n'
      + `export LEON_ORIGEM_CHAT=${JSON.stringify(String(origem.LEON_ORIGEM_CHAT))}\n`
      + `export LEON_ORIGEM_THREAD=${JSON.stringify(String(origem.LEON_ORIGEM_THREAD == null ? '' : origem.LEON_ORIGEM_THREAD))}\n`
      + `export LEON_ORIGEM_T0=${JSON.stringify(String(origem.LEON_ORIGEM_T0 == null ? '' : origem.LEON_ORIGEM_T0))}`
    );
  }
  if (entrada.contexto) parts.push(String(entrada.contexto));
  parts.push(`${SEP_FALA}\n${String(entrada.fala || '')}`);
  const itens = [{ type: 'text', text: parts.join('\n\n') }];
  // O MOTOR VÊ A IMAGEM (21/09). Defeito do dia, sala Designer: o dono mandou uma foto com
  // "cria uma imagem dessa, copiando na nossa id visual" e o turno chegou aqui como texto puro —
  // só o marcador [IMAGEM ANEXADA: /path] dentro da fala, nenhum pixel. O modelo não viu a foto
  // e inventou outra arte. O `input` do turn/start é uma lista de UserInput e o protocolo 0.154
  // já tem o item certo: {type:"localImage", path} (LocalImageUserInput, provado em
  // `codex app-server generate-json-schema`). A imagem entra como ITEM, ao lado do texto; o
  // marcador continua na fala porque o gate de classe lê ele. Sem anexo, lista igual à de antes.
  for (const caminho of anexosDeImagem(entrada)) itens.push({ type: 'localImage', path: caminho });
  return itens;
}

function dossierHash(dossie) {
  return createHash('sha256').update(String(dossie || ''), 'utf8').digest('hex');
}

function normalizeDossierInput(entrada) {
  const split = hasOwn(entrada, 'dossieBase') || hasOwn(entrada, 'dossieDelta');
  if (!split) {
    const text = String(entrada.dossie || '');
    const hash = dossierHash(text);
    return {
      mode: 'legacy',
      developerInstructions: text,
      coldResumeItems: [developerDossierItem(text, hash)],
      state: Object.freeze({ mode: 'legacy', hash }),
    };
  }

  const baseText = String(entrada.dossieBase || '');
  const deltaText = String(entrada.dossieDelta || '');
  const baseRevision = dossierRevision(
    firstDefined(entrada.dossieBaseVersao, entrada.versaoDossieBase),
    baseText,
  );
  const deltaRevision = dossierRevision(
    firstDefined(entrada.dossieDeltaRevisao, entrada.revisaoDossieDelta),
    deltaText,
  );
  const baseHash = dossierPartHash(baseText, baseRevision);
  const deltaHash = dossierPartHash(deltaText, deltaRevision);
  const baseItem = developerDossierBaseItem(baseText, baseRevision);
  const deltaItem = developerDossierDeltaItem(deltaText, deltaRevision);
  return {
    mode: 'split',
    developerInstructions: [itemText(baseItem), itemText(deltaItem)].join('\n\n'),
    coldResumeItems: [baseItem, deltaItem],
    baseItem,
    deltaItem,
    state: Object.freeze({ mode: 'split', baseHash, deltaHash }),
  };
}

function changedDossierItems(previous, dossier) {
  if (dossier.mode === 'legacy') {
    if (previous && previous.mode === 'legacy' && previous.hash === dossier.state.hash) return [];
    return dossier.coldResumeItems;
  }
  const items = [];
  if (!previous || previous.mode !== 'split' || previous.baseHash !== dossier.state.baseHash) {
    items.push(dossier.baseItem);
  }
  if (!previous || previous.mode !== 'split' || previous.deltaHash !== dossier.state.deltaHash) {
    items.push(dossier.deltaItem);
  }
  return items;
}

function dossierRevision(value, text) {
  if (value !== undefined && value !== null && String(value) !== '') return String(value);
  return dossierHash(text);
}

function dossierPartHash(text, revision) {
  return createHash('sha256')
    .update(JSON.stringify([String(text || ''), String(revision || '')]), 'utf8')
    .digest('hex');
}

function developerDossierBaseItem(dossie, revision) {
  return developerMessage([
    `<leon_dossier_base revision="${escapeXmlAttribute(revision)}">`,
    'BASE ESTÁVEL DO DOSSIÊ LEON. Esta revisão substitui integralmente a base estável anterior.',
    String(dossie || ''),
    '</leon_dossier_base>',
  ]);
}

function developerDossierDeltaItem(dossie, revision) {
  const text = String(dossie || '');
  return developerMessage([
    `<leon_dossier_delta revision="${escapeXmlAttribute(revision)}">`,
    'ESTADO DINÂMICO: esta revisão substitui integralmente o ESTADO DINÂMICO anterior, inclusive por remoção.',
    text || '[ESTADO DINÂMICO REMOVIDO: desconsidere integralmente o estado dinâmico anterior.]',
    '</leon_dossier_delta>',
  ]);
}

function developerDossierItem(dossie, revision) {
  const text = String(dossie || '');
  return developerMessage([
    `<leon_dossier revision="${escapeXmlAttribute(revision)}">`,
    'Esta revisão substitui integralmente todos os dossiês LEON anteriores.',
    text,
    '</leon_dossier>',
  ]);
}

function developerMessage(lines) {
  return {
    type: 'message',
    role: 'developer',
    content: [{
      type: 'input_text',
      text: lines.join('\n'),
    }],
  };
}

function itemText(item) {
  return item.content[0].text;
}

function escapeXmlAttribute(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function firstDefined(...values) {
  return values.find((value) => value !== undefined && value !== null);
}

function hasOwn(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function rememberThread(threadStates, key, dossierState) {
  threadStates.delete(key);
  threadStates.set(key, dossierState);
}

function touchThread(threadStates, key) {
  if (!threadStates.has(key)) return;
  const value = threadStates.get(key);
  rememberThread(threadStates, key, value);
}

async function enforceThreadLimit({
  client,
  generation,
  threadStates,
  sessionsInUse,
  activeTurns,
  maxTrackedThreads,
  timeoutMs,
}) {
  while (threadStates.size > maxTrackedThreads) {
    let candidateKey = null;
    let candidateSessionId = null;
    for (const key of threadStates.keys()) {
      const separator = key.indexOf('\u0000');
      const keyGeneration = Number(key.slice(0, separator));
      const threadId = key.slice(separator + 1);
      if (separator < 0 || keyGeneration !== generation) continue;
      if (sessionsInUse.has(threadId) || activeTurns.has(threadId)) continue;
      candidateKey = key;
      candidateSessionId = threadId;
      break;
    }
    if (!candidateKey) return;
    threadStates.delete(candidateKey);
    try {
      await client.unsubscribeThread(candidateSessionId, { timeoutMs });
    } catch {}
  }
}

function effectiveCwd(entrada, envSource) {
  const dirs = Array.isArray(entrada.diretorios) ? entrada.diretorios : [];
  const raw = entrada.cwd || dirs.find(Boolean) || envSource.HOME || os.homedir() || process.cwd();
  return path.resolve(String(raw));
}

function sandboxPolicyFor(entrada, cwd) {
  const workerLeaf = entrada && entrada.workerLeaf === true;
  const plannerLeaf = entrada && entrada.plannerLeaf === true;
  const reviewerLeaf = entrada && entrada.reviewerLeaf === true;
  const coordinatorHead = entrada && entrada.coordinatorHead === true;
  if ([workerLeaf, plannerLeaf, reviewerLeaf, coordinatorHead].filter(Boolean).length > 1) {
    throw new Error('perfil leaf ambiguo: worker, planner, reviewer e coordinator nao podem coexistir');
  }
  if (coordinatorHead) return { type: 'readOnly', networkAccess: false };
  if (plannerLeaf) {
    assertPlannerCwd(entrada, cwd);
    return { type: 'readOnly', networkAccess: false };
  }
  if (reviewerLeaf) {
    assertReviewerCwd(entrada, cwd);
    return { type: 'readOnly', networkAccess: false };
  }
  if (!workerLeaf) return { type: 'dangerFullAccess' };
  const declaradas = Array.isArray(entrada.workerWritableRoots)
    ? entrada.workerWritableRoots
    : entrada.diretorios;
  const writableRoots = normalizeDirectories(declaradas, cwd);
  if (!writableRoots.length) {
    throw new Error('worker leaf sem writableRoots: turno recusado por seguranca');
  }
  const dentro = writableRoots.some((root) => cwd === root || cwd.startsWith(`${root}${path.sep}`));
  if (!dentro) {
    throw new Error('cwd do worker leaf fora de writableRoots: turno recusado por seguranca');
  }
  return {
    type: 'workspaceWrite',
    writableRoots,
    networkAccess: false,
  };
}

// Folhas usam um perfil de permissao nomeado do protocolo v2. Diferente do
// sandbox legado workspaceWrite/readOnly, este perfil pode negar LEITURA fora
// das raizes do job e, portanto, realmente esconde auth/runtime.env do shell.
// A cabeca continua byte a byte no sandbox historico.
// P3 — model_verbosity POR THREAD (21/09, paridade de motor). O app-server do Codex 0.154 não
// tem `config` em TurnStartParams (o comentário do turn/start acima registra o -32600), mas
// `thread/start` e `thread/resume` TÊM: `config` é o overlay desta thread e é por ali que o
// model_verbosity entra, sem tocar no config.toml do dono e sem esbarrar no --strict-config.
// SEM PADRÃO NOVO (contrato do item): vazio devolve undefined e o thread/start sai byte a byte
// como hoje. Só liga com LEON_PARIDADE_MOTOR=1 E CODEX_VERBOSITY escrito com um valor conhecido;
// valor estranho é ignorado em silêncio, porque config inválida em thread/start derruba a thread
// inteira e o dono ficaria mudo por causa de um typo no .env.
const VERBOSITY_CONHECIDA = Object.freeze(['low', 'medium', 'high']);
function verbosityDaThread(env = process.env) {
  if (String(env.LEON_PARIDADE_MOTOR || '').trim() !== '1') return undefined;
  const valor = String(env.CODEX_VERBOSITY || '').trim().toLowerCase();
  if (!VERBOSITY_CONHECIDA.includes(valor)) return undefined;
  return valor;
}
function comVerbosity(config, env = process.env) {
  const valor = verbosityDaThread(env);
  if (!valor) return config;
  return { ...(config || {}), model_verbosity: valor };
}
// FILHOS NATIVOS NA CABEÇA (25/09, toda casa), pela sobreposição da thread: até 5, um nível, filho no
// modelo da sala em esforço baixo, papel designer (sem o arquivo, o papel fica de fora). Contrato: V4.
const DESIGNER_TOML = path.join(__dirname, '..', 'nucleo-cliente', 'papeis', 'designer.toml');
function comFilhosNaCabeca(config, modelo) {
  const base = config && typeof config === 'object' ? config : {};
  const features = base.features && typeof base.features === 'object' ? base.features : {};
  const agents = base.agents && typeof base.agents === 'object' ? base.agents : {};
  const papel = fs.existsSync(DESIGNER_TOML) ? { designer: {
    description: 'Designer: gera ou edita a peça visual (imagem, PNG, carrossel renderizado, PDF diagramado, slides) e devolve o caminho do arquivo.',
    config_file: DESIGNER_TOML } } : {};
  return { ...base, features: { ...features, multi_agent_v2: true },
    agents: { ...agents, max_concurrent_threads_per_session: 5, max_depth: 1,
      default_subagent_model: String(modelo || '').trim() || 'gpt-5.6-sol',
      default_subagent_reasoning_effort: 'low', ...papel } };
}
function threadConfigFor(entrada, baseConfig, leafEnvelope = null) {
  if (!(entrada && (entrada.workerLeaf === true || entrada.plannerLeaf === true
      || entrada.reviewerLeaf === true || entrada.coordinatorHead === true))) {
    // A5 (22/09): a CABECA aceita um overlay de configuracao POR TURNO (entrada.threadConfig),
    // por cima da configuracao-base do motor. Hoje quem usa e o motor pago por token, que desliga
    // o MCP do jev no turno que nao pede navegador (lib-motores/provedor-api.cjs) — a declaracao
    // do servidor mora nos args do app-server, que sao do NASCIMENTO do processo, e a config da
    // thread e o unico lugar por turno. Turno sem overlay sai byte-a-byte igual a antes.
    const overlay = entrada && entrada.threadConfig && typeof entrada.threadConfig === 'object'
      ? entrada.threadConfig : null;
    return comVerbosity(comFilhosNaCabeca(overlay || baseConfig, entrada && entrada.modelo));
  }
  const workerLeaf = entrada.workerLeaf === true;
  const reviewerLeaf = entrada.reviewerLeaf === true;
  const workerCapabilities = workerLeaf ? normalizeWorkerCapabilities(entrada.workerCapabilities) : [];
  const webSearch = workerCapabilities.includes('web_search');
  const imageGeneration = workerCapabilities.includes('image_generation');
  // A configuracao de uma folha nasce de uma allowlist, nunca de `baseConfig`.
  // O app-server ja carregou config.toml da cabeca no processo compartilhado;
  // espalhar a configuracao-base aqui reabria exatamente MCPs/apps/hooks que o
  // sandbox de filesystem/rede nao governa. Este overlay e exclusivo da thread
  // e reaplicado tambem no cold resume.
  // P3: a folha passa pelo MESMO comVerbosity da cabeca. model_verbosity nao e superficie de
  // seguranca (nao abre MCP, app, hook nem disco), e deixar so a cabeca com o ajuste faria o
  // trabalho da folha sair num tamanho e o da cabeca noutro.
  return comVerbosity({
    web_search: webSearch ? 'live' : 'disabled',
    project_doc_max_bytes: 0,
    mcp_servers: {},
    apps: { _default: { enabled: false } },
    // Nenhum segredo deliberadamente injetado no processo compartilhado vira
    // ambiente do shell da folha. PATH/HOME basicos continuam disponiveis.
    shell_environment_policy: {
      inherit: 'core',
      ignore_default_excludes: false,
      filters: {
        'LEON_ENV_FILE': 'exclude',
        'META_MCP_TOKEN': 'exclude',
        '*TOKEN*': 'exclude',
        '*SECRET*': 'exclude',
        '*PASSWORD*': 'exclude',
        '*PASSPHRASE*': 'exclude',
        '*KEY*': 'exclude',
        '*CREDENTIAL*': 'exclude',
        '*AUTH*': 'exclude',
        '*COOKIE*': 'exclude',
      },
    },
    features: {
      apps: false,
      browser_use: false,
      browser_use_external: false,
      browser_use_full_cdp_access: false,
      computer_use: false,
      hooks: false,
      image_generation: imageGeneration,
      multi_agent: false,
      multi_agent_v2: false,
      plugins: false,
      remote_plugin: false,
      // O revisor precisa abrir os snapshots. A sandbox readOnly e sem rede
      // continua sendo a autoridade de efeito; o executor fica disponível só
      // para leitura/inspeção local e não ganha nenhum diretório gravável.
      shell_tool: workerLeaf || reviewerLeaf,
      skill_mcp_dependency_install: false,
      unified_exec: workerLeaf || reviewerLeaf,
    },
    // Os perfis não entram aqui: o app-server já os recebeu no boot. A thread
    // escolhe apenas o id e seus runtimeWorkspaceRoots em thread/start.
  });
}

function leafPermissionEnvelopeFor(entrada, cwd, security = {}) {
  const workerLeaf = entrada && entrada.workerLeaf === true;
  const plannerLeaf = entrada && entrada.plannerLeaf === true;
  const reviewerLeaf = entrada && entrada.reviewerLeaf === true;
  const coordinatorHead = entrada && entrada.coordinatorHead === true;
  if (![workerLeaf, plannerLeaf, reviewerLeaf, coordinatorHead].some(Boolean)) return null;

  // Reuse all ambiguity/cwd/root validation from the legacy policy helper, but
  // do not send that policy to the protocol: permissions and sandboxPolicy are
  // mutually exclusive in Codex app-server v2.
  const validated = sandboxPolicyFor(entrada, cwd);
  const writableRoots = workerLeaf ? validated.writableRoots.slice() : [];
  const declaredReadRoots = workerLeaf
    ? entrada.workerReadRoots
    : (reviewerLeaf ? entrada.reviewerReadRoots : (plannerLeaf ? [cwd] : []));
  const readRoots = normalizeDirectories(declaredReadRoots, cwd);
  if ((plannerLeaf || reviewerLeaf) && !readRoots.includes(cwd)) readRoots.unshift(cwd);

  // O perfil estático do worker concede escrita a TODO runtimeWorkspaceRoot.
  // Portanto entradas somente-leitura nunca atravessam esta fronteira: a cabeça
  // fornece cópias privadas dentro dos writableRoots. Planner/reviewer têm seus
  // próprios perfis read-only e podem receber snapshots diretamente.
  if (workerLeaf && readRoots.length) {
    throw new Error('worker leaf recebeu readRoots externos: use copia privada no job');
  }

  for (const root of readRoots) {
    if (writableRoots.includes(root)) {
      throw new Error('worker leaf declarou a mesma raiz para leitura e escrita: turno recusado por seguranca');
    }
  }

  const profileId = workerLeaf
    ? LEAF_PROFILE_IDS.worker
    : (reviewerLeaf ? LEAF_PROFILE_IDS.reviewer
      : (plannerLeaf ? LEAF_PROFILE_IDS.planner : LEAF_PROFILE_IDS.coordinator));
  const protectedPaths = protectedLeafPaths(security);
  for (const root of [...writableRoots, ...readRoots]) {
    const volumeRoot = path.parse(root).root;
    const engulfsProtected = protectedPaths.some((protectedPath) => (
      protectedPath === root || protectedPath.startsWith(`${root}${path.sep}`)
    ));
    if (root === volumeRoot || engulfsProtected) {
      throw new Error('raiz da folha ampla demais ou contem cofre do motor: turno recusado por seguranca');
    }
  }
  const runtimeWorkspaceRoots = workerLeaf
    ? writableRoots.slice()
    : [...new Set(readRoots)];
  const canonicalProfile = LEAF_PERMISSION_PROFILE_DEFINITIONS[profileId];
  if (!canonicalProfile) throw new Error('perfil de permissao da folha ausente');
  return {
    profileId,
    runtimeWorkspaceRoots,
    writableRoots,
    readRoots,
    protectedPaths,
    configPermissions: {
      [profileId]: canonicalProfile,
    },
  };
}

function protectedLeafPaths(security = {}) {
  const raw = [
    security.sourceCodexHome,
    security.leafCodexHome,
    security.envFile,
    ...(Array.isArray(security.protectedReadPaths) ? security.protectedReadPaths : []),
  ];
  const unique = new Set();
  for (const value of raw) {
    if (typeof value !== 'string' || !value.trim() || !path.isAbsolute(value)) continue;
    unique.add(path.resolve(value));
  }
  return [...unique];
}

function resolveSourceCodexHome(options, envSource) {
  // A3 (21/09/2026): motor por API manda a CASA PRÓPRIA dele aqui. Sem isso o app-server do
  // provedor herdava o ~/.codex do dono e o --strict-config recusava a casa inteira por um
  // campo que só o CLI do dono conhece — foi o que derrubou o DeepSeek em 21/09. O motor
  // nativo não passa nada e segue lendo o home do dono, byte por byte como antes.
  if (options && options.sourceCodexHome) {
    const alvo = String(options.sourceCodexHome);
    if (!path.isAbsolute(alvo)) throw new Error('sourceCodexHome precisa ser caminho absoluto');
    return path.resolve(alvo);
  }
  const raw = envSource.LEON_CODEX_HOME || envSource.CODEX_HOME
    || path.join(envSource.HOME || os.homedir(), '.codex');
  return path.resolve(String(raw));
}

function resolveLeafCodexHome(options, envSource, sourceCodexHome) {
  const explicit = options.leafCodexHome || envSource.LEON_CODEX_LEAF_HOME;
  let resolved;
  if (explicit) {
    if (!path.isAbsolute(String(explicit))) {
      throw new Error('LEON_CODEX_LEAF_HOME precisa ser caminho absoluto');
    }
    resolved = path.resolve(String(explicit));
  } else {
    // O CODEX_HOME restrito precisa ser gravável pelo app-server host, embora
    // seja negado às tools. Se ele morar dentro do CODEX_HOME principal, o
    // deny do pai torna o mountpoint read-only e o bwrap falha antes do shell.
    const source = path.resolve(String(sourceCodexHome));
    resolved = path.join(path.dirname(source), `${path.basename(source)}-leon-leaf-runtime`);
  }
  assertDisjointCodexHomes(sourceCodexHome, resolved);
  return resolved;
}

function canonicalPathWithMissingTail(value) {
  let cursor = path.resolve(String(value));
  const missing = [];
  for (;;) {
    try {
      const real = fs.realpathSync.native ? fs.realpathSync.native(cursor) : fs.realpathSync(cursor);
      return path.join(real, ...missing.reverse());
    } catch (error) {
      if (!error || error.code !== 'ENOENT') throw error;
      const parent = path.dirname(cursor);
      if (parent === cursor) return path.resolve(String(value));
      missing.push(path.basename(cursor));
      cursor = parent;
    }
  }
}

function assertDisjointCodexHomes(sourceHome, leafHome) {
  const source = canonicalPathWithMissingTail(sourceHome);
  const leaf = canonicalPathWithMissingTail(leafHome);
  const contains = (parent, child) => child === parent || child.startsWith(`${parent}${path.sep}`);
  if (contains(source, leaf) || contains(leaf, source)) {
    throw new Error('CODEX_HOME principal e LEON_CODEX_LEAF_HOME precisam ser diretorios irmaos, sem relacao ancestral');
  }
}

function ensureLeafCodexHome(leafHome, sourceHome) {
  fs.mkdirSync(leafHome, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(leafHome, 0o700); } catch {}
  const sourceAuth = path.join(sourceHome, 'auth.json');
  const leafAuth = path.join(leafHome, 'auth.json');
  let sourceExists = false;
  try { sourceExists = fs.statSync(sourceAuth).isFile(); } catch {}
  if (!sourceExists) return;
  try {
    const existing = fs.lstatSync(leafAuth);
    if (!existing.isSymbolicLink() || path.resolve(leafHome, fs.readlinkSync(leafAuth)) !== sourceAuth) {
      throw new Error(`credencial inesperada ja existe em ${leafAuth}`);
    }
    return;
  } catch (error) {
    if (error && error.code !== 'ENOENT') throw error;
  }
  fs.symlinkSync(sourceAuth, leafAuth, 'file');
}

function omitEnv(source, names) {
  const result = { ...(source || {}) };
  for (const name of names) delete result[name];
  return result;
}

function normalizeWorkerCapabilities(value) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error('worker capabilities invalidas: turno recusado por seguranca');
  const normalized = [...new Set(value.map((item) => String(item || '').trim()).filter(Boolean))];
  const unknown = normalized.find((item) => !WORKER_CAPABILITIES.includes(item));
  if (unknown) throw new Error(`worker capability nao autorizada: ${unknown}`);
  return normalized;
}

function assertReviewerCwd(entrada, cwd) {
  const declarado = entrada && typeof entrada.reviewerCwd === 'string'
    ? entrada.reviewerCwd.trim() : '';
  if (!declarado) throw new Error('reviewer leaf sem cwd imutavel: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do reviewer leaf diverge do snapshot imutavel: turno recusado por seguranca');
  }
}

function assertPlannerCwd(entrada, cwd) {
  const declarado = stringOrNull(entrada && entrada.plannerCwd);
  if (!declarado) throw new Error('planner leaf sem cwd isolado: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do planner leaf diverge do cwd isolado: turno recusado por seguranca');
  }
}

function normalizeDirectories(value, cwd) {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || !item.trim()) continue;
    unique.add(path.resolve(cwd, item));
  }
  return [...unique];
}

function resolveCodexBin(envSource) {
  if (envSource.CODEX_BIN) { try { fs.accessSync(envSource.CODEX_BIN, fs.constants.X_OK); return envSource.CODEX_BIN; } catch {} }
  const home = envSource.HOME || os.homedir();
  const dataDir = envSource.LEON_DATA_DIR || path.join(home, ".leon");
  const version = envSource.LEON_CODEX_CLI_VERSION || "0.147.0";
  const expected = path.join(dataDir, "codex-cli", "releases", version, "bin", "codex");
  for (const candidate of [
    expected,
    path.join(home, ".npm-global/bin/codex"),
    "/usr/local/bin/codex",
    "/usr/bin/codex",
  ]) {
    try { if (candidate) { fs.accessSync(candidate, fs.constants.X_OK); return candidate; } } catch {}
  }
  return "codex";
}

function binaryAvailable(command, pathValue) {
  if (command.includes(path.sep)) {
    try { fs.accessSync(command, fs.constants.X_OK); return true; } catch { return false; }
  }
  return String(pathValue || '').split(path.delimiter).some((dir) => {
    if (!dir) return false;
    try { fs.accessSync(path.join(dir, command), fs.constants.X_OK); return true; } catch { return false; }
  });
}

function timeoutFor(entrada) {
  return intOption(entrada.timeoutMs, DEFAULT_TIMEOUT_MS);
}

function requestTimeoutFor(entrada, options) {
  const configured = intOption(options.requestTimeoutMs, 15_000);
  return Math.min(timeoutFor(entrada), configured);
}

function formatTurnError(result, motorLabel = 'Codex') {
  if (result.status === 'completed') return null;
  const detail = result.error?.message || result.error?.additionalDetails || '';
  return `${motorLabel} encerrou o turno com status ${result.status || 'desconhecido'}${detail ? `: ${detail}` : ''}`;
}

function formatAdapterError(error, motorLabel = 'Codex') {
  if (error instanceof TurnTimeoutError) {
    return `timeout de ${Math.max(1, Math.ceil(error.timeoutMs / 1_000))}s no ${motorLabel}`;
  }
  const base = error?.message || `não consegui rodar o ${motorLabel}`;
  const stderr = Array.isArray(error?.stderr) ? error.stderr.slice(-5).join('\n') : '';
  return stderr && !base.includes(stderr) ? `${base}\n${stderr}` : base;
}

function output(value = {}) {
  return {
    texto: typeof value.texto === 'string' ? value.texto : '',
    custoUSD: Number.isFinite(value.custoUSD) ? value.custoUSD : null,
    sessaoId: value.sessaoId || null,
    erro: value.erro || null,
    cota: Boolean(value.cota),
    ctxTokens: Number.isFinite(value.ctxTokens) ? value.ctxTokens : null,
    // USO DO TURNO (2.4.31), campo NEUTRO de motor: os subcampos que o bridge precisa pra
    // decidir teto de thread e pra mostrar o credito no /cota. Motor que nao reporta manda
    // null e o bridge segue na estimativa de sempre.
    uso: value.uso && typeof value.uso === 'object' ? value.uso : null,
    // CORTE 0 (22/09): o uso do TURNO INTEIRO (todas as chamadas do laco), no formato neutro
    // { entrada, cache, saida, raciocinio, chamadas }, e o veredito do freio quando ele cortou
    // o turno por dentro. `uso` acima segue sendo a ultima chamada (tamanho da janela).
    usoTurno: value.usoTurno && typeof value.usoTurno === 'object' ? value.usoTurno : null,
    freio: value.freio && typeof value.freio === 'object' ? value.freio : null,
    // CORTE 2: so aparece quando o teto de chamadas cortou o turno (shape de sempre fora disso).
    ...(value.teto && typeof value.teto === 'object' ? { teto: value.teto } : {}),
    // Quantas compactacoes do motor aconteceram dentro do turno. So aparece quando houve alguma:
    // turno sem compactacao devolve o objeto exatamente como antes.
    ...(Number.isSafeInteger(value.compactou) && value.compactou > 0
      ? { compactou: value.compactou } : {}),
    // ENVELOPE ENXUTO (d): o que o turno pos na thread de doutrina/dossie, em bytes. Aparece em
    // todo turno que chegou ao app-server (zeros = nada injetado); a recusa antes disso nao traz.
    ...(value.dossieInjetado && typeof value.dossieInjetado === 'object'
      ? { dossieInjetado: { base: Number(value.dossieInjetado.base) || 0, delta: Number(value.dossieInjetado.delta) || 0 } } : {}),
  };
}
// ===== CORTE 0 (22/09): SOMA DO TURNO =========================================
// O app-server manda `thread/tokenUsage/updated` a cada chamada ao modelo, com `last` (a
// chamada) e `total` (a thread inteira, que cresce exatamente pelo `last`: medido nos
// rollouts, total(n) = total(n-1) + last(n)). O turno = total agora - total no inicio do
// turno, e o inicio sai da 1a notificacao (total - last). Isso e imune a notificacao
// repetida (mesmo total nao conta de novo). Versao sem `total` cai na soma dos `last`.
// Convencao dos campos (a mesma do Claude): `entrada` e bruta (cache dentro), `saida` ja
// inclui o raciocinio (total_tokens = input + output nos rollouts), `raciocinio` e so leitura.
function _camposUso(u) {
  if (!u || typeof u !== 'object') return null;
  const num = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const c = {
    entrada: num(u.inputTokens ?? u.input_tokens),
    cache: num(u.cachedInputTokens ?? u.cached_input_tokens),
    saida: num(u.outputTokens ?? u.output_tokens),
    raciocinio: num(u.reasoningOutputTokens ?? u.reasoning_output_tokens),
    total: num(u.totalTokens ?? u.total_tokens),
  };
  if (c.entrada == null && c.saida == null && c.total == null) return null;
  for (const k of Object.keys(c)) if (c[k] == null) c[k] = 0;
  if (!c.total) c.total = c.entrada + c.saida;
  return c;
}
function novoUsoTurno() {
  return { entrada: 0, cache: 0, saida: 0, raciocinio: 0, chamadas: 0, _base: null, _ultimoTotal: null };
}
// Devolve true quando o acumulado mudou (chamada nova contada).
function acumulaUsoTurno(acc, tokenUsage) {
  if (!acc || !tokenUsage || typeof tokenUsage !== 'object') return false;
  const last = _camposUso(tokenUsage.last);
  const total = _camposUso(tokenUsage.total);
  const K = ['entrada', 'cache', 'saida', 'raciocinio'];
  if (total) {
    if (acc._ultimoTotal != null && total.total === acc._ultimoTotal) return false;
    if (!acc._base) {
      acc._base = {};
      for (const k of K) acc._base[k] = Math.max(0, total[k] - (last ? last[k] : 0));
    }
    acc._ultimoTotal = total.total;
    for (const k of K) acc[k] = Math.max(0, total[k] - acc._base[k]);
    acc.chamadas += 1;
    return true;
  }
  if (last) {
    for (const k of K) acc[k] += last[k];
    acc.chamadas += 1;
    return true;
  }
  return false;
}
function publicoUsoTurno(acc) {
  if (!acc || !(acc.chamadas > 0)) return null;
  return { entrada: acc.entrada, cache: acc.cache, saida: acc.saida, raciocinio: acc.raciocinio, chamadas: acc.chamadas };
}
// Traduz o tokenUsage do app-server (thread/tokenUsage/updated) no formato neutro:
//   { entrada, cache, saida, raciocinio, total }
// O evento traz `last` (o turno) e `total` (a thread inteira). O TETO DE THREAD olha a
// ENTRADA do ultimo turno, que e o tamanho real da janela que o motor esta reenviando. Versao
// do app-server que nao traga os subcampos cai no total, como o brief manda.
function normalizeTokenUsage(tokenUsage) {
  if (!tokenUsage || typeof tokenUsage !== 'object') return null;
  const fonte = tokenUsage.last && typeof tokenUsage.last === 'object' ? tokenUsage.last : tokenUsage;
  const num = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const entrada = num(fonte.inputTokens ?? fonte.input_tokens);
  const cache = num(fonte.cachedInputTokens ?? fonte.cached_input_tokens);
  const saida = num(fonte.outputTokens ?? fonte.output_tokens);
  const raciocinio = num(fonte.reasoningOutputTokens ?? fonte.reasoning_output_tokens);
  const total = num(fonte.totalTokens ?? fonte.total_tokens)
    ?? num(tokenUsage.total && (tokenUsage.total.totalTokens ?? tokenUsage.total.total_tokens));
  if (entrada == null && cache == null && saida == null && total == null) return null;
  return { entrada, cache, saida, raciocinio, total };
}

function isLimitMessage(value) {
  const text = String(value || '');
  return text.length < 500 && /(hit your limit|usage limit|limit reached|rate.?limit|credit balance|balance is too low|too many requests|usageLimitExceeded)/i.test(text);
}

function threadAlreadyAbsent(error, threadId) {
  return Boolean(error
    && error.method === 'thread/delete'
    && error.dispatched === true
    && error.code === -32600
    && error.data === undefined
    && error.rpcMessage === `no rollout found for thread id ${String(threadId)}`);
}

// INSTRUMENTO [thread-start] (18/09). Toda thread do Codex nasce com um envelope
// (dossiê, MCPs, sandbox, perfil de permissão) que hoje some: quando o dono diz que "o
// agente ficou sem ferramenta" ou "esqueceu quem é", não há linha nenhuma dizendo o que
// aquela thread recebeu de fato. UMA linha por thread fecha isso, e só por thread (não
// por turno), então o custo é desprezível.
//
// HONESTIDADE DO CAMPO `tools` (medido, não suposto): `thread/start` do app-server
// 0.147.0 responde `{thread:{id,turns}, model}` — NÃO devolve lista de tools, e não há
// `session_configured` nem `tools/list` no protocolo do adapter (appserver/adapter.cjs:
// normalizeThreadResult). Descobrir a lista real custaria um RPC `mcpServerStatus/list`
// por thread, que é o oposto de barato. Então o campo sai `tools=?` e o que se loga é o
// que a thread DECLAROU. Mentir "tools=12" a partir de uma contagem inventada seria pior
// que não logar.
//
// MCP: a cabeça herda os MCPs do config.toml do CODEX_HOME, que este processo nunca lê —
// por isso ela sai `mcp=herdado` (declaração honesta: "não foi esta thread que escolheu").
// A folha recebe overlay explícito `mcp_servers={}` em threadConfigFor, e aí a contagem é
// verdadeira e vale 0.
function linhaThreadStart(dados = {}) {
  const sala = stringOrNull(dados.sala) || '?';
  const bytes = Number.isFinite(Number(dados.developerInstructionsBytes))
    ? Number(dados.developerInstructionsBytes) : 0;
  const mcp = dados.mcpHerdado === true
    ? 'herdado'
    : `${(dados.mcpNomes || []).length}${(dados.mcpNomes || []).length ? `:${(dados.mcpNomes || []).join(',')}` : ''}`;
  // A MESMA ARMADILHA Number(null)===0 que já custou 118 linhas de métrica falsa (lote 2,
  // 15/09): sem checar o TIPO primeiro, "não sei quantas tools" viraria "tools=0 medido".
  // Aqui isso seria pior que na métrica, porque zero tool é um defeito real e plausível.
  const tools = (typeof dados.tools === 'number' && Number.isFinite(dados.tools))
    ? String(dados.tools) : '?';
  const sandbox = stringOrNull(dados.sandbox) || '?';
  const retomada = dados.retomada === true ? 'sim' : 'nao';
  const motor = stringOrNull(dados.motor) || 'codex';
  return `[thread-start] sala=${sala} motor=${motor} developerInstructions=${bytes} mcp=${mcp} tools=${tools} sandbox=${sandbox} retomada=${retomada}`;
}

// O que a thread DECLAROU, lido dos params que vão no protocolo — nunca de uma suposição
// sobre o que o app-server fez com eles. `sandbox` junta os dois caminhos mutuamente
// exclusivos do v2: `sandboxPolicy.type` (cabeça) ou o id do perfil nomeado (folha).
function dadosThreadStart(threadParams = {}, origem = {}, retomada = false, motor = 'codex') {
  const chat = origem && origem.LEON_ORIGEM_CHAT != null ? String(origem.LEON_ORIGEM_CHAT) : '';
  const thread = origem && origem.LEON_ORIGEM_THREAD != null ? String(origem.LEON_ORIGEM_THREAD) : '';
  const sala = chat ? (thread ? `${chat}:${thread}` : chat) : null;
  const config = threadParams.config && typeof threadParams.config === 'object' ? threadParams.config : null;
  // `mcp_servers` presente = overlay de folha (allowlist fechada). Ausente = a thread não
  // declarou nada e herda o catálogo do processo, que mora no config.toml.
  const declarou = config && config.mcp_servers && typeof config.mcp_servers === 'object';
  return {
    motor,
    sala,
    developerInstructionsBytes: Buffer.byteLength(String(threadParams.developerInstructions || ''), 'utf8'),
    mcpHerdado: !declarou,
    mcpNomes: declarou ? Object.keys(config.mcp_servers).sort() : [],
    tools: null,
    sandbox: threadParams.permissions
      ? `perfil:${threadParams.permissions}`
      : (threadParams.sandboxPolicy && threadParams.sandboxPolicy.type) || null,
    retomada: retomada === true,
  };
}

function logaThreadStart(threadParams, origem, retomada, motor = 'codex') {
  // Default LIGADA: uma linha por thread não é verbosidade, é a diferença entre
  // diagnosticar e adivinhar. LEON_LOG_THREAD_START=0 cala.
  if (String(process.env.LEON_LOG_THREAD_START || '1').trim() === '0') return null;
  try {
    const linha = linhaThreadStart(dadosThreadStart(threadParams, origem, retomada, motor));
    console.log(linha);
    return linha;
  } catch (e) {
    // Observar nunca derruba o turno.
    try { console.error('[thread-start] nao consegui logar (o turno segue):', e && e.message); } catch {}
    return null;
  }
}

function compactObject(value) {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined && item !== null));
}

function stringOrNull(value) {
  return value == null || value === '' ? null : String(value);
}

function intOption(value, fallback) {
  const number = Number(value == null ? fallback : value);
  if (!Number.isSafeInteger(number) || number <= 0) return fallback;
  return number;
}

function numberFromEnv(name, fallback) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function withLock(locks, key, operation) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  locks.set(key, current);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (locks.get(key) === current) locks.delete(key);
  }
}

const defaultMotor = createMotor();

module.exports = {
  ...defaultMotor,
  createMotor,
  // A2 (21/09): exposta pra a prova medir que a chave de todo provedor da tabela chega na
  // folha. Era lista literal; virou derivada, e derivada sem prova regride calado.
  LEAF_ALLOWED_SECRET_ENV,
  _buildUserInput: buildUserInput,
  _comColaboracaoPadrao: comColaboracaoPadrao,
  COLABORACAO_PADRAO_CODEX,
  _sandboxPolicyFor: sandboxPolicyFor,
  _threadConfigFor: threadConfigFor,
  _leafPermissionEnvelopeFor: leafPermissionEnvelopeFor,
  _resolveLeafCodexHome: resolveLeafCodexHome,
  _leafAppServerArgs: (base = ['app-server']) => [
    ...Array.from(base, String), ...LEAF_APP_SERVER_CONFIG_ARGS,
  ],
  _leafPermissionProfileDefinitions: LEAF_PERMISSION_PROFILE_DEFINITIONS,
  _leafPermissionProfilesToml: LEAF_PERMISSION_PROFILES_TOML,
  _normalizeWorkerCapabilities: normalizeWorkerCapabilities,
  _normalizeDirectories: normalizeDirectories,
  _output: output,
  _linhaThreadStart: linhaThreadStart,
  _dadosThreadStart: dadosThreadStart,
  _normalizeRateLimits: normalizeRateLimits,
  _normalizeTokenUsage: normalizeTokenUsage,
  _acumulaUsoTurno: acumulaUsoTurno,
  _novoUsoTurno: novoUsoTurno,
  _publicoUsoTurno: publicoUsoTurno,
  compactaEmTokens,
  dossiePosCompactaLigado,
  _changedDossierItems: changedDossierItems,
  saidaFerramentaTokens,
  _economiaConfigArgs: economiaConfigArgs,
  _ehCompactacao: ehCompactacao,
  _contaCompactacoes: contaCompactacoes,
};
