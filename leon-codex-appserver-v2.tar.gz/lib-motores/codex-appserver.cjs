'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');

const {
  CodexAppServerAdapter,
  TurnTimeoutError,
} = require('../appserver/adapter.cjs');

const SEP_FALA = '===== FALA DO DONO =====';
const DEFAULT_TIMEOUT_MS = numberFromEnv('CODEX_TIMEOUT_SEG', 240) * 1_000;
// Secret-looking variables are opt-in. The Google MCP bridge can pass
// ['GOG_KEYRING_PASSWORD', 'GOG_ACCOUNT'] when it deliberately needs them.
const DEFAULT_ALLOWED_SECRET_ENV = Object.freeze([]);

const capacidades = Object.freeze({
  promptSistemaSeparado: true,
  retomaSessao: true,
  tetoCustoNativo: false,
  reportaCusto: false,
  saidaEstruturada: true,
  controlePermissao: true,
  modeloSelecionavel: true,
  effort: true,
  diretoriosExtras: true,
  compactacaoNativa: false,
  // ORQUESTRA (5-C): o app-server do Codex NÃO restringe a caixa de ferramenta
  // por turno — só aplica sandboxPolicy de acesso a disco/rede. Estreitar o
  // toolsAllow de 54 pra 1 mata o turno (C09, 03-problemas-reproduzidos.md:627).
  // Por isso declara false, e o gate fail-closed recusa subir o subagente aqui:
  // "esse ajudante só liga no motor Claude por enquanto".
  restringeFerramentas: false,
  // O corte do turno aqui e o RPC `turn/interrupt`: ele mata o TURNO e deixa a THREAD
  // valida no app-server. Por isso o /para pode PRESERVAR o sid (a conversa continua).
  cancelaPreservandoSessao: true,
});

function createMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const command = options.command || resolveCodexBin(envSource);
  const adapterOptions = options.adapterOptions || {};
  const fixedAdapter = options.adapter || null;
  let adapter = fixedAdapter;
  let adapterGeneration = null;
  const threadStates = new Map();
  const sessionLocks = new Map();
  const sessionsInUse = new Set();
  const activeTurns = new Map();
  const maxTrackedThreads = intOption(options.maxTrackedThreads, 64);
  let adapterComRateListener = null;
  let adapterComCicloListener = null;

  function getAdapter() {
    if (!adapter) {
      adapter = new CodexAppServerAdapter({
        command,
        args: ['app-server'],
        cwd: options.processCwd || process.cwd(),
        envSource,
        // TETO DE MENSAGEM DO PROTOCOLO (cura 10/09): o default de 1MB do adapter matava turnos
        // quando o Codex emitia UMA linha de evento >1MB (ler/gerar arquivo grande, output de tool
        // gordo) — o dono via "conteúdo demais, me peça como missão" e o trabalho morria. O adapter
        // lê linha a linha em memória; com folga de RAM, 16MB cobre os eventos reais sem risco.
        // Configurável por CODEX_MAX_MSG_BYTES pra a frota afinar por hardware.
        maxMessageBytes: Number(envSource.CODEX_MAX_MSG_BYTES) || 16 * 1024 * 1024,
        env: {
          RUST_LOG: envSource.CODEX_RUST_LOG || 'warn',
          CODEX_HOME: envSource.LEON_CODEX_HOME || envSource.CODEX_HOME,
          // token do MCP oficial da Meta (meta-connect): o config.toml referencia por
          // bearer_token_env_var, então a variável PRECISA existir no processo do app-server.
          // Ausente = spread vazio, zero efeito. O valor nunca é logado.
          ...(envSource.META_MCP_TOKEN ? { META_MCP_TOKEN: envSource.META_MCP_TOKEN } : {}),
          // CAMINHO do arquivo de configuração da casa (F4). É caminho, nunca o valor: o token
          // segue barrado no env do motor pelo deny pattern, como deve ser. Isto só diz ao
          // agente ONDE fica o cofre, pra ele carregar na hora do comando (set -a; . "$LEON_ENV_FILE")
          // quando precisar falar com uma API que os atalhos prontos não cobrem. Sem isto a
          // doutrina da liberdade manda usar a API e não diz onde está a chave.
          ...(envSource.LEON_ENV_FILE ? { LEON_ENV_FILE: envSource.LEON_ENV_FILE } : {}),
        },
        allowedSecretEnv: Array.isArray(options.allowedSecretEnv)
          ? options.allowedSecretEnv
          : DEFAULT_ALLOWED_SECRET_ENV,
        clientInfo: {
          name: 'leon_codex',
          title: 'LEON Codex',
          version: String(options.version || '1.0.0'),
        },
        requestTimeoutMs: intOption(options.requestTimeoutMs, 15_000),
        turnTimeoutMs: intOption(options.turnTimeoutMs, DEFAULT_TIMEOUT_MS),
        maxBufferedNotifications: intOption(options.maxBufferedNotifications, 256),
        maxBufferedNotificationBytes: intOption(options.maxBufferedNotificationBytes, 1_048_576),
        maxActiveTurns: intOption(options.maxActiveTurns, 16),
        autoRestart: options.autoRestart !== false,
        ...adapterOptions,
        // excludeTurns on thread/resume is capability-gated in Codex 0.147.0.
        capabilities: {
          ...(adapterOptions.capabilities || {}),
          experimentalApi: true,
        },
      });
    }
    // SALA DE TOKENS (30/08): account/rateLimits/updated tem escopo de CONTA (sem threadId),
    // então o _routeTurnNotification do adapter nunca a entrega no onNotification do turno —
    // ela só sai no emitter global ('notification'). O attach é 1x por instância de adapter:
    // autoRestart preserva o objeto (listener sobrevive); encerrar() anula o adapter e o
    // próximo getAdapter() cria outro e re-anexa. Observador puro: um throw no callback do
    // chamador não pode derrubar o turno.
    //
    // EVENTO NEUTRO DE MOTOR (04/09): quem escuta hoje é `onEventoMotor({tipo:'cota', cota})`,
    // um canal que qualquer motor futuro emite sem o bridge saber de rate limit de app-server.
    // `onRateLimits` continua aceito e recebe o mesmo snapshot: chamador antigo não quebra.
    const querEvento = typeof options.onEventoMotor === 'function' || typeof options.onRateLimits === 'function';
    if (adapter !== adapterComRateListener && querEvento && typeof adapter.on === 'function') {
      adapter.on('notification', (message) => {
        if (!message || message.method !== 'account/rateLimits/updated') return;
        const snapshot = normalizeRateLimits(message.params);
        if (!snapshot) return;
        if (typeof options.onEventoMotor === 'function') {
          try { options.onEventoMotor({ tipo: 'cota', motor: 'codex', cota: snapshot }); } catch {}
        }
        if (typeof options.onRateLimits === 'function') {
          try { options.onRateLimits(snapshot); } catch {}
        }
      });
      adapterComRateListener = adapter;
    }
    // CICLO DE VIDA DO APP-SERVER (11/09): ready/childExit/restartScheduled/restartFailed/retired eram
    // safeEmit SEM listener — por isso o log nunca mostrava crash/religamento e a investigação demorou 2
    // dias (confundimos restart-meu com crash). Só log, não muda comportamento. Off: CODEX_APPSERVER_LOG_CICLO=0.
    if (adapter !== adapterComCicloListener && process.env.CODEX_APPSERVER_LOG_CICLO !== '0' && typeof adapter.on === 'function') {
      const log = (m) => { try { console.log(`[app-server] ${m}`); } catch {} };
      adapter.on('ready', (e) => log(`subiu (gen ${e && e.generation}, pid ${e && e.pid})`));
      adapter.on('childExit', (e) => log(`CAIU inesperado (gen ${e && e.generation}, code=${e && e.code}, signal=${(e && e.signal) || 'none'})`));
      adapter.on('restartScheduled', (e) => log(`religando em ${e && e.delayMs}ms`));
      adapter.on('restartFailed', (err) => log(`religar falhou: ${err && err.message}`));
      adapter.on('retired', (e) => log(`desistiu de religar após ${e && e.crashes} quedas em 60s; o próximo turno sobe processo novo via start()`));
      adapterComCicloListener = adapter;
    }
    return adapter;
  }

  function syncGeneration(client) {
    const generation = client.status().generation;
    if (adapterGeneration !== generation) {
      threadStates.clear();
      adapterGeneration = generation;
    }
    return generation;
  }

  async function responder(entrada = {}) {
    const requestedSessionId = stringOrNull(entrada.sessaoId);
    const lockKey = requestedSessionId ? `session:${requestedSessionId}` : Symbol('new-thread');
    return withLock(sessionLocks, lockKey, async () => {
      let sessionId = requestedSessionId;
      let client = null;
      let generation = null;
      if (sessionId) sessionsInUse.add(sessionId);
      try {
        client = getAdapter();
        await client.start();
        generation = syncGeneration(client);
        const cwd = effectiveCwd(entrada, envSource);
        const dossie = String(entrada.dossie || '');
        const model = stringOrNull(entrada.modelo);
        // ACESSO TOTAL (04/09, decisao do dono): o cliente roda EXATAMENTE como o motor
        // mestre, sem sandbox. Provado no 99: o perfil de permissoes nomeado
        // (default_permissions) mantem o isolamento ligado mesmo sob
        // sandbox_mode = "danger-full-access" e o Codex morre em
        // "bwrap: setting up uid map: Permission denied". Por isso o perfil saiu do config
        // e daqui, e o turno declara sandboxPolicy de acesso total.
        // dangerFullAccess e variante unitaria do enum SandboxPolicy do app-server
        // (Codex 0.147.0): { type: 'dangerFullAccess' }, sem campos.
        const threadParams = compactObject({
          cwd,
          developerInstructions: dossie || null,
          model,
          approvalPolicy: options.approvalPolicy || 'never',
          config: options.threadConfig || undefined,
          sandboxPolicy: { type: 'dangerFullAccess' },
          ephemeral: sessionId ? undefined : false,
        });

        if (sessionId) {
          const loadedKey = `${generation}\u0000${sessionId}`;
          if (!threadStates.has(loadedKey)) {
            const resumed = await client.resumeThread(sessionId, {
              ...threadParams,
              // The bridge needs only the durable id. Returning all turns can
              // make one JSONL response exceed the adapter's safety cap on a
              // long or image-heavy conversation.
              excludeTurns: true,
            }, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            if (sessionId !== resumed.threadId) {
              sessionsInUse.delete(sessionId);
              sessionsInUse.add(resumed.threadId);
            }
            sessionId = resumed.threadId;
            const resumedKey = `${generation}\u0000${sessionId}`;
            // Also inject on a cold resume. Codex 0.147.0 accepts the plain
            // resume override but can omit it from the first resumed model
            // request; the persisted developer item closes that gap.
            const resumedDossierHash = dossierHash(dossie);
            await client.injectItems(sessionId, [developerDossierItem(dossie, resumedDossierHash)], {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            rememberThread(threadStates, resumedKey, resumedDossierHash);
          } else {
            touchThread(threadStates, loadedKey);
          }
        } else {
          const started = await client.startThread(threadParams, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          sessionId = started.threadId;
          sessionsInUse.add(sessionId);
          const startedKey = `${generation}\u0000${sessionId}`;
          rememberThread(threadStates, startedKey, dossierHash(dossie));
        }

        // Codex 0.147.0 ignores thread/resume overrides for an already-loaded
        // thread. Append a developer item only when LEON's dynamic dossier
        // changes, so the next model request sees the new revision without
        // copying a large system prompt into every user message.
        const dossierKey = `${generation}\u0000${sessionId}`;
        const nextDossierHash = dossierHash(dossie);
        const previousDossierHash = threadStates.get(dossierKey);
        if (previousDossierHash !== undefined && previousDossierHash !== nextDossierHash) {
          await client.injectItems(sessionId, [developerDossierItem(dossie, nextDossierHash)], {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          rememberThread(threadStates, dossierKey, nextDossierHash);
        }

        const timeoutMs = timeoutFor(entrada);
        const input = buildUserInput(entrada);
        const turnParams = compactObject({
          threadId: sessionId,
          input,
          cwd,
          model,
          effort: stringOrNull(entrada.effort),
          // Acesso total tambem no turno: o thread carrega a politica, o turno a repete
          // pra que um resume de thread antiga nao herde sandbox de uma versao anterior.
          sandboxPolicy: { type: 'dangerFullAccess' },
        });
        // CONSERTO DO ctxTokens (30/08): thread/tokenUsage/updated chega COM threadId+turnId,
        // então o adapter já a roteia pro onNotification deste turno. Guarda o último
        // tokenUsage e o output() devolve o total real no lugar do null histórico — o
        // persistSession do bridge passa a gravar número de verdade sem mudança de encanamento.
        let ultimoTokenUsage = null;
        const onEventoExterno = typeof entrada.onEvento === 'function' ? entrada.onEvento : null;
        const onNotificationTurno = (n) => {
          try {
            if (n && n.method === 'thread/tokenUsage/updated' && n.params && n.params.tokenUsage) {
              ultimoTokenUsage = n.params.tokenUsage;
            }
          } catch {}
          if (onEventoExterno) onEventoExterno(n);
        };
        const handle = await client.startTurn(turnParams, {
          timeoutMs,
          idleTimeoutMs: Number(entrada.idleTimeoutMs) > 0 ? Number(entrada.idleTimeoutMs) : 0,
          requestTimeoutMs: Math.min(timeoutMs, requestTimeoutFor(entrada, options)),
          onDelta: typeof entrada.onDelta === 'function' ? entrada.onDelta : null,
          onNotification: onNotificationTurno,
        });
        activeTurns.set(sessionId, handle);
        let result;
        try {
          result = await handle.completion;
        } finally {
          if (activeTurns.get(sessionId) === handle) activeTurns.delete(sessionId);
        }

        const text = String(result.finalText || '').trim();
        const turnError = formatTurnError(result);
        if (!text) {
          return output({
            erro: turnError || `Codex encerrou o turno com status ${result.status || 'desconhecido'} sem resposta`,
            cota: isLimitMessage(turnError),
            sessaoId: sessionId,
          });
        }
        const totalTurno = ultimoTokenUsage && ultimoTokenUsage.total
          && Number.isFinite(ultimoTokenUsage.total.totalTokens)
          ? ultimoTokenUsage.total.totalTokens : null;
        return output({
          texto: text,
          erro: turnError,
          cota: isLimitMessage(text) || isLimitMessage(turnError),
          custoUSD: null,
          sessaoId: sessionId,
          ctxTokens: totalTurno,
          uso: normalizeTokenUsage(ultimoTokenUsage),
        });
      } catch (error) {
        const message = formatAdapterError(error);
        return output({
          erro: message,
          cota: isLimitMessage(message),
          sessaoId: sessionId,
        });
      } finally {
        if (sessionId) sessionsInUse.delete(sessionId);
        if (client && generation != null) {
          await enforceThreadLimit({
            client,
            generation,
            threadStates,
            sessionsInUse,
            activeTurns,
            maxTrackedThreads,
            timeoutMs: intOption(options.requestTimeoutMs, 15_000),
          });
        }
      }
    });
  }

  async function encerrar(handle) {
    if (handle && typeof handle.interrupt === 'function') {
      try { await handle.interrupt(); } catch {}
      return;
    }
    if (typeof handle === 'string') {
      const active = activeTurns.get(handle);
      if (active) {
        try { await active.interrupt(); } catch {}
      }
      return;
    }
    if (adapter) {
      try { await adapter.close(); } catch {}
      if (!fixedAdapter) adapter = null;
      threadStates.clear();
      sessionsInUse.clear();
      adapterGeneration = null;
    }
  }

  // CATÁLOGO DE MODELOS DA CONTA (2.4.38). Contrato NEUTRO de motor: devolve o array cru de
  // itens do motor, ou null quando o motor não sabe listar. FAIL-SOFT de propósito — o seletor
  // do bridge cai na escada do .env e o dono continua escolhendo; um catálogo que não veio
  // nunca pode calar o comando. Timeout curto: isto roda na frente de um dono esperando.
  async function listarModelos(opts = {}) {
    try {
      const client = getAdapter();
      const out = await client.listModels({}, {
        timeoutMs: intOption(opts.timeoutMs, intOption(options.requestTimeoutMs, 15_000)),
      });
      if (Array.isArray(out)) return out;
      if (out && Array.isArray(out.data)) return out.data;
      return null;
    } catch (error) {
      return null;
    }
  }

  async function resetar(sessionId) {
    const target = stringOrNull(sessionId);
    if (!target) return { ok: true, sessaoId: null };
    return withLock(sessionLocks, `session:${target}`, async () => {
      let deleteStarted = false;
      try {
        const client = getAdapter();
        await client.start();
        const generation = syncGeneration(client);
        if (activeTurns.has(target) || sessionsInUse.has(target)) {
          throw new Error(`thread ${target} ainda possui turno ativo`);
        }
        deleteStarted = true;
        await client.deleteThread(target, {
          timeoutMs: intOption(options.requestTimeoutMs, 15_000),
        });
        for (const key of [...threadStates.keys()]) {
          if (key === `${generation}\u0000${target}` || key.endsWith(`\u0000${target}`)) threadStates.delete(key);
        }
        sessionsInUse.delete(target);
        activeTurns.delete(target);
        return { ok: true, sessaoId: target };
      } catch (error) {
        if (threadAlreadyAbsent(error, target)) {
          for (const key of [...threadStates.keys()]) {
            if (key.endsWith(`\u0000${target}`)) threadStates.delete(key);
          }
          sessionsInUse.delete(target);
          activeTurns.delete(target);
          return { ok: true, sessaoId: target };
        }
        if (!deleteStarted && error && error.dispatched === undefined) {
          try {
            error.method = 'thread/delete';
            error.dispatched = false;
          } catch {}
        }
        throw error;
      }
    });
  }

  return {
    nome: 'codex',
    bin: command,
    capacidades,
    disponivel() { return binaryAvailable(command, envSource.PATH); },
    responder,
    resetar,
    encerrar,
    listarModelos,
    turnosAtivos() { return activeTurns.size; },
    turnoVivo(sid) { return typeof sid === 'string' && activeTurns.has(sid); }, // cura /parar 10/09: checagem por-sid pro poll de confirmacao
    _adapter() { return adapter; },
  };
}

// Traduz account/rateLimits/updated (codex 0.147.0, capturado cru no bench 30/08) num
// snapshot NEUTRO de motor — o contrato com o bridge:
//   { motor, plano, credits, limiteBatido, janelas:[{ id, usadoPct, resetsAt, windowMins }] }
// primary = janela de 5h (300 min), secondary = semanal (10080 min). resetsAt é epoch em
// SEGUNDOS: relativo por construção, imune a fuso. Conta unlimited/pré-paga pode vir sem
// usedPercent útil — os campos ficam null e o bridge decide o que mostrar. Qualquer motor
// futuro que entregue este formato herda a sala de tokens inteira.
function normalizeRateLimits(params) {
  const rl = params && params.rateLimits;
  if (!rl || typeof rl !== 'object') return null;
  const janelas = [];
  const janela = (id, w) => {
    if (!w || typeof w !== 'object') return;
    janelas.push({
      id,
      usadoPct: Number.isFinite(w.usedPercent) ? w.usedPercent : null,
      resetsAt: Number.isFinite(w.resetsAt) ? w.resetsAt : null,
      windowMins: Number.isFinite(w.windowDurationMins) ? w.windowDurationMins : null,
    });
  };
  janela('5h', rl.primary);
  janela('semana', rl.secondary);
  if (!janelas.length) return null;
  return {
    motor: 'codex',
    plano: rl.planType || null,
    credits: rl.credits && typeof rl.credits === 'object' ? {
      hasCredits: Boolean(rl.credits.hasCredits),
      unlimited: Boolean(rl.credits.unlimited),
      balance: rl.credits.balance != null ? String(rl.credits.balance) : null,
    } : null,
    limiteBatido: rl.rateLimitReachedType != null,
    janelas,
  };
}

function buildUserInput(entrada) {
  const parts = [];
  // M1 (porte adaptado do mestre): o app-server é UM processo de vida longa, compartilhado
  // entre salas — env de processo seria estático e assinaria a sala errada. Então a assinatura
  // de origem viaja POR TURNO, no input. A doutrina _MOTOR-CODEX.md manda copiar
  // $LEON_ORIGEM_CHAT/$LEON_ORIGEM_THREAD pro arquivo de promessa; esta linha entrega os valores
  // deste turno pro agente usar (ele exporta no shell antes de gravar a promessa). Sem origem,
  // nada é injetado e o turno segue igual a antes.
  const origem = (entrada && entrada.origem && typeof entrada.origem === 'object') ? entrada.origem : {};
  if (origem.LEON_ORIGEM_CHAT != null && origem.LEON_ORIGEM_CHAT !== '') {
    parts.push(
      '===== ORIGEM DESTE TURNO (M1) =====\n'
      + 'Antes de gravar qualquer arquivo de promessa, exporte no shell os valores desta sala e '
      + 'copie-os pra origemChatId/origemThreadId (nunca invente nem troque):\n'
      + `export LEON_ORIGEM_CHAT=${JSON.stringify(String(origem.LEON_ORIGEM_CHAT))}\n`
      + `export LEON_ORIGEM_THREAD=${JSON.stringify(String(origem.LEON_ORIGEM_THREAD == null ? '' : origem.LEON_ORIGEM_THREAD))}\n`
      + `export LEON_ORIGEM_T0=${JSON.stringify(String(origem.LEON_ORIGEM_T0 == null ? '' : origem.LEON_ORIGEM_T0))}`
    );
  }
  if (entrada.contexto) parts.push(String(entrada.contexto));
  parts.push(`${SEP_FALA}\n${String(entrada.fala || '')}`);
  return [{ type: 'text', text: parts.join('\n\n') }];
}

function dossierHash(dossie) {
  return createHash('sha256').update(String(dossie || ''), 'utf8').digest('hex');
}

function developerDossierItem(dossie, revision) {
  const text = String(dossie || '');
  return {
    type: 'message',
    role: 'developer',
    content: [{
      type: 'input_text',
      text: [
        `<leon_dossier revision="${revision}">`,
        'Esta revisão substitui integralmente todos os dossiês LEON anteriores.',
        text,
        '</leon_dossier>',
      ].join('\n'),
    }],
  };
}

function rememberThread(threadStates, key, dossierRevision) {
  threadStates.delete(key);
  threadStates.set(key, dossierRevision);
}

function touchThread(threadStates, key) {
  if (!threadStates.has(key)) return;
  const value = threadStates.get(key);
  rememberThread(threadStates, key, value);
}

async function enforceThreadLimit({
  client,
  generation,
  threadStates,
  sessionsInUse,
  activeTurns,
  maxTrackedThreads,
  timeoutMs,
}) {
  while (threadStates.size > maxTrackedThreads) {
    let candidateKey = null;
    let candidateSessionId = null;
    for (const key of threadStates.keys()) {
      const separator = key.indexOf('\u0000');
      const keyGeneration = Number(key.slice(0, separator));
      const threadId = key.slice(separator + 1);
      if (separator < 0 || keyGeneration !== generation) continue;
      if (sessionsInUse.has(threadId) || activeTurns.has(threadId)) continue;
      candidateKey = key;
      candidateSessionId = threadId;
      break;
    }
    if (!candidateKey) return;
    threadStates.delete(candidateKey);
    try {
      await client.unsubscribeThread(candidateSessionId, { timeoutMs });
    } catch {}
  }
}

function effectiveCwd(entrada, envSource) {
  const dirs = Array.isArray(entrada.diretorios) ? entrada.diretorios : [];
  const raw = entrada.cwd || dirs.find(Boolean) || envSource.HOME || os.homedir() || process.cwd();
  return path.resolve(String(raw));
}

function normalizeDirectories(value, cwd) {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || !item.trim()) continue;
    unique.add(path.resolve(cwd, item));
  }
  return [...unique];
}

function resolveCodexBin(envSource) {
  if (envSource.CODEX_BIN) { try { fs.accessSync(envSource.CODEX_BIN, fs.constants.X_OK); return envSource.CODEX_BIN; } catch {} }
  const home = envSource.HOME || os.homedir();
  const dataDir = envSource.LEON_DATA_DIR || path.join(home, ".leon");
  const version = envSource.LEON_CODEX_CLI_VERSION || "0.147.0";
  const expected = path.join(dataDir, "codex-cli", "releases", version, "bin", "codex");
  for (const candidate of [
    expected,
    path.join(home, ".npm-global/bin/codex"),
    "/usr/local/bin/codex",
    "/usr/bin/codex",
  ]) {
    try { if (candidate) { fs.accessSync(candidate, fs.constants.X_OK); return candidate; } } catch {}
  }
  return "codex";
}

function binaryAvailable(command, pathValue) {
  if (command.includes(path.sep)) {
    try { fs.accessSync(command, fs.constants.X_OK); return true; } catch { return false; }
  }
  return String(pathValue || '').split(path.delimiter).some((dir) => {
    if (!dir) return false;
    try { fs.accessSync(path.join(dir, command), fs.constants.X_OK); return true; } catch { return false; }
  });
}

function timeoutFor(entrada) {
  return intOption(entrada.timeoutMs, DEFAULT_TIMEOUT_MS);
}

function requestTimeoutFor(entrada, options) {
  const configured = intOption(options.requestTimeoutMs, 15_000);
  return Math.min(timeoutFor(entrada), configured);
}

function formatTurnError(result) {
  if (result.status === 'completed') return null;
  const detail = result.error?.message || result.error?.additionalDetails || '';
  return `Codex encerrou o turno com status ${result.status || 'desconhecido'}${detail ? `: ${detail}` : ''}`;
}

function formatAdapterError(error) {
  if (error instanceof TurnTimeoutError) {
    return `timeout de ${Math.max(1, Math.ceil(error.timeoutMs / 1_000))}s no Codex`;
  }
  const base = error?.message || 'não consegui rodar o Codex';
  const stderr = Array.isArray(error?.stderr) ? error.stderr.slice(-5).join('\n') : '';
  return stderr && !base.includes(stderr) ? `${base}\n${stderr}` : base;
}

function output(value = {}) {
  return {
    texto: typeof value.texto === 'string' ? value.texto : '',
    custoUSD: Number.isFinite(value.custoUSD) ? value.custoUSD : null,
    sessaoId: value.sessaoId || null,
    erro: value.erro || null,
    cota: Boolean(value.cota),
    ctxTokens: Number.isFinite(value.ctxTokens) ? value.ctxTokens : null,
    // USO DO TURNO (2.4.31), campo NEUTRO de motor: os subcampos que o bridge precisa pra
    // decidir teto de thread e pra mostrar o credito no /cota. Motor que nao reporta manda
    // null e o bridge segue na estimativa de sempre.
    uso: value.uso && typeof value.uso === 'object' ? value.uso : null,
  };
}
// Traduz o tokenUsage do app-server (thread/tokenUsage/updated) no formato neutro:
//   { entrada, cache, saida, raciocinio, total }
// O evento traz `last` (o turno) e `total` (a thread inteira). O TETO DE THREAD olha a
// ENTRADA do ultimo turno, que e o tamanho real da janela que o motor esta reenviando. Versao
// do app-server que nao traga os subcampos cai no total, como o brief manda.
function normalizeTokenUsage(tokenUsage) {
  if (!tokenUsage || typeof tokenUsage !== 'object') return null;
  const fonte = tokenUsage.last && typeof tokenUsage.last === 'object' ? tokenUsage.last : tokenUsage;
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
  const entrada = num(fonte.inputTokens ?? fonte.input_tokens);
  const cache = num(fonte.cachedInputTokens ?? fonte.cached_input_tokens);
  const saida = num(fonte.outputTokens ?? fonte.output_tokens);
  const raciocinio = num(fonte.reasoningOutputTokens ?? fonte.reasoning_output_tokens);
  const total = num(fonte.totalTokens ?? fonte.total_tokens)
    ?? num(tokenUsage.total && (tokenUsage.total.totalTokens ?? tokenUsage.total.total_tokens));
  if (entrada == null && cache == null && saida == null && total == null) return null;
  return { entrada, cache, saida, raciocinio, total };
}

function isLimitMessage(value) {
  const text = String(value || '');
  return text.length < 500 && /(hit your limit|usage limit|limit reached|rate.?limit|credit balance|balance is too low|too many requests|usageLimitExceeded)/i.test(text);
}

function threadAlreadyAbsent(error, threadId) {
  return Boolean(error
    && error.method === 'thread/delete'
    && error.dispatched === true
    && error.code === -32600
    && error.data === undefined
    && error.rpcMessage === `no rollout found for thread id ${String(threadId)}`);
}

function compactObject(value) {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined && item !== null));
}

function stringOrNull(value) {
  return value == null || value === '' ? null : String(value);
}

function intOption(value, fallback) {
  const number = Number(value == null ? fallback : value);
  if (!Number.isSafeInteger(number) || number <= 0) return fallback;
  return number;
}

function numberFromEnv(name, fallback) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function withLock(locks, key, operation) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  locks.set(key, current);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (locks.get(key) === current) locks.delete(key);
  }
}

const defaultMotor = createMotor();

module.exports = {
  ...defaultMotor,
  createMotor,
  _buildUserInput: buildUserInput,
  _normalizeDirectories: normalizeDirectories,
  _output: output,
  _normalizeRateLimits: normalizeRateLimits,
  _normalizeTokenUsage: normalizeTokenUsage,
};
