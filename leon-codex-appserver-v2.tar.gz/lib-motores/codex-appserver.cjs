'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');

const {
  CodexAppServerAdapter,
  TurnTimeoutError,
} = require('../appserver/adapter.cjs');

const SEP_FALA = '===== FALA DO DONO =====';
const DEFAULT_TIMEOUT_MS = numberFromEnv('CODEX_TIMEOUT_SEG', 240) * 1_000;
const WORKER_CAPABILITIES = Object.freeze(['web_search', 'image_generation']);
const LEAF_ALLOWED_SECRET_ENV = Object.freeze(['OPENAI_API_KEY']);
const LEAF_PROFILE_IDS = Object.freeze({
  worker: 'leon-worker',
  planner: 'leon-planner',
  reviewer: 'leon-reviewer',
  coordinator: 'leon-coordinator',
});
const LEAF_CREDENTIAL_DENIES = Object.freeze({
  '.env': 'deny',
  '*.env': 'deny',
  '**/*.env': 'deny',
  '**/auth.json': 'deny',
  '**/*credentials*.json': 'deny',
});

// 17/09 (provado dentro do namespace, nas duas topologias): o bwrap morria no
// execvp do proprio helper nativo do Codex, porque o diretorio onde o executavel
// vive nunca entrava no namespace da folha. O envelope so recebe as raizes privadas
// do job (LEON_WORK_AREA/leon-jobs/<id>/<frente>) e o binario mora fora delas:
// o prefixo global do npm no mestre (~/.npm-global), ~/.leon/codex-cli/releases/<v>
// na casa de cliente. Consequencia medida: TODA frente morria antes de abrir arquivo, o revisor
// lia "a leitura dos arquivos falhou" e reprovava 3 rodadas; o dono ficou 2 dias sem
// nenhum trabalho concluir. E READ, nunca raiz de escrita: como raiz, o perfil do
// worker daria escrita e a folha poderia gravar no proprio motor.
function codexInstallPrefix() {
  try {
    const bin = resolveCodexBin(process.env || {});
    if (!bin) return "";
    return path.dirname(path.dirname(bin));
  } catch { return ""; }
}

function leafFilesystem(workspaceMode = null) {
  const filesystem = {
    ':root': 'deny',
    ':minimal': 'read',
    glob_scan_max_depth: 4,
  };
  const _prefixoCodex = codexInstallPrefix();
  if (_prefixoCodex) filesystem[`${_prefixoCodex}/**`] = 'read';
  if (workspaceMode) {
    filesystem[':workspace_roots'] = Object.freeze({
      './**': workspaceMode,
      ...LEAF_CREDENTIAL_DENIES,
    });
  }
  return Object.freeze(filesystem);
}

function leafProfile(description, workspaceMode = null) {
  return Object.freeze({
    description,
    filesystem: leafFilesystem(workspaceMode),
    network: Object.freeze({ enabled: false }),
  });
}

// Fonte unica dos perfis: o mesmo objeto gera o TOML de boot, alimenta o
// envelope auditavel e e inspecionado pelo preflight do instalador.
const LEAF_PERMISSION_PROFILE_DEFINITIONS = Object.freeze({
  [LEAF_PROFILE_IDS.worker]: leafProfile('LEON worker: private job roots only', 'write'),
  [LEAF_PROFILE_IDS.planner]: leafProfile('LEON planner: isolated snapshot only', 'read'),
  [LEAF_PROFILE_IDS.reviewer]: leafProfile('LEON reviewer: immutable snapshots only', 'read'),
  [LEAF_PROFILE_IDS.coordinator]: leafProfile('LEON coordinator: no workspace and no network'),
});

function inlineToml(value) {
  if (typeof value === 'string') return JSON.stringify(value);
  if (typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))) return String(value);
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return `{${Object.entries(value).map(([key, item]) => `${JSON.stringify(key)}=${inlineToml(item)}`).join(',')}}`;
  }
  throw new TypeError('valor nao suportado no TOML inline de permissoes');
}
// Perfis nomeados precisam existir quando o app-server nasce. Defini-los em
// `thread/start.config` parece válido no JSON, mas o resolvedor de permissões já
// fechou seu catálogo nessa altura; a thread fica sem tools. Os roots concretos
// continuam dinâmicos em `runtimeWorkspaceRoots`, enquanto estes quatro perfis
// estáticos determinam o tipo de acesso dentro deles.
const LEAF_PERMISSION_PROFILES_TOML = `permissions=${inlineToml(LEAF_PERMISSION_PROFILE_DEFINITIONS)}`;
// Folhas usam um segundo app-server. Estes overrides mordem no BOOT do
// processo, antes de existir thread, para que MCPs/plugins/hooks da cabeca nem
// entrem no catalogo da folha. Web e imagem continuam disponiveis no binario,
// mas so sao concedidos por thread em `threadConfigFor`.
const LEAF_APP_SERVER_CONFIG_ARGS = Object.freeze([
  '--strict-config',
  '-c', 'default_permissions="leon-coordinator"',
  '-c', LEAF_PERMISSION_PROFILES_TOML,
  '-c', 'mcp_servers={}',
  '-c', 'apps={}',
  '-c', 'plugins={}',
  '-c', 'hooks={}',
  '-c', 'marketplaces={}',
  '--disable', 'apps',
  '--disable', 'hooks',
  '--disable', 'multi_agent',
  '--disable', 'multi_agent_v2',
  '--disable', 'plugins',
  '--disable', 'remote_plugin',
  '--disable', 'skill_mcp_dependency_install',
  '--disable', 'skill_search',
  '--disable', 'memories',
  '--disable', 'goals',
  '--disable', 'recommended_plugins',
  '--disable', 'browser_use',
  '--disable', 'browser_use_external',
  '--disable', 'browser_use_full_cdp_access',
  '--disable', 'computer_use',
  '-c', 'allow_login_shell=false',
]);
// Secret-looking variables are opt-in. The Google MCP bridge can pass
// ['GOG_KEYRING_PASSWORD', 'GOG_ACCOUNT'] when it deliberately needs them.
// A instalação vendável aceita OAuth em CODEX_HOME ou chave fornecida pelo
// próprio cliente. A chave entra somente no processo do motor, nunca no worker
// como dado de prompt nem nas integrações do agente.
const capacidades = Object.freeze({
  promptSistemaSeparado: true,
  // O adapter acompanha hashes independentes da base e do estado vivo. O bridge
  // pode, portanto, mandar o contrato incremental sem depender do nome do motor.
  dossieIncremental: true,
  retomaSessao: true,
  tetoCustoNativo: false,
  reportaCusto: false,
  saidaEstruturada: true,
  controlePermissao: true,
  modeloSelecionavel: true,
  effort: true,
  diretoriosExtras: true,
  compactacaoNativa: false,
  // ORQUESTRA (5-C): o app-server do Codex NÃO restringe a caixa de ferramenta
  // por turno — só aplica sandboxPolicy de acesso a disco/rede. Estreitar o
  // toolsAllow de 54 pra 1 mata o turno (C09, 03-problemas-reproduzidos.md:627).
  // Por isso declara false, e o gate fail-closed recusa subir o subagente aqui:
  // "esse ajudante só liga no motor Claude por enquanto".
  restringeFerramentas: false,
  // O corte do turno aqui e o RPC `turn/interrupt`: ele mata o TURNO e deixa a THREAD
  // valida no app-server. Por isso o /para pode PRESERVAR o sid (a conversa continua).
  cancelaPreservandoSessao: true,
});

function createMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const command = options.command || resolveCodexBin(envSource);
  const adapterOptions = options.adapterOptions || {};
  const fixedAdapter = options.adapter || null;
  const fixedLeafAdapter = options.leafAdapter || null;
  let adapter = fixedAdapter;
  let leafAdapter = fixedLeafAdapter;
  let adapterGeneration = null;
  let leafAdapterGeneration = null;
  const threadStates = new Map();
  const leafThreadStates = new Map();
  const sessionLocks = new Map();
  const sessionsInUse = new Set();
  const activeTurns = new Map();
  const maxTrackedThreads = intOption(options.maxTrackedThreads, 64);
  let adapterComRateListener = null;
  let adapterComCicloListener = null;
  const sourceCodexHome = resolveSourceCodexHome(options, envSource);
  const leafCodexHome = resolveLeafCodexHome(options, envSource, sourceCodexHome);

  function makeAdapter(restricted) {
    const baseArgs = Array.isArray(adapterOptions.args)
      ? adapterOptions.args.map(String) : ['app-server'];
    const processArgs = restricted
      ? [...baseArgs, ...LEAF_APP_SERVER_CONFIG_ARGS]
      : baseArgs;
    const headOnlyEnv = restricted ? {} : {
      // A folha nunca recebe o token de MCP nem o caminho do cofre. A cabeca
      // preserva exatamente o comportamento historico.
      ...(envSource.META_MCP_TOKEN ? { META_MCP_TOKEN: envSource.META_MCP_TOKEN } : {}),
      ...(envSource.LEON_ENV_FILE ? { LEON_ENV_FILE: envSource.LEON_ENV_FILE } : {}),
    };
    if (restricted) ensureLeafCodexHome(leafCodexHome, sourceCodexHome);
    const effectiveEnvSource = restricted
      ? omitEnv(envSource, ['LEON_ENV_FILE', 'META_MCP_TOKEN'])
      : envSource;
    const adapterEnv = { ...(adapterOptions.env || {}) };
    if (restricted) {
      delete adapterEnv.LEON_ENV_FILE;
      delete adapterEnv.META_MCP_TOKEN;
    }
    const configuredSecrets = Array.isArray(options.allowedSecretEnv)
      ? [...new Set(options.allowedSecretEnv.map(String))]
      : [];
    const allowedSecretEnv = restricted
      ? configuredSecrets.filter((name) => LEAF_ALLOWED_SECRET_ENV.includes(name))
      : configuredSecrets;
    return new CodexAppServerAdapter({
      command,
      cwd: options.processCwd || process.cwd(),
      envSource: effectiveEnvSource,
      // TETO DE MENSAGEM DO PROTOCOLO (cura 10/09): o default de 1MB do adapter matava turnos
      // quando o Codex emitia UMA linha de evento >1MB (ler/gerar arquivo grande, output de tool
      // gordo) — o dono via "conteúdo demais, me peça como missão" e o trabalho morria. O adapter
      // lê linha a linha em memória; com folga de RAM, 16MB cobre os eventos reais sem risco.
      maxMessageBytes: Number(envSource.CODEX_MAX_MSG_BYTES) || 16 * 1024 * 1024,
      allowedSecretEnv,
      clientInfo: {
        name: restricted ? 'leon_codex_restricted' : 'leon_codex',
        title: restricted ? 'LEON Codex Restricted' : 'LEON Codex',
        version: String(options.version || '1.0.0'),
      },
      requestTimeoutMs: intOption(options.requestTimeoutMs, 15_000),
      turnTimeoutMs: intOption(options.turnTimeoutMs, DEFAULT_TIMEOUT_MS),
      maxBufferedNotifications: intOption(options.maxBufferedNotifications, 256),
      maxBufferedNotificationBytes: intOption(options.maxBufferedNotificationBytes, 1_048_576),
      // Um app-server de folha compartilhado atende o teto fisico de tres
      // workers; nao nasce um processo adicional por frente.
      maxActiveTurns: intOption(options.maxActiveTurns, 16),
      autoRestart: options.autoRestart !== false,
      ...adapterOptions,
      // Depois do spread: testes podem trocar binario/transport, mas nao podem
      // retirar o hardening nem reinjetar segredo no processo de folha.
      args: processArgs,
      envSource: effectiveEnvSource,
      allowedSecretEnv,
      env: {
        ...adapterEnv,
        RUST_LOG: envSource.CODEX_RUST_LOG || 'warn',
        CODEX_HOME: restricted ? leafCodexHome : sourceCodexHome,
        ...headOnlyEnv,
      },
      // excludeTurns on thread/resume is capability-gated in Codex 0.147.0.
      capabilities: {
        ...(adapterOptions.capabilities || {}),
        experimentalApi: true,
      },
    });
  }

  function getAdapter(entrada = {}) {
    const restricted = entrada.workerLeaf === true || entrada.plannerLeaf === true
      || entrada.reviewerLeaf === true || entrada.coordinatorHead === true;
    if (restricted) {
      if (!leafAdapter) leafAdapter = makeAdapter(true);
    } else if (!adapter) {
      adapter = makeAdapter(false);
    }
    const selected = restricted ? leafAdapter : adapter;
    // SALA DE TOKENS (30/08): account/rateLimits/updated tem escopo de CONTA (sem threadId),
    // então o _routeTurnNotification do adapter nunca a entrega no onNotification do turno —
    // ela só sai no emitter global ('notification'). O attach é 1x por instância de adapter:
    // autoRestart preserva o objeto (listener sobrevive); encerrar() anula o adapter e o
    // próximo getAdapter() cria outro e re-anexa. Observador puro: um throw no callback do
    // chamador não pode derrubar o turno.
    //
    // EVENTO NEUTRO DE MOTOR (04/09): quem escuta hoje é `onEventoMotor({tipo:'cota', cota})`,
    // um canal que qualquer motor futuro emite sem o bridge saber de rate limit de app-server.
    // `onRateLimits` continua aceito e recebe o mesmo snapshot: chamador antigo não quebra.
    const querEvento = typeof options.onEventoMotor === 'function' || typeof options.onRateLimits === 'function';
    if (selected !== adapterComRateListener && querEvento && typeof selected.on === 'function') {
      selected.on('notification', (message) => {
        if (!message || message.method !== 'account/rateLimits/updated') return;
        const snapshot = normalizeRateLimits(message.params);
        if (!snapshot) return;
        if (typeof options.onEventoMotor === 'function') {
          try { options.onEventoMotor({ tipo: 'cota', motor: 'codex', cota: snapshot }); } catch {}
        }
        if (typeof options.onRateLimits === 'function') {
          try { options.onRateLimits(snapshot); } catch {}
        }
      });
      adapterComRateListener = selected;
    }
    // CICLO DE VIDA DO APP-SERVER (11/09): ready/childExit/restartScheduled/restartFailed/retired eram
    // safeEmit SEM listener — por isso o log nunca mostrava crash/religamento e a investigação demorou 2
    // dias (confundimos restart-meu com crash). Só log, não muda comportamento. Off: CODEX_APPSERVER_LOG_CICLO=0.
    if (selected !== adapterComCicloListener && process.env.CODEX_APPSERVER_LOG_CICLO !== '0' && typeof selected.on === 'function') {
      const log = (m) => { try { console.log(`[app-server] ${m}`); } catch {} };
      selected.on('ready', (e) => log(`${restricted ? 'restrito ' : ''}subiu (gen ${e && e.generation}, pid ${e && e.pid})`));
      selected.on('childExit', (e) => log(`${restricted ? 'restrito ' : ''}CAIU inesperado (gen ${e && e.generation}, code=${e && e.code}, signal=${(e && e.signal) || 'none'})`));
      selected.on('restartScheduled', (e) => log(`${restricted ? 'restrito ' : ''}religando em ${e && e.delayMs}ms`));
      selected.on('restartFailed', (err) => log(`${restricted ? 'restrito ' : ''}religar falhou: ${err && err.message}`));
      selected.on('retired', (e) => log(`${restricted ? 'restrito ' : ''}desistiu de religar após ${e && e.crashes} quedas em 60s; o próximo turno sobe processo novo via start()`));
      adapterComCicloListener = selected;
    }
    return selected;
  }

  function syncGeneration(client) {
    const generation = client.status().generation;
    const leaf = client === leafAdapter;
    const states = leaf ? leafThreadStates : threadStates;
    const previous = leaf ? leafAdapterGeneration : adapterGeneration;
    if (previous !== generation) {
      states.clear();
      if (leaf) leafAdapterGeneration = generation;
      else adapterGeneration = generation;
    }
    return generation;
  }

  async function responder(entrada = {}) {
    const requestedSessionId = stringOrNull(entrada.sessaoId);
    if (entrada.plannerLeaf === true && requestedSessionId) {
      return output({ erro: 'planner leaf nao retoma sessao persistente: turno recusado por seguranca' });
    }
    const lockKey = requestedSessionId ? `session:${requestedSessionId}` : Symbol('new-thread');
    return withLock(sessionLocks, lockKey, async () => {
      let sessionId = requestedSessionId;
      let client = null;
      let generation = null;
      let states = null;
      if (sessionId) sessionsInUse.add(sessionId);
      try {
        client = getAdapter(entrada);
        await client.start();
        generation = syncGeneration(client);
        states = client === leafAdapter ? leafThreadStates : threadStates;
        const cwd = effectiveCwd(entrada, envSource);
        const dossier = normalizeDossierInput(entrada);
        const model = stringOrNull(entrada.modelo);
        // A cabeca continua com o acesso historico. Folhas nunca herdam a
        // maquina inteira so porque usam o mesmo app-server: worker recebe
        // workspaceWrite sem rede; planejador recebe readOnly sem rede e uma
        // configuracao que desliga integracoes/fan-out. A politica morde no
        // protocolo tanto no nascimento quanto em cada turno.
        const leafEnvelope = leafPermissionEnvelopeFor(entrada, cwd, {
          sourceCodexHome,
          leafCodexHome,
          envFile: envSource.LEON_ENV_FILE,
          protectedReadPaths: options.protectedReadPaths,
        });
        const sandboxPolicy = leafEnvelope ? undefined : sandboxPolicyFor(entrada, cwd);
        const threadConfig = threadConfigFor(entrada, options.threadConfig, leafEnvelope);
        // ACESSO TOTAL (04/09, decisao do dono): o cliente roda EXATAMENTE como o motor
        // mestre, sem sandbox. Provado no 99: o perfil de permissoes nomeado
        // (default_permissions) mantem o isolamento ligado mesmo sob
        // sandbox_mode = "danger-full-access" e o Codex morre em
        // "bwrap: setting up uid map: Permission denied". Por isso o perfil saiu do config
        // e daqui, e o turno declara sandboxPolicy de acesso total.
        // dangerFullAccess e variante unitaria do enum SandboxPolicy do app-server
        // (Codex 0.147.0): { type: 'dangerFullAccess' }, sem campos.
        const threadParams = compactObject({
          cwd,
          developerInstructions: dossier.developerInstructions || null,
          model,
          approvalPolicy: options.approvalPolicy || 'never',
          config: threadConfig,
          sandboxPolicy,
          permissions: leafEnvelope?.profileId,
          runtimeWorkspaceRoots: leafEnvelope?.runtimeWorkspaceRoots,
          // Planejamento e uma chamada descartavel. A SID continua existindo
          // enquanto o turno esta vivo (onSessao + /para), mas nao deixa uma
          // conversa persistente capaz de ser retomada sob outro perfil.
          ephemeral: entrada.plannerLeaf === true ? true : (sessionId ? undefined : false),
        });

        if (sessionId) {
          const loadedKey = `${generation}\u0000${sessionId}`;
          if (!states.has(loadedKey)) {
            logaThreadStart(threadParams, entrada.origem, true);
            const resumed = await client.resumeThread(sessionId, {
              ...threadParams,
              // The bridge needs only the durable id. Returning all turns can
              // make one JSONL response exceed the adapter's safety cap on a
              // long or image-heavy conversation.
              excludeTurns: true,
            }, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            if (sessionId !== resumed.threadId) {
              sessionsInUse.delete(sessionId);
              sessionsInUse.add(resumed.threadId);
            }
            sessionId = resumed.threadId;
            const resumedKey = `${generation}\u0000${sessionId}`;
            // Also inject on a cold resume. Codex 0.147.0 accepts the plain
            // resume override but can omit it from the first resumed model
            // request; the persisted developer item closes that gap.
            await client.injectItems(sessionId, dossier.coldResumeItems, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            rememberThread(states, resumedKey, dossier.state);
          } else {
            touchThread(states, loadedKey);
          }
        } else {
          logaThreadStart(threadParams, entrada.origem, false);
          const started = await client.startThread(threadParams, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          sessionId = started.threadId;
          sessionsInUse.add(sessionId);
          const startedKey = `${generation}\u0000${sessionId}`;
          rememberThread(states, startedKey, dossier.state);
        }

        // Codex 0.147.0 ignores thread/resume overrides for an already-loaded
        // thread. Append a developer item only when LEON's dynamic dossier
        // changes, so the next model request sees the new revision without
        // copying a large system prompt into every user message.
        const dossierKey = `${generation}\u0000${sessionId}`;
        const previousDossierState = states.get(dossierKey);
        const changedItems = changedDossierItems(previousDossierState, dossier);
        if (previousDossierState !== undefined && changedItems.length > 0) {
          await client.injectItems(sessionId, changedItems, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          // Never acknowledge a revision before the app-server persisted all
          // corresponding developer items. A failed injection is retried on
          // the next turn with the old hashes still intact.
          rememberThread(states, dossierKey, dossier.state);
        }

        const timeoutMs = timeoutFor(entrada);
        const input = buildUserInput(entrada);
        const turnParams = compactObject({
          threadId: sessionId,
          input,
          cwd,
          model,
          effort: stringOrNull(entrada.effort),
          // Codex 0.154 não possui `config` em TurnStartParams. Enviar o nome
          // de permissions outra vez faz o servidor tentar resolvê-lo fora da
          // tabela da thread e recusar com -32600. Perfis restritos ficam
          // vinculados em thread/start ou thread/resume (config + permissions
          // + runtimeWorkspaceRoots) e o turn/start herda essa policy. O head
          // legado continua repetindo apenas seu sandboxPolicy histórico.
          sandboxPolicy,
        });
        // CONSERTO DO ctxTokens (30/08): thread/tokenUsage/updated chega COM threadId+turnId,
        // então o adapter já a roteia pro onNotification deste turno. Guarda o último
        // tokenUsage e o output() devolve o total real no lugar do null histórico — o
        // persistSession do bridge passa a gravar número de verdade sem mudança de encanamento.
        let ultimoTokenUsage = null;
        const onEventoExterno = typeof entrada.onEvento === 'function' ? entrada.onEvento : null;
        const onNotificationTurno = (n) => {
          try {
            if (n && n.method === 'thread/tokenUsage/updated' && n.params && n.params.tokenUsage) {
              ultimoTokenUsage = n.params.tokenUsage;
            }
          } catch {}
          if (onEventoExterno) onEventoExterno(n);
        };
        const handle = await client.startTurn(turnParams, {
          timeoutMs,
          idleTimeoutMs: Number(entrada.idleTimeoutMs) > 0 ? Number(entrada.idleTimeoutMs) : 0,
          requestTimeoutMs: Math.min(timeoutMs, requestTimeoutFor(entrada, options)),
          onDelta: typeof entrada.onDelta === 'function' ? entrada.onDelta : null,
          onNotification: onNotificationTurno,
        });
        activeTurns.set(sessionId, handle);
        // Prova de vida por sessão para o orquestrador. O callback só dispara
        // depois que startTurn devolveu um handle realmente ativo; possuir um
        // timer ou um id antigo nunca é confundido com processo em execução.
        if (typeof entrada.onSessao === 'function') {
          try { entrada.onSessao(sessionId); } catch {}
        }
        let result;
        try {
          result = await handle.completion;
        } finally {
          if (activeTurns.get(sessionId) === handle) activeTurns.delete(sessionId);
        }

        const text = String(result.finalText || '').trim();
        const turnError = formatTurnError(result);
        const totalTurno = ultimoTokenUsage && ultimoTokenUsage.total
          && Number.isFinite(ultimoTokenUsage.total.totalTokens)
          ? ultimoTokenUsage.total.totalTokens : null;
        if (!text) {
          return output({
            erro: turnError || `Codex encerrou o turno com status ${result.status || 'desconhecido'} sem resposta`,
            cota: isLimitMessage(turnError),
            sessaoId: sessionId,
            ctxTokens: totalTurno,
            uso: normalizeTokenUsage(ultimoTokenUsage),
          });
        }
        return output({
          texto: text,
          erro: turnError,
          cota: isLimitMessage(text) || isLimitMessage(turnError),
          custoUSD: null,
          sessaoId: sessionId,
          ctxTokens: totalTurno,
          uso: normalizeTokenUsage(ultimoTokenUsage),
        });
      } catch (error) {
        const message = formatAdapterError(error);
        return output({
          erro: message,
          cota: isLimitMessage(message),
          sessaoId: sessionId,
        });
      } finally {
        if (sessionId) sessionsInUse.delete(sessionId);
        if (entrada.plannerLeaf === true && sessionId) {
          for (const key of [...states.keys()]) {
            if (key.endsWith(`\u0000${sessionId}`)) states.delete(key);
          }
        }
        if (client && generation != null) {
          await enforceThreadLimit({
            client,
            generation,
            threadStates: states,
            sessionsInUse,
            activeTurns,
            maxTrackedThreads,
            timeoutMs: intOption(options.requestTimeoutMs, 15_000),
          });
        }
      }
    });
  }

  async function encerrar(handle) {
    if (handle && typeof handle.interrupt === 'function') {
      try { await handle.interrupt(); } catch {}
      return;
    }
    if (typeof handle === 'string') {
      const active = activeTurns.get(handle);
      if (active) {
        try { await active.interrupt(); } catch {}
      }
      return;
    }
    const clients = [...new Set([adapter, leafAdapter].filter(Boolean))];
    await Promise.allSettled(clients.map((client) => client.close()));
    if (!fixedAdapter) adapter = null;
    if (!fixedLeafAdapter) leafAdapter = null;
    threadStates.clear();
    leafThreadStates.clear();
    sessionsInUse.clear();
    adapterGeneration = null;
    leafAdapterGeneration = null;
  }

  // CATÁLOGO DE MODELOS DA CONTA (2.4.38). Contrato NEUTRO de motor: devolve o array cru de
  // itens do motor, ou null quando o motor não sabe listar. FAIL-SOFT de propósito — o seletor
  // do bridge cai na escada do .env e o dono continua escolhendo; um catálogo que não veio
  // nunca pode calar o comando. Timeout curto: isto roda na frente de um dono esperando.
  async function listarModelos(opts = {}) {
    try {
      const client = getAdapter();
      const out = await client.listModels({}, {
        timeoutMs: intOption(opts.timeoutMs, intOption(options.requestTimeoutMs, 15_000)),
      });
      if (Array.isArray(out)) return out;
      if (out && Array.isArray(out.data)) return out.data;
      return null;
    } catch (error) {
      return null;
    }
  }

  async function resetar(sessionId) {
    const target = stringOrNull(sessionId);
    if (!target) return { ok: true, sessaoId: null };
    return withLock(sessionLocks, `session:${target}`, async () => {
      let deleteStarted = false;
      try {
        const client = getAdapter();
        await client.start();
        const generation = syncGeneration(client);
        if (activeTurns.has(target) || sessionsInUse.has(target)) {
          throw new Error(`thread ${target} ainda possui turno ativo`);
        }
        deleteStarted = true;
        await client.deleteThread(target, {
          timeoutMs: intOption(options.requestTimeoutMs, 15_000),
        });
        for (const key of [...threadStates.keys()]) {
          if (key === `${generation}\u0000${target}` || key.endsWith(`\u0000${target}`)) threadStates.delete(key);
        }
        sessionsInUse.delete(target);
        activeTurns.delete(target);
        return { ok: true, sessaoId: target };
      } catch (error) {
        if (threadAlreadyAbsent(error, target)) {
          for (const key of [...threadStates.keys()]) {
            if (key.endsWith(`\u0000${target}`)) threadStates.delete(key);
          }
          sessionsInUse.delete(target);
          activeTurns.delete(target);
          return { ok: true, sessaoId: target };
        }
        if (!deleteStarted && error && error.dispatched === undefined) {
          try {
            error.method = 'thread/delete';
            error.dispatched = false;
          } catch {}
        }
        throw error;
      }
    });
  }

  return {
    nome: 'codex',
    bin: command,
    capacidades,
    disponivel() { return binaryAvailable(command, envSource.PATH); },
    responder,
    resetar,
    encerrar,
    listarModelos,
    turnosAtivos() { return activeTurns.size; },
    turnoVivo(sid) { return typeof sid === 'string' && activeTurns.has(sid); }, // cura /parar 10/09: checagem por-sid pro poll de confirmacao
    _adapter() { return adapter; },
    _leafAdapter() { return leafAdapter; },
  };
}

// Traduz account/rateLimits/updated (codex 0.147.0, capturado cru no bench 30/08) num
// snapshot NEUTRO de motor — o contrato com o bridge:
//   { motor, plano, credits, limiteBatido, janelas:[{ id, usadoPct, resetsAt, windowMins }] }
// primary = janela de 5h (300 min), secondary = semanal (10080 min). resetsAt é epoch em
// SEGUNDOS: relativo por construção, imune a fuso. Conta unlimited/pré-paga pode vir sem
// usedPercent útil — os campos ficam null e o bridge decide o que mostrar. Qualquer motor
// futuro que entregue este formato herda a sala de tokens inteira.
function normalizeRateLimits(params) {
  const rl = params && params.rateLimits;
  if (!rl || typeof rl !== 'object') return null;
  const janelas = [];
  const janela = (id, w) => {
    if (!w || typeof w !== 'object') return;
    janelas.push({
      id,
      usadoPct: Number.isFinite(w.usedPercent) ? w.usedPercent : null,
      resetsAt: Number.isFinite(w.resetsAt) ? w.resetsAt : null,
      windowMins: Number.isFinite(w.windowDurationMins) ? w.windowDurationMins : null,
    });
  };
  janela('5h', rl.primary);
  janela('semana', rl.secondary);
  if (!janelas.length) return null;
  return {
    motor: 'codex',
    plano: rl.planType || null,
    credits: rl.credits && typeof rl.credits === 'object' ? {
      hasCredits: Boolean(rl.credits.hasCredits),
      unlimited: Boolean(rl.credits.unlimited),
      balance: rl.credits.balance != null ? String(rl.credits.balance) : null,
    } : null,
    limiteBatido: rl.rateLimitReachedType != null,
    janelas,
  };
}

function buildUserInput(entrada) {
  const parts = [];
  // M1 (porte adaptado do mestre): o app-server é UM processo de vida longa, compartilhado
  // entre salas — env de processo seria estático e assinaria a sala errada. Então a assinatura
  // de origem viaja POR TURNO, no input. A doutrina _MOTOR-CODEX.md manda copiar
  // $LEON_ORIGEM_CHAT/$LEON_ORIGEM_THREAD pro arquivo de promessa; esta linha entrega os valores
  // deste turno pro agente usar (ele exporta no shell antes de gravar a promessa). Sem origem,
  // nada é injetado e o turno segue igual a antes.
  const origem = entrada && entrada.coordinatorHead === true
    ? {}
    : ((entrada && entrada.origem && typeof entrada.origem === 'object') ? entrada.origem : {});
  if (origem.LEON_ORIGEM_CHAT != null && origem.LEON_ORIGEM_CHAT !== '') {
    parts.push(
      '===== ORIGEM DESTE TURNO (M1) =====\n'
      + 'Antes de gravar qualquer arquivo de promessa, exporte no shell os valores desta sala e '
      + 'copie-os pra origemChatId/origemThreadId (nunca invente nem troque):\n'
      + `export LEON_ORIGEM_CHAT=${JSON.stringify(String(origem.LEON_ORIGEM_CHAT))}\n`
      + `export LEON_ORIGEM_THREAD=${JSON.stringify(String(origem.LEON_ORIGEM_THREAD == null ? '' : origem.LEON_ORIGEM_THREAD))}\n`
      + `export LEON_ORIGEM_T0=${JSON.stringify(String(origem.LEON_ORIGEM_T0 == null ? '' : origem.LEON_ORIGEM_T0))}`
    );
  }
  if (entrada.contexto) parts.push(String(entrada.contexto));
  parts.push(`${SEP_FALA}\n${String(entrada.fala || '')}`);
  return [{ type: 'text', text: parts.join('\n\n') }];
}

function dossierHash(dossie) {
  return createHash('sha256').update(String(dossie || ''), 'utf8').digest('hex');
}

function normalizeDossierInput(entrada) {
  const split = hasOwn(entrada, 'dossieBase') || hasOwn(entrada, 'dossieDelta');
  if (!split) {
    const text = String(entrada.dossie || '');
    const hash = dossierHash(text);
    return {
      mode: 'legacy',
      developerInstructions: text,
      coldResumeItems: [developerDossierItem(text, hash)],
      state: Object.freeze({ mode: 'legacy', hash }),
    };
  }

  const baseText = String(entrada.dossieBase || '');
  const deltaText = String(entrada.dossieDelta || '');
  const baseRevision = dossierRevision(
    firstDefined(entrada.dossieBaseVersao, entrada.versaoDossieBase),
    baseText,
  );
  const deltaRevision = dossierRevision(
    firstDefined(entrada.dossieDeltaRevisao, entrada.revisaoDossieDelta),
    deltaText,
  );
  const baseHash = dossierPartHash(baseText, baseRevision);
  const deltaHash = dossierPartHash(deltaText, deltaRevision);
  const baseItem = developerDossierBaseItem(baseText, baseRevision);
  const deltaItem = developerDossierDeltaItem(deltaText, deltaRevision);
  return {
    mode: 'split',
    developerInstructions: [itemText(baseItem), itemText(deltaItem)].join('\n\n'),
    coldResumeItems: [baseItem, deltaItem],
    baseItem,
    deltaItem,
    state: Object.freeze({ mode: 'split', baseHash, deltaHash }),
  };
}

function changedDossierItems(previous, dossier) {
  if (dossier.mode === 'legacy') {
    if (previous && previous.mode === 'legacy' && previous.hash === dossier.state.hash) return [];
    return dossier.coldResumeItems;
  }
  const items = [];
  if (!previous || previous.mode !== 'split' || previous.baseHash !== dossier.state.baseHash) {
    items.push(dossier.baseItem);
  }
  if (!previous || previous.mode !== 'split' || previous.deltaHash !== dossier.state.deltaHash) {
    items.push(dossier.deltaItem);
  }
  return items;
}

function dossierRevision(value, text) {
  if (value !== undefined && value !== null && String(value) !== '') return String(value);
  return dossierHash(text);
}

function dossierPartHash(text, revision) {
  return createHash('sha256')
    .update(JSON.stringify([String(text || ''), String(revision || '')]), 'utf8')
    .digest('hex');
}

function developerDossierBaseItem(dossie, revision) {
  return developerMessage([
    `<leon_dossier_base revision="${escapeXmlAttribute(revision)}">`,
    'BASE ESTÁVEL DO DOSSIÊ LEON. Esta revisão substitui integralmente a base estável anterior.',
    String(dossie || ''),
    '</leon_dossier_base>',
  ]);
}

function developerDossierDeltaItem(dossie, revision) {
  const text = String(dossie || '');
  return developerMessage([
    `<leon_dossier_delta revision="${escapeXmlAttribute(revision)}">`,
    'ESTADO DINÂMICO: esta revisão substitui integralmente o ESTADO DINÂMICO anterior, inclusive por remoção.',
    text || '[ESTADO DINÂMICO REMOVIDO: desconsidere integralmente o estado dinâmico anterior.]',
    '</leon_dossier_delta>',
  ]);
}

function developerDossierItem(dossie, revision) {
  const text = String(dossie || '');
  return developerMessage([
    `<leon_dossier revision="${escapeXmlAttribute(revision)}">`,
    'Esta revisão substitui integralmente todos os dossiês LEON anteriores.',
    text,
    '</leon_dossier>',
  ]);
}

function developerMessage(lines) {
  return {
    type: 'message',
    role: 'developer',
    content: [{
      type: 'input_text',
      text: lines.join('\n'),
    }],
  };
}

function itemText(item) {
  return item.content[0].text;
}

function escapeXmlAttribute(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function firstDefined(...values) {
  return values.find((value) => value !== undefined && value !== null);
}

function hasOwn(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

function rememberThread(threadStates, key, dossierState) {
  threadStates.delete(key);
  threadStates.set(key, dossierState);
}

function touchThread(threadStates, key) {
  if (!threadStates.has(key)) return;
  const value = threadStates.get(key);
  rememberThread(threadStates, key, value);
}

async function enforceThreadLimit({
  client,
  generation,
  threadStates,
  sessionsInUse,
  activeTurns,
  maxTrackedThreads,
  timeoutMs,
}) {
  while (threadStates.size > maxTrackedThreads) {
    let candidateKey = null;
    let candidateSessionId = null;
    for (const key of threadStates.keys()) {
      const separator = key.indexOf('\u0000');
      const keyGeneration = Number(key.slice(0, separator));
      const threadId = key.slice(separator + 1);
      if (separator < 0 || keyGeneration !== generation) continue;
      if (sessionsInUse.has(threadId) || activeTurns.has(threadId)) continue;
      candidateKey = key;
      candidateSessionId = threadId;
      break;
    }
    if (!candidateKey) return;
    threadStates.delete(candidateKey);
    try {
      await client.unsubscribeThread(candidateSessionId, { timeoutMs });
    } catch {}
  }
}

function effectiveCwd(entrada, envSource) {
  const dirs = Array.isArray(entrada.diretorios) ? entrada.diretorios : [];
  const raw = entrada.cwd || dirs.find(Boolean) || envSource.HOME || os.homedir() || process.cwd();
  return path.resolve(String(raw));
}

function sandboxPolicyFor(entrada, cwd) {
  const workerLeaf = entrada && entrada.workerLeaf === true;
  const plannerLeaf = entrada && entrada.plannerLeaf === true;
  const reviewerLeaf = entrada && entrada.reviewerLeaf === true;
  const coordinatorHead = entrada && entrada.coordinatorHead === true;
  if ([workerLeaf, plannerLeaf, reviewerLeaf, coordinatorHead].filter(Boolean).length > 1) {
    throw new Error('perfil leaf ambiguo: worker, planner, reviewer e coordinator nao podem coexistir');
  }
  if (coordinatorHead) return { type: 'readOnly', networkAccess: false };
  if (plannerLeaf) {
    assertPlannerCwd(entrada, cwd);
    return { type: 'readOnly', networkAccess: false };
  }
  if (reviewerLeaf) {
    assertReviewerCwd(entrada, cwd);
    return { type: 'readOnly', networkAccess: false };
  }
  if (!workerLeaf) return { type: 'dangerFullAccess' };
  const declaradas = Array.isArray(entrada.workerWritableRoots)
    ? entrada.workerWritableRoots
    : entrada.diretorios;
  const writableRoots = normalizeDirectories(declaradas, cwd);
  if (!writableRoots.length) {
    throw new Error('worker leaf sem writableRoots: turno recusado por seguranca');
  }
  const dentro = writableRoots.some((root) => cwd === root || cwd.startsWith(`${root}${path.sep}`));
  if (!dentro) {
    throw new Error('cwd do worker leaf fora de writableRoots: turno recusado por seguranca');
  }
  return {
    type: 'workspaceWrite',
    writableRoots,
    networkAccess: false,
  };
}

// Folhas usam um perfil de permissao nomeado do protocolo v2. Diferente do
// sandbox legado workspaceWrite/readOnly, este perfil pode negar LEITURA fora
// das raizes do job e, portanto, realmente esconde auth/runtime.env do shell.
// A cabeca continua byte a byte no sandbox historico.
function threadConfigFor(entrada, baseConfig, leafEnvelope = null) {
  if (!(entrada && (entrada.workerLeaf === true || entrada.plannerLeaf === true
      || entrada.reviewerLeaf === true || entrada.coordinatorHead === true))) return baseConfig || undefined;
  const workerLeaf = entrada.workerLeaf === true;
  const reviewerLeaf = entrada.reviewerLeaf === true;
  const workerCapabilities = workerLeaf ? normalizeWorkerCapabilities(entrada.workerCapabilities) : [];
  const webSearch = workerCapabilities.includes('web_search');
  const imageGeneration = workerCapabilities.includes('image_generation');
  // A configuracao de uma folha nasce de uma allowlist, nunca de `baseConfig`.
  // O app-server ja carregou config.toml da cabeca no processo compartilhado;
  // espalhar a configuracao-base aqui reabria exatamente MCPs/apps/hooks que o
  // sandbox de filesystem/rede nao governa. Este overlay e exclusivo da thread
  // e reaplicado tambem no cold resume.
  return {
    web_search: webSearch ? 'live' : 'disabled',
    project_doc_max_bytes: 0,
    mcp_servers: {},
    apps: { _default: { enabled: false } },
    // Nenhum segredo deliberadamente injetado no processo compartilhado vira
    // ambiente do shell da folha. PATH/HOME basicos continuam disponiveis.
    shell_environment_policy: {
      inherit: 'core',
      ignore_default_excludes: false,
      filters: {
        'LEON_ENV_FILE': 'exclude',
        'META_MCP_TOKEN': 'exclude',
        '*TOKEN*': 'exclude',
        '*SECRET*': 'exclude',
        '*PASSWORD*': 'exclude',
        '*PASSPHRASE*': 'exclude',
        '*KEY*': 'exclude',
        '*CREDENTIAL*': 'exclude',
        '*AUTH*': 'exclude',
        '*COOKIE*': 'exclude',
      },
    },
    features: {
      apps: false,
      browser_use: false,
      browser_use_external: false,
      browser_use_full_cdp_access: false,
      computer_use: false,
      hooks: false,
      image_generation: imageGeneration,
      multi_agent: false,
      multi_agent_v2: false,
      plugins: false,
      remote_plugin: false,
      // O revisor precisa abrir os snapshots. A sandbox readOnly e sem rede
      // continua sendo a autoridade de efeito; o executor fica disponível só
      // para leitura/inspeção local e não ganha nenhum diretório gravável.
      shell_tool: workerLeaf || reviewerLeaf,
      skill_mcp_dependency_install: false,
      unified_exec: workerLeaf || reviewerLeaf,
    },
    // Os perfis não entram aqui: o app-server já os recebeu no boot. A thread
    // escolhe apenas o id e seus runtimeWorkspaceRoots em thread/start.
  };
}

function leafPermissionEnvelopeFor(entrada, cwd, security = {}) {
  const workerLeaf = entrada && entrada.workerLeaf === true;
  const plannerLeaf = entrada && entrada.plannerLeaf === true;
  const reviewerLeaf = entrada && entrada.reviewerLeaf === true;
  const coordinatorHead = entrada && entrada.coordinatorHead === true;
  if (![workerLeaf, plannerLeaf, reviewerLeaf, coordinatorHead].some(Boolean)) return null;

  // Reuse all ambiguity/cwd/root validation from the legacy policy helper, but
  // do not send that policy to the protocol: permissions and sandboxPolicy are
  // mutually exclusive in Codex app-server v2.
  const validated = sandboxPolicyFor(entrada, cwd);
  const writableRoots = workerLeaf ? validated.writableRoots.slice() : [];
  const declaredReadRoots = workerLeaf
    ? entrada.workerReadRoots
    : (reviewerLeaf ? entrada.reviewerReadRoots : (plannerLeaf ? [cwd] : []));
  const readRoots = normalizeDirectories(declaredReadRoots, cwd);
  if ((plannerLeaf || reviewerLeaf) && !readRoots.includes(cwd)) readRoots.unshift(cwd);

  // O perfil estático do worker concede escrita a TODO runtimeWorkspaceRoot.
  // Portanto entradas somente-leitura nunca atravessam esta fronteira: a cabeça
  // fornece cópias privadas dentro dos writableRoots. Planner/reviewer têm seus
  // próprios perfis read-only e podem receber snapshots diretamente.
  if (workerLeaf && readRoots.length) {
    throw new Error('worker leaf recebeu readRoots externos: use copia privada no job');
  }

  for (const root of readRoots) {
    if (writableRoots.includes(root)) {
      throw new Error('worker leaf declarou a mesma raiz para leitura e escrita: turno recusado por seguranca');
    }
  }

  const profileId = workerLeaf
    ? LEAF_PROFILE_IDS.worker
    : (reviewerLeaf ? LEAF_PROFILE_IDS.reviewer
      : (plannerLeaf ? LEAF_PROFILE_IDS.planner : LEAF_PROFILE_IDS.coordinator));
  const protectedPaths = protectedLeafPaths(security);
  for (const root of [...writableRoots, ...readRoots]) {
    const volumeRoot = path.parse(root).root;
    const engulfsProtected = protectedPaths.some((protectedPath) => (
      protectedPath === root || protectedPath.startsWith(`${root}${path.sep}`)
    ));
    if (root === volumeRoot || engulfsProtected) {
      throw new Error('raiz da folha ampla demais ou contem cofre do motor: turno recusado por seguranca');
    }
  }
  const runtimeWorkspaceRoots = workerLeaf
    ? writableRoots.slice()
    : [...new Set(readRoots)];
  const canonicalProfile = LEAF_PERMISSION_PROFILE_DEFINITIONS[profileId];
  if (!canonicalProfile) throw new Error('perfil de permissao da folha ausente');
  return {
    profileId,
    runtimeWorkspaceRoots,
    writableRoots,
    readRoots,
    protectedPaths,
    configPermissions: {
      [profileId]: canonicalProfile,
    },
  };
}

function protectedLeafPaths(security = {}) {
  const raw = [
    security.sourceCodexHome,
    security.leafCodexHome,
    security.envFile,
    ...(Array.isArray(security.protectedReadPaths) ? security.protectedReadPaths : []),
  ];
  const unique = new Set();
  for (const value of raw) {
    if (typeof value !== 'string' || !value.trim() || !path.isAbsolute(value)) continue;
    unique.add(path.resolve(value));
  }
  return [...unique];
}

function resolveSourceCodexHome(options, envSource) {
  const raw = envSource.LEON_CODEX_HOME || envSource.CODEX_HOME
    || path.join(envSource.HOME || os.homedir(), '.codex');
  return path.resolve(String(raw));
}

function resolveLeafCodexHome(options, envSource, sourceCodexHome) {
  const explicit = options.leafCodexHome || envSource.LEON_CODEX_LEAF_HOME;
  let resolved;
  if (explicit) {
    if (!path.isAbsolute(String(explicit))) {
      throw new Error('LEON_CODEX_LEAF_HOME precisa ser caminho absoluto');
    }
    resolved = path.resolve(String(explicit));
  } else {
    // O CODEX_HOME restrito precisa ser gravável pelo app-server host, embora
    // seja negado às tools. Se ele morar dentro do CODEX_HOME principal, o
    // deny do pai torna o mountpoint read-only e o bwrap falha antes do shell.
    const source = path.resolve(String(sourceCodexHome));
    resolved = path.join(path.dirname(source), `${path.basename(source)}-leon-leaf-runtime`);
  }
  assertDisjointCodexHomes(sourceCodexHome, resolved);
  return resolved;
}

function canonicalPathWithMissingTail(value) {
  let cursor = path.resolve(String(value));
  const missing = [];
  for (;;) {
    try {
      const real = fs.realpathSync.native ? fs.realpathSync.native(cursor) : fs.realpathSync(cursor);
      return path.join(real, ...missing.reverse());
    } catch (error) {
      if (!error || error.code !== 'ENOENT') throw error;
      const parent = path.dirname(cursor);
      if (parent === cursor) return path.resolve(String(value));
      missing.push(path.basename(cursor));
      cursor = parent;
    }
  }
}

function assertDisjointCodexHomes(sourceHome, leafHome) {
  const source = canonicalPathWithMissingTail(sourceHome);
  const leaf = canonicalPathWithMissingTail(leafHome);
  const contains = (parent, child) => child === parent || child.startsWith(`${parent}${path.sep}`);
  if (contains(source, leaf) || contains(leaf, source)) {
    throw new Error('CODEX_HOME principal e LEON_CODEX_LEAF_HOME precisam ser diretorios irmaos, sem relacao ancestral');
  }
}

function ensureLeafCodexHome(leafHome, sourceHome) {
  fs.mkdirSync(leafHome, { recursive: true, mode: 0o700 });
  try { fs.chmodSync(leafHome, 0o700); } catch {}
  const sourceAuth = path.join(sourceHome, 'auth.json');
  const leafAuth = path.join(leafHome, 'auth.json');
  let sourceExists = false;
  try { sourceExists = fs.statSync(sourceAuth).isFile(); } catch {}
  if (!sourceExists) return;
  try {
    const existing = fs.lstatSync(leafAuth);
    if (!existing.isSymbolicLink() || path.resolve(leafHome, fs.readlinkSync(leafAuth)) !== sourceAuth) {
      throw new Error(`credencial inesperada ja existe em ${leafAuth}`);
    }
    return;
  } catch (error) {
    if (error && error.code !== 'ENOENT') throw error;
  }
  fs.symlinkSync(sourceAuth, leafAuth, 'file');
}

function omitEnv(source, names) {
  const result = { ...(source || {}) };
  for (const name of names) delete result[name];
  return result;
}

function normalizeWorkerCapabilities(value) {
  if (value == null) return [];
  if (!Array.isArray(value)) throw new Error('worker capabilities invalidas: turno recusado por seguranca');
  const normalized = [...new Set(value.map((item) => String(item || '').trim()).filter(Boolean))];
  const unknown = normalized.find((item) => !WORKER_CAPABILITIES.includes(item));
  if (unknown) throw new Error(`worker capability nao autorizada: ${unknown}`);
  return normalized;
}

function assertReviewerCwd(entrada, cwd) {
  const declarado = entrada && typeof entrada.reviewerCwd === 'string'
    ? entrada.reviewerCwd.trim() : '';
  if (!declarado) throw new Error('reviewer leaf sem cwd imutavel: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do reviewer leaf diverge do snapshot imutavel: turno recusado por seguranca');
  }
}

function assertPlannerCwd(entrada, cwd) {
  const declarado = stringOrNull(entrada && entrada.plannerCwd);
  if (!declarado) throw new Error('planner leaf sem cwd isolado: turno recusado por seguranca');
  if (path.resolve(declarado) !== path.resolve(cwd)) {
    throw new Error('cwd do planner leaf diverge do cwd isolado: turno recusado por seguranca');
  }
}

function normalizeDirectories(value, cwd) {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || !item.trim()) continue;
    unique.add(path.resolve(cwd, item));
  }
  return [...unique];
}

function resolveCodexBin(envSource) {
  if (envSource.CODEX_BIN) { try { fs.accessSync(envSource.CODEX_BIN, fs.constants.X_OK); return envSource.CODEX_BIN; } catch {} }
  const home = envSource.HOME || os.homedir();
  const dataDir = envSource.LEON_DATA_DIR || path.join(home, ".leon");
  const version = envSource.LEON_CODEX_CLI_VERSION || "0.147.0";
  const expected = path.join(dataDir, "codex-cli", "releases", version, "bin", "codex");
  for (const candidate of [
    expected,
    path.join(home, ".npm-global/bin/codex"),
    "/usr/local/bin/codex",
    "/usr/bin/codex",
  ]) {
    try { if (candidate) { fs.accessSync(candidate, fs.constants.X_OK); return candidate; } } catch {}
  }
  return "codex";
}

function binaryAvailable(command, pathValue) {
  if (command.includes(path.sep)) {
    try { fs.accessSync(command, fs.constants.X_OK); return true; } catch { return false; }
  }
  return String(pathValue || '').split(path.delimiter).some((dir) => {
    if (!dir) return false;
    try { fs.accessSync(path.join(dir, command), fs.constants.X_OK); return true; } catch { return false; }
  });
}

function timeoutFor(entrada) {
  return intOption(entrada.timeoutMs, DEFAULT_TIMEOUT_MS);
}

function requestTimeoutFor(entrada, options) {
  const configured = intOption(options.requestTimeoutMs, 15_000);
  return Math.min(timeoutFor(entrada), configured);
}

function formatTurnError(result) {
  if (result.status === 'completed') return null;
  const detail = result.error?.message || result.error?.additionalDetails || '';
  return `Codex encerrou o turno com status ${result.status || 'desconhecido'}${detail ? `: ${detail}` : ''}`;
}

function formatAdapterError(error) {
  if (error instanceof TurnTimeoutError) {
    return `timeout de ${Math.max(1, Math.ceil(error.timeoutMs / 1_000))}s no Codex`;
  }
  const base = error?.message || 'não consegui rodar o Codex';
  const stderr = Array.isArray(error?.stderr) ? error.stderr.slice(-5).join('\n') : '';
  return stderr && !base.includes(stderr) ? `${base}\n${stderr}` : base;
}

function output(value = {}) {
  return {
    texto: typeof value.texto === 'string' ? value.texto : '',
    custoUSD: Number.isFinite(value.custoUSD) ? value.custoUSD : null,
    sessaoId: value.sessaoId || null,
    erro: value.erro || null,
    cota: Boolean(value.cota),
    ctxTokens: Number.isFinite(value.ctxTokens) ? value.ctxTokens : null,
    // USO DO TURNO (2.4.31), campo NEUTRO de motor: os subcampos que o bridge precisa pra
    // decidir teto de thread e pra mostrar o credito no /cota. Motor que nao reporta manda
    // null e o bridge segue na estimativa de sempre.
    uso: value.uso && typeof value.uso === 'object' ? value.uso : null,
  };
}
// Traduz o tokenUsage do app-server (thread/tokenUsage/updated) no formato neutro:
//   { entrada, cache, saida, raciocinio, total }
// O evento traz `last` (o turno) e `total` (a thread inteira). O TETO DE THREAD olha a
// ENTRADA do ultimo turno, que e o tamanho real da janela que o motor esta reenviando. Versao
// do app-server que nao traga os subcampos cai no total, como o brief manda.
function normalizeTokenUsage(tokenUsage) {
  if (!tokenUsage || typeof tokenUsage !== 'object') return null;
  const fonte = tokenUsage.last && typeof tokenUsage.last === 'object' ? tokenUsage.last : tokenUsage;
  const num = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const entrada = num(fonte.inputTokens ?? fonte.input_tokens);
  const cache = num(fonte.cachedInputTokens ?? fonte.cached_input_tokens);
  const saida = num(fonte.outputTokens ?? fonte.output_tokens);
  const raciocinio = num(fonte.reasoningOutputTokens ?? fonte.reasoning_output_tokens);
  const total = num(fonte.totalTokens ?? fonte.total_tokens)
    ?? num(tokenUsage.total && (tokenUsage.total.totalTokens ?? tokenUsage.total.total_tokens));
  if (entrada == null && cache == null && saida == null && total == null) return null;
  return { entrada, cache, saida, raciocinio, total };
}

function isLimitMessage(value) {
  const text = String(value || '');
  return text.length < 500 && /(hit your limit|usage limit|limit reached|rate.?limit|credit balance|balance is too low|too many requests|usageLimitExceeded)/i.test(text);
}

function threadAlreadyAbsent(error, threadId) {
  return Boolean(error
    && error.method === 'thread/delete'
    && error.dispatched === true
    && error.code === -32600
    && error.data === undefined
    && error.rpcMessage === `no rollout found for thread id ${String(threadId)}`);
}

// INSTRUMENTO [thread-start] (18/09). Toda thread do Codex nasce com um envelope
// (dossiê, MCPs, sandbox, perfil de permissão) que hoje some: quando o dono diz que "o
// agente ficou sem ferramenta" ou "esqueceu quem é", não há linha nenhuma dizendo o que
// aquela thread recebeu de fato. UMA linha por thread fecha isso, e só por thread (não
// por turno), então o custo é desprezível.
//
// HONESTIDADE DO CAMPO `tools` (medido, não suposto): `thread/start` do app-server
// 0.147.0 responde `{thread:{id,turns}, model}` — NÃO devolve lista de tools, e não há
// `session_configured` nem `tools/list` no protocolo do adapter (appserver/adapter.cjs:
// normalizeThreadResult). Descobrir a lista real custaria um RPC `mcpServerStatus/list`
// por thread, que é o oposto de barato. Então o campo sai `tools=?` e o que se loga é o
// que a thread DECLAROU. Mentir "tools=12" a partir de uma contagem inventada seria pior
// que não logar.
//
// MCP: a cabeça herda os MCPs do config.toml do CODEX_HOME, que este processo nunca lê —
// por isso ela sai `mcp=herdado` (declaração honesta: "não foi esta thread que escolheu").
// A folha recebe overlay explícito `mcp_servers={}` em threadConfigFor, e aí a contagem é
// verdadeira e vale 0.
function linhaThreadStart(dados = {}) {
  const sala = stringOrNull(dados.sala) || '?';
  const bytes = Number.isFinite(Number(dados.developerInstructionsBytes))
    ? Number(dados.developerInstructionsBytes) : 0;
  const mcp = dados.mcpHerdado === true
    ? 'herdado'
    : `${(dados.mcpNomes || []).length}${(dados.mcpNomes || []).length ? `:${(dados.mcpNomes || []).join(',')}` : ''}`;
  // A MESMA ARMADILHA Number(null)===0 que já custou 118 linhas de métrica falsa (lote 2,
  // 15/09): sem checar o TIPO primeiro, "não sei quantas tools" viraria "tools=0 medido".
  // Aqui isso seria pior que na métrica, porque zero tool é um defeito real e plausível.
  const tools = (typeof dados.tools === 'number' && Number.isFinite(dados.tools))
    ? String(dados.tools) : '?';
  const sandbox = stringOrNull(dados.sandbox) || '?';
  const retomada = dados.retomada === true ? 'sim' : 'nao';
  return `[thread-start] sala=${sala} motor=codex developerInstructions=${bytes} mcp=${mcp} tools=${tools} sandbox=${sandbox} retomada=${retomada}`;
}

// O que a thread DECLAROU, lido dos params que vão no protocolo — nunca de uma suposição
// sobre o que o app-server fez com eles. `sandbox` junta os dois caminhos mutuamente
// exclusivos do v2: `sandboxPolicy.type` (cabeça) ou o id do perfil nomeado (folha).
function dadosThreadStart(threadParams = {}, origem = {}, retomada = false) {
  const chat = origem && origem.LEON_ORIGEM_CHAT != null ? String(origem.LEON_ORIGEM_CHAT) : '';
  const thread = origem && origem.LEON_ORIGEM_THREAD != null ? String(origem.LEON_ORIGEM_THREAD) : '';
  const sala = chat ? (thread ? `${chat}:${thread}` : chat) : null;
  const config = threadParams.config && typeof threadParams.config === 'object' ? threadParams.config : null;
  // `mcp_servers` presente = overlay de folha (allowlist fechada). Ausente = a thread não
  // declarou nada e herda o catálogo do processo, que mora no config.toml.
  const declarou = config && config.mcp_servers && typeof config.mcp_servers === 'object';
  return {
    sala,
    developerInstructionsBytes: Buffer.byteLength(String(threadParams.developerInstructions || ''), 'utf8'),
    mcpHerdado: !declarou,
    mcpNomes: declarou ? Object.keys(config.mcp_servers).sort() : [],
    tools: null,
    sandbox: threadParams.permissions
      ? `perfil:${threadParams.permissions}`
      : (threadParams.sandboxPolicy && threadParams.sandboxPolicy.type) || null,
    retomada: retomada === true,
  };
}

function logaThreadStart(threadParams, origem, retomada) {
  // Default LIGADA: uma linha por thread não é verbosidade, é a diferença entre
  // diagnosticar e adivinhar. LEON_LOG_THREAD_START=0 cala.
  if (String(process.env.LEON_LOG_THREAD_START || '1').trim() === '0') return null;
  try {
    const linha = linhaThreadStart(dadosThreadStart(threadParams, origem, retomada));
    console.log(linha);
    return linha;
  } catch (e) {
    // Observar nunca derruba o turno.
    try { console.error('[thread-start] nao consegui logar (o turno segue):', e && e.message); } catch {}
    return null;
  }
}

function compactObject(value) {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined && item !== null));
}

function stringOrNull(value) {
  return value == null || value === '' ? null : String(value);
}

function intOption(value, fallback) {
  const number = Number(value == null ? fallback : value);
  if (!Number.isSafeInteger(number) || number <= 0) return fallback;
  return number;
}

function numberFromEnv(name, fallback) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function withLock(locks, key, operation) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  locks.set(key, current);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (locks.get(key) === current) locks.delete(key);
  }
}

const defaultMotor = createMotor();

module.exports = {
  ...defaultMotor,
  createMotor,
  _buildUserInput: buildUserInput,
  _sandboxPolicyFor: sandboxPolicyFor,
  _threadConfigFor: threadConfigFor,
  _leafPermissionEnvelopeFor: leafPermissionEnvelopeFor,
  _resolveLeafCodexHome: resolveLeafCodexHome,
  _leafAppServerArgs: (base = ['app-server']) => [
    ...Array.from(base, String), ...LEAF_APP_SERVER_CONFIG_ARGS,
  ],
  _leafPermissionProfileDefinitions: LEAF_PERMISSION_PROFILE_DEFINITIONS,
  _leafPermissionProfilesToml: LEAF_PERMISSION_PROFILES_TOML,
  _normalizeWorkerCapabilities: normalizeWorkerCapabilities,
  _normalizeDirectories: normalizeDirectories,
  _output: output,
  _linhaThreadStart: linhaThreadStart,
  _dadosThreadStart: dadosThreadStart,
  _normalizeRateLimits: normalizeRateLimits,
  _normalizeTokenUsage: normalizeTokenUsage,
};
