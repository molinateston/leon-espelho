'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createHash } = require('node:crypto');

const {
  CodexAppServerAdapter,
  TurnTimeoutError,
} = require('../appserver/adapter.cjs');

const SEP_FALA = '===== FALA DO DONO =====';
const DEFAULT_TIMEOUT_MS = numberFromEnv('CODEX_TIMEOUT_SEG', 240) * 1_000;
// Secret-looking variables are opt-in. The Google MCP bridge can pass
// ['GOG_KEYRING_PASSWORD', 'GOG_ACCOUNT'] when it deliberately needs them.
const DEFAULT_ALLOWED_SECRET_ENV = Object.freeze([]);

const capacidades = Object.freeze({
  promptSistemaSeparado: true,
  retomaSessao: true,
  tetoCustoNativo: false,
  reportaCusto: false,
  saidaEstruturada: true,
  controlePermissao: true,
  modeloSelecionavel: true,
  effort: true,
  diretoriosExtras: true,
  compactacaoNativa: false,
});

function createMotor(options = {}) {
  const envSource = options.envSource || process.env;
  const command = options.command || resolveCodexBin(envSource);
  const adapterOptions = options.adapterOptions || {};
  const fixedAdapter = options.adapter || null;
  let adapter = fixedAdapter;
  let adapterGeneration = null;
  const threadStates = new Map();
  const sessionLocks = new Map();
  const sessionsInUse = new Set();
  const activeTurns = new Map();
  const maxTrackedThreads = intOption(options.maxTrackedThreads, 64);

  function getAdapter() {
    if (!adapter) {
      adapter = new CodexAppServerAdapter({
        command,
        args: ['app-server'],
        cwd: options.processCwd || process.cwd(),
        envSource,
        env: {
          RUST_LOG: envSource.CODEX_RUST_LOG || 'warn',
          CODEX_HOME: envSource.LEON_CODEX_HOME || envSource.CODEX_HOME,
        },
        allowedSecretEnv: Array.isArray(options.allowedSecretEnv)
          ? options.allowedSecretEnv
          : DEFAULT_ALLOWED_SECRET_ENV,
        clientInfo: {
          name: 'leon_codex',
          title: 'LEON Codex',
          version: String(options.version || '1.0.0'),
        },
        requestTimeoutMs: intOption(options.requestTimeoutMs, 15_000),
        turnTimeoutMs: intOption(options.turnTimeoutMs, DEFAULT_TIMEOUT_MS),
        maxBufferedNotifications: intOption(options.maxBufferedNotifications, 256),
        maxBufferedNotificationBytes: intOption(options.maxBufferedNotificationBytes, 1_048_576),
        maxActiveTurns: intOption(options.maxActiveTurns, 16),
        autoRestart: options.autoRestart !== false,
        ...adapterOptions,
        // excludeTurns on thread/resume is capability-gated in Codex 0.147.0.
        capabilities: {
          ...(adapterOptions.capabilities || {}),
          experimentalApi: true,
        },
      });
    }
    return adapter;
  }

  function syncGeneration(client) {
    const generation = client.status().generation;
    if (adapterGeneration !== generation) {
      threadStates.clear();
      adapterGeneration = generation;
    }
    return generation;
  }

  async function responder(entrada = {}) {
    const requestedSessionId = stringOrNull(entrada.sessaoId);
    const lockKey = requestedSessionId ? `session:${requestedSessionId}` : Symbol('new-thread');
    return withLock(sessionLocks, lockKey, async () => {
      let sessionId = requestedSessionId;
      let client = null;
      let generation = null;
      if (sessionId) sessionsInUse.add(sessionId);
      try {
        client = getAdapter();
        await client.start();
        generation = syncGeneration(client);
        const cwd = effectiveCwd(entrada, envSource);
        const directories = normalizeDirectories(entrada.diretorios, cwd);
        const dossie = String(entrada.dossie || '');
        const model = stringOrNull(entrada.modelo);
        const threadParams = compactObject({
          cwd,
          developerInstructions: dossie || null,
          model,
          approvalPolicy: options.approvalPolicy || 'never',
          config: options.threadConfig || { default_permissions: options.permissionProfile || 'leon' },
          ephemeral: sessionId ? undefined : false,
        });

        if (sessionId) {
          const loadedKey = `${generation}\u0000${sessionId}`;
          if (!threadStates.has(loadedKey)) {
            const resumed = await client.resumeThread(sessionId, {
              ...threadParams,
              // The bridge needs only the durable id. Returning all turns can
              // make one JSONL response exceed the adapter's safety cap on a
              // long or image-heavy conversation.
              excludeTurns: true,
            }, {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            if (sessionId !== resumed.threadId) {
              sessionsInUse.delete(sessionId);
              sessionsInUse.add(resumed.threadId);
            }
            sessionId = resumed.threadId;
            const resumedKey = `${generation}\u0000${sessionId}`;
            // Also inject on a cold resume. Codex 0.147.0 accepts the plain
            // resume override but can omit it from the first resumed model
            // request; the persisted developer item closes that gap.
            const resumedDossierHash = dossierHash(dossie);
            await client.injectItems(sessionId, [developerDossierItem(dossie, resumedDossierHash)], {
              timeoutMs: requestTimeoutFor(entrada, options),
            });
            rememberThread(threadStates, resumedKey, resumedDossierHash);
          } else {
            touchThread(threadStates, loadedKey);
          }
        } else {
          const started = await client.startThread(threadParams, {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          sessionId = started.threadId;
          sessionsInUse.add(sessionId);
          const startedKey = `${generation}\u0000${sessionId}`;
          rememberThread(threadStates, startedKey, dossierHash(dossie));
        }

        // Codex 0.147.0 ignores thread/resume overrides for an already-loaded
        // thread. Append a developer item only when LEON's dynamic dossier
        // changes, so the next model request sees the new revision without
        // copying a large system prompt into every user message.
        const dossierKey = `${generation}\u0000${sessionId}`;
        const nextDossierHash = dossierHash(dossie);
        const previousDossierHash = threadStates.get(dossierKey);
        if (previousDossierHash !== undefined && previousDossierHash !== nextDossierHash) {
          await client.injectItems(sessionId, [developerDossierItem(dossie, nextDossierHash)], {
            timeoutMs: requestTimeoutFor(entrada, options),
          });
          rememberThread(threadStates, dossierKey, nextDossierHash);
        }

        const timeoutMs = timeoutFor(entrada);
        const input = buildUserInput(entrada);
        const turnParams = compactObject({
          threadId: sessionId,
          input,
          cwd,
          model,
          effort: stringOrNull(entrada.effort),
        });
        const handle = await client.startTurn(turnParams, {
          timeoutMs,
          requestTimeoutMs: Math.min(timeoutMs, requestTimeoutFor(entrada, options)),
          onDelta: typeof entrada.onDelta === 'function' ? entrada.onDelta : null,
          onNotification: typeof entrada.onEvento === 'function' ? entrada.onEvento : null,
        });
        activeTurns.set(sessionId, handle);
        let result;
        try {
          result = await handle.completion;
        } finally {
          if (activeTurns.get(sessionId) === handle) activeTurns.delete(sessionId);
        }

        const text = String(result.finalText || '').trim();
        const turnError = formatTurnError(result);
        if (!text) {
          return output({
            erro: turnError || `Codex encerrou o turno com status ${result.status || 'desconhecido'} sem resposta`,
            cota: isLimitMessage(turnError),
            sessaoId: sessionId,
          });
        }
        return output({
          texto: text,
          erro: turnError,
          cota: isLimitMessage(text) || isLimitMessage(turnError),
          custoUSD: null,
          sessaoId: sessionId,
          ctxTokens: null,
        });
      } catch (error) {
        const message = formatAdapterError(error);
        return output({
          erro: message,
          cota: isLimitMessage(message),
          sessaoId: sessionId,
        });
      } finally {
        if (sessionId) sessionsInUse.delete(sessionId);
        if (client && generation != null) {
          await enforceThreadLimit({
            client,
            generation,
            threadStates,
            sessionsInUse,
            activeTurns,
            maxTrackedThreads,
            timeoutMs: intOption(options.requestTimeoutMs, 15_000),
          });
        }
      }
    });
  }

  async function encerrar(handle) {
    if (handle && typeof handle.interrupt === 'function') {
      try { await handle.interrupt(); } catch {}
      return;
    }
    if (typeof handle === 'string') {
      const active = activeTurns.get(handle);
      if (active) {
        try { await active.interrupt(); } catch {}
      }
      return;
    }
    if (adapter) {
      try { await adapter.close(); } catch {}
      if (!fixedAdapter) adapter = null;
      threadStates.clear();
      sessionsInUse.clear();
      adapterGeneration = null;
    }
  }

  async function resetar(sessionId) {
    const target = stringOrNull(sessionId);
    if (!target) return { ok: true, sessaoId: null };
    return withLock(sessionLocks, `session:${target}`, async () => {
      let deleteStarted = false;
      try {
        const client = getAdapter();
        await client.start();
        const generation = syncGeneration(client);
        if (activeTurns.has(target) || sessionsInUse.has(target)) {
          throw new Error(`thread ${target} ainda possui turno ativo`);
        }
        deleteStarted = true;
        await client.deleteThread(target, {
          timeoutMs: intOption(options.requestTimeoutMs, 15_000),
        });
        for (const key of [...threadStates.keys()]) {
          if (key === `${generation}\u0000${target}` || key.endsWith(`\u0000${target}`)) threadStates.delete(key);
        }
        sessionsInUse.delete(target);
        activeTurns.delete(target);
        return { ok: true, sessaoId: target };
      } catch (error) {
        if (threadAlreadyAbsent(error, target)) {
          for (const key of [...threadStates.keys()]) {
            if (key.endsWith(`\u0000${target}`)) threadStates.delete(key);
          }
          sessionsInUse.delete(target);
          activeTurns.delete(target);
          return { ok: true, sessaoId: target };
        }
        if (!deleteStarted && error && error.dispatched === undefined) {
          try {
            error.method = 'thread/delete';
            error.dispatched = false;
          } catch {}
        }
        throw error;
      }
    });
  }

  return {
    nome: 'codex',
    bin: command,
    capacidades,
    disponivel() { return binaryAvailable(command, envSource.PATH); },
    responder,
    resetar,
    encerrar,
    _adapter() { return adapter; },
  };
}

function buildUserInput(entrada) {
  const parts = [];
  if (entrada.contexto) parts.push(String(entrada.contexto));
  parts.push(`${SEP_FALA}\n${String(entrada.fala || '')}`);
  return [{ type: 'text', text: parts.join('\n\n') }];
}

function dossierHash(dossie) {
  return createHash('sha256').update(String(dossie || ''), 'utf8').digest('hex');
}

function developerDossierItem(dossie, revision) {
  const text = String(dossie || '');
  return {
    type: 'message',
    role: 'developer',
    content: [{
      type: 'input_text',
      text: [
        `<leon_dossier revision="${revision}">`,
        'Esta revisão substitui integralmente todos os dossiês LEON anteriores.',
        text,
        '</leon_dossier>',
      ].join('\n'),
    }],
  };
}

function rememberThread(threadStates, key, dossierRevision) {
  threadStates.delete(key);
  threadStates.set(key, dossierRevision);
}

function touchThread(threadStates, key) {
  if (!threadStates.has(key)) return;
  const value = threadStates.get(key);
  rememberThread(threadStates, key, value);
}

async function enforceThreadLimit({
  client,
  generation,
  threadStates,
  sessionsInUse,
  activeTurns,
  maxTrackedThreads,
  timeoutMs,
}) {
  while (threadStates.size > maxTrackedThreads) {
    let candidateKey = null;
    let candidateSessionId = null;
    for (const key of threadStates.keys()) {
      const separator = key.indexOf('\u0000');
      const keyGeneration = Number(key.slice(0, separator));
      const threadId = key.slice(separator + 1);
      if (separator < 0 || keyGeneration !== generation) continue;
      if (sessionsInUse.has(threadId) || activeTurns.has(threadId)) continue;
      candidateKey = key;
      candidateSessionId = threadId;
      break;
    }
    if (!candidateKey) return;
    threadStates.delete(candidateKey);
    try {
      await client.unsubscribeThread(candidateSessionId, { timeoutMs });
    } catch {}
  }
}

function effectiveCwd(entrada, envSource) {
  const dirs = Array.isArray(entrada.diretorios) ? entrada.diretorios : [];
  const raw = entrada.cwd || dirs.find(Boolean) || envSource.HOME || os.homedir() || process.cwd();
  return path.resolve(String(raw));
}

function normalizeDirectories(value, cwd) {
  if (!Array.isArray(value)) return [];
  const unique = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || !item.trim()) continue;
    unique.add(path.resolve(cwd, item));
  }
  return [...unique];
}

function resolveCodexBin(envSource) {
  const home = envSource.HOME || os.homedir();
  const dataDir = envSource.LEON_DATA_DIR || path.join(home, '.leon');
  const version = envSource.LEON_CODEX_CLI_VERSION || '0.147.0';
  const expected = path.join(dataDir, 'codex-cli', 'releases', version, 'bin', 'codex');
  const candidate = envSource.CODEX_BIN || expected;
  return path.resolve(candidate) === path.resolve(expected) ? candidate : expected;
}

function binaryAvailable(command, pathValue) {
  if (command.includes(path.sep)) {
    try { return fs.existsSync(command); } catch { return false; }
  }
  return String(pathValue || '').split(path.delimiter).some((dir) => {
    if (!dir) return false;
    try { return fs.existsSync(path.join(dir, command)); } catch { return false; }
  });
}

function timeoutFor(entrada) {
  return intOption(entrada.timeoutMs, DEFAULT_TIMEOUT_MS);
}

function requestTimeoutFor(entrada, options) {
  const configured = intOption(options.requestTimeoutMs, 15_000);
  return Math.min(timeoutFor(entrada), configured);
}

function formatTurnError(result) {
  if (result.status === 'completed') return null;
  const detail = result.error?.message || result.error?.additionalDetails || '';
  return `Codex encerrou o turno com status ${result.status || 'desconhecido'}${detail ? `: ${detail}` : ''}`;
}

function formatAdapterError(error) {
  if (error instanceof TurnTimeoutError) {
    return `timeout de ${Math.max(1, Math.ceil(error.timeoutMs / 1_000))}s no Codex`;
  }
  const base = error?.message || 'não consegui rodar o Codex';
  const stderr = Array.isArray(error?.stderr) ? error.stderr.slice(-5).join('\n') : '';
  return stderr && !base.includes(stderr) ? `${base}\n${stderr}` : base;
}

function output(value = {}) {
  return {
    texto: typeof value.texto === 'string' ? value.texto : '',
    custoUSD: Number.isFinite(value.custoUSD) ? value.custoUSD : null,
    sessaoId: value.sessaoId || null,
    erro: value.erro || null,
    cota: Boolean(value.cota),
    ctxTokens: Number.isFinite(value.ctxTokens) ? value.ctxTokens : null,
  };
}

function isLimitMessage(value) {
  const text = String(value || '');
  return text.length < 500 && /(hit your limit|usage limit|limit reached|rate.?limit|credit balance|balance is too low|too many requests|usageLimitExceeded)/i.test(text);
}

function threadAlreadyAbsent(error, threadId) {
  return Boolean(error
    && error.method === 'thread/delete'
    && error.dispatched === true
    && error.code === -32600
    && error.data === undefined
    && error.rpcMessage === `no rollout found for thread id ${String(threadId)}`);
}

function compactObject(value) {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined && item !== null));
}

function stringOrNull(value) {
  return value == null || value === '' ? null : String(value);
}

function intOption(value, fallback) {
  const number = Number(value == null ? fallback : value);
  if (!Number.isSafeInteger(number) || number <= 0) return fallback;
  return number;
}

function numberFromEnv(name, fallback) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

async function withLock(locks, key, operation) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => { release = resolve; });
  locks.set(key, current);
  await previous.catch(() => {});
  try {
    return await operation();
  } finally {
    release();
    if (locks.get(key) === current) locks.delete(key);
  }
}

const defaultMotor = createMotor();

module.exports = {
  ...defaultMotor,
  createMotor,
  _buildUserInput: buildUserInput,
  _normalizeDirectories: normalizeDirectories,
  _output: output,
};
