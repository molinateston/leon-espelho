'use strict';
// lib-motores/anexos.cjs — O MOTOR VÊ A IMAGEM (21/09/2026).
//
// DEFEITO (caso real do dono, sala Designer): o dono mandou uma FOTO com a legenda "cria uma
// imagem dessa, copiando na nossa id visual". O bridge baixou a foto pro disco, colou no texto
// o marcador [IMAGEM ANEXADA: /path — use a ferramenta Read ...] e mandou pro motor um prompt
// de ~50 KB de TEXTO PURO. Nenhum dos dois buildUserInput olhava pro arquivo: o caminho existia
// só como frase dentro da fala. O modelo não viu a foto e inventou outra arte (um touro dourado
// no lugar de uma ilustração de dois rostos), sem nunca dizer que estava cego.
//
// Este módulo é a fonte ÚNICA da lista de imagens do turno, pros dois motores. Cada motor entrega
// pelo canal que o CLI dele aceita — Codex pelo item {type:"localImage"} do turn/start, Claude
// pelo caminho absoluto no prompt com ordem de leitura — mas quem decide QUAIS caminhos valem é
// aqui, uma régua só. O marcador continua na fala: o gate de classe lê ele (18/09), e tirá-lo
// desarmaria aquele conserto.
//
// A régua é conservadora de propósito: caminho não-absoluto, arquivo que não existe, extensão
// que o motor não lê, ou anexo que não é imagem (doc/PDF, que já viajam pré-convertidos pra
// texto) ficam de fora em silêncio — o turno segue exatamente como antes, com o marcador. O
// dossiê nunca passa por aqui.

const fs = require('node:fs');
const path = require('node:path');

// O que os dois motores leem como imagem. Fora desta lista, o anexo continua só marcador: é o
// mesmo conjunto que a API aceita e que o Read do Claude Code abre nativo.
const EXTENSOES = Object.freeze(['.jpg', '.jpeg', '.png', '.gif', '.webp']);

// Kill-switch do dono. Nasce LIGADA porque isto é conserto de defeito, não capacidade nova: o
// comportamento cego é o bug. Com LEON_MOTOR_VE_IMAGEM=0 os dois motores voltam ao turno de
// texto puro com o marcador, que é o de antes deste commit.
function motorVeImagemLigado(envSource = process.env) {
  return String((envSource && envSource.LEON_MOTOR_VE_IMAGEM) || '1').trim() !== '0';
}

function ehImagem(caminho) {
  return EXTENSOES.includes(path.extname(String(caminho || '')).toLowerCase());
}

// Os caminhos de imagem deste turno, prontos pro motor. Devolve [] sempre que houver qualquer
// dúvida: um anexo que não chega é o defeito de hoje, mas um caminho inventado seria pior.
function anexosDeImagem(entrada, envSource = process.env) {
  if (!motorVeImagemLigado(envSource)) return [];
  const bruto = entrada && Array.isArray(entrada.imagens) ? entrada.imagens : [];
  const vistos = new Set();
  const saida = [];
  for (const item of bruto) {
    if (typeof item !== 'string' || !item.trim()) continue;
    const abs = path.resolve(item.trim());
    // Só caminho ABSOLUTO: o cwd do motor é o do turno, não o do bridge, então caminho relativo
    // resolveria em pasta errada e o motor leria um arquivo que não é o do dono — ou nenhum.
    if (abs !== item.trim() && !path.isAbsolute(item.trim())) continue;
    if (vistos.has(abs) || !ehImagem(abs)) continue;
    // O arquivo tem que EXISTIR agora, na hora de montar o turno. O sweepTmp varre a cada 30 min
    // e apaga por idade (6 h de retenção), então a foto deste turno está viva — mas conferir aqui
    // é o que impede o motor de receber um caminho morto e alucinar em cima dele.
    try { if (!fs.statSync(abs).isFile()) continue; } catch { continue; }
    vistos.add(abs);
    saida.push(abs);
  }
  return saida;
}

module.exports = { anexosDeImagem, motorVeImagemLigado, EXTENSOES };
