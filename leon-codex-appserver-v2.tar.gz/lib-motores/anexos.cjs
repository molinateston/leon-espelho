'use strict';
// lib-motores/anexos.cjs — O MOTOR VÊ A IMAGEM (21/09/2026).
//
// DEFEITO (caso real do dono, sala Designer): o dono mandou uma FOTO com a legenda "cria uma
// imagem dessa, copiando na nossa id visual". O bridge baixou a foto pro disco, colou no texto
// o marcador [IMAGEM ANEXADA: /path — use a ferramenta Read ...] e mandou pro motor um prompt
// de ~50 KB de TEXTO PURO. Nenhum dos dois buildUserInput olhava pro arquivo: o caminho existia
// só como frase dentro da fala. O modelo não viu a foto e inventou outra arte (um touro dourado
// no lugar de uma ilustração de dois rostos), sem nunca dizer que estava cego.
//
// Este módulo é a fonte ÚNICA da lista de imagens do turno, pros dois motores. Cada motor entrega
// pelo canal que o CLI dele aceita — Codex pelo item {type:"localImage"} do turn/start, Claude
// pelo caminho absoluto no prompt com ordem de leitura — mas quem decide QUAIS caminhos valem é
// aqui, uma régua só. O marcador continua na fala: o gate de classe lê ele (18/09), e tirá-lo
// desarmaria aquele conserto.
//
// A régua é conservadora de propósito: caminho não-absoluto, arquivo que não existe, extensão
// que o motor não lê, ou anexo que não é imagem (doc/PDF, que já viajam pré-convertidos pra
// texto) ficam de fora em silêncio — o turno segue exatamente como antes, com o marcador. O
// dossiê nunca passa por aqui.

const fs = require('node:fs');
const path = require('node:path');

// O que os dois motores leem como imagem. Fora desta lista, o anexo continua só marcador: é o
// mesmo conjunto que a API aceita e que o Read do Claude Code abre nativo.
const EXTENSOES = Object.freeze(['.jpg', '.jpeg', '.png', '.gif', '.webp']);

// Kill-switch do dono. Nasce LIGADA porque isto é conserto de defeito, não capacidade nova: o
// comportamento cego é o bug. Com LEON_MOTOR_VE_IMAGEM=0 os dois motores voltam ao turno de
// texto puro com o marcador, que é o de antes deste commit.
function motorVeImagemLigado(envSource = process.env) {
  return String((envSource && envSource.LEON_MOTOR_VE_IMAGEM) || '1').trim() !== '0';
}

function ehImagem(caminho) {
  return EXTENSOES.includes(path.extname(String(caminho || '')).toLowerCase());
}

// Os caminhos de imagem deste turno, prontos pro motor. Devolve [] sempre que houver qualquer
// dúvida: um anexo que não chega é o defeito de hoje, mas um caminho inventado seria pior.
function anexosDeImagem(entrada, envSource = process.env) {
  if (!motorVeImagemLigado(envSource)) return [];
  const bruto = entrada && Array.isArray(entrada.imagens) ? entrada.imagens : [];
  const vistos = new Set();
  const saida = [];
  for (const item of bruto) {
    if (typeof item !== 'string' || !item.trim()) continue;
    const abs = path.resolve(item.trim());
    // Só caminho ABSOLUTO: o cwd do motor é o do turno, não o do bridge, então caminho relativo
    // resolveria em pasta errada e o motor leria um arquivo que não é o do dono — ou nenhum.
    if (abs !== item.trim() && !path.isAbsolute(item.trim())) continue;
    if (vistos.has(abs) || !ehImagem(abs)) continue;
    // O arquivo tem que EXISTIR agora, na hora de montar o turno. O sweepTmp varre a cada 30 min
    // e apaga por idade (6 h de retenção), então a foto deste turno está viva — mas conferir aqui
    // é o que impede o motor de receber um caminho morto e alucinar em cima dele.
    try { if (!fs.statSync(abs).isFile()) continue; } catch { continue; }
    vistos.add(abs);
    saida.push(imagemLeveLigada(envSource) ? copiaLeve(abs, envSource) : imagemReduzidaLigada(envSource) ? copiaReduzida(abs, envSource) : abs);
  }
  return saida;
}

// ── A2 DO ENSAIO SECO (24/09): IMAGEM REDUZIDA PRO MOTOR ────────────────────────────────────────
// REGUA NATIVA DO PROVEDOR (revisao 24/09). A primeira versao cortava o lado maior em 1.200 px (a V6
// do laboratorio, molde image-sanitization do gateway de referencia, que ainda espera a rodada ao
// vivo). Isso deixava o modelo mais burro do que ele e: um print de celular 1170x2532 virava 555x1200,
// quando o provedor le nativo cerca de 724x1568 no Claude (lado maior ate 1.568 px e ate ~1,15 MP).
// Agora a copia vai exatamente ao tamanho que o provedor le: lado maior ate 1.568 px E area ate
// 1,15 MP, o que vier primeiro. O modelo ve os mesmos pixels que veria com o original; so os bytes
// caem (foto do Telegram 4000x3000 de 2,4 MB vira 1238x928). O original NAO muda e o caminho dele
// segue na fala (o marcador e o bloco de assets citam o original), entao editar e montar arte
// continua sobre o arquivo cheio. So reduz: imagem que ja cabe, GIF (pode ser animado) ou falha do
// ffmpeg entregam o original, igual a antes. A copia mora AO LADO do original (mesma pasta): quem
// podia ler o original (TMP_DIR no --add-dir do Claude, a pasta de entrada privada da folha) le a
// copia tambem. Refeita so quando o original muda (tamanho e mtime entram na chave); o prefixo novo
// (nativa-) nao reaproveita copia de 1.200 px feita pela versao anterior. Nasce LIGADA, pelos tres
// motores ao mesmo tempo, porque este modulo e a regua unica deles; LEON_IMAGEM_REDUZIDA=0 manda o
// original como antes.
const LADO_MAX = 1568;
const PIXELS_MAX = 1150000;
function imagemReduzidaLigada(envSource = process.env) {
  return String((envSource && envSource.LEON_IMAGEM_REDUZIDA) || '1').trim() !== '0';
}
function copiaReduzida(abs, envSource = process.env) {
  try {
    const ext = path.extname(abs).toLowerCase();
    if (ext === '.gif') return abs;
    const base = path.basename(abs);
    if (base.startsWith('nativa-') || base.startsWith('leve1200-')) return abs;
    const st = fs.statSync(abs);
    const { createHash } = require('node:crypto');
    const chave = createHash('sha256').update(`${abs}\0${st.size}\0${st.mtimeMs}`).digest('hex').slice(0, 16);
    const extSaida = ext === '.jpeg' ? '.jpg' : ext;
    const destino = path.join(path.dirname(abs), `nativa-${chave}${extSaida}`);
    try { if (fs.statSync(destino).size > 0) return destino; } catch {}
    const ffmpeg = String((envSource && envSource.FFMPEG_BIN) || 'ffmpeg');
    const { spawnSync } = require('node:child_process');
    const tmp = path.join(path.dirname(abs), `.nativa-${chave}-${process.pid}${extSaida}`);
    const r = spawnSync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-i', abs,
      '-vf', `scale=w='trunc(iw*min(1,min(${LADO_MAX}/max(iw,ih),sqrt(${PIXELS_MAX}/(iw*ih))))/2)*2':h=-2`,
      ...(extSaida === '.jpg' ? ['-q:v', '3'] : []), '-frames:v', '1', tmp],
    { timeout: 30000, stdio: ['ignore', 'ignore', 'pipe'] });
    if (r.status !== 0) { try { fs.unlinkSync(tmp); } catch {} return abs; }
    const novo = fs.statSync(tmp).size;
    // copia que nao ficou menor nao serve (imagem ja pequena): o motor recebe o original
    if (!novo || novo >= st.size) { try { fs.unlinkSync(tmp); } catch {} return abs; }
    try { fs.chmodSync(tmp, 0o600); } catch {}
    fs.renameSync(tmp, destino);
    return destino;
  } catch {
    return abs;
  }
}

// ── LABORATÓRIO DE LEVEZA V6 (23/09, LEON_IMAGEM_LEVE, nasce 0) ──────────────────────────────────
// Molde do gateway de referência (src/agents/image-sanitization.ts: lado maior em 1.200 px antes de mandar ao
// modelo). O motor recebe uma CÓPIA reduzida; o original fica no disco e o caminho dele segue na
// fala (o marcador não muda), então editar e montar arte continua sobre o arquivo cheio. Só reduz:
// imagem menor que o limite, GIF (pode ser animado) ou falha do ffmpeg devolvem o original, igual
// a hoje. A cópia mora AO LADO do original (prefixo leve1200-, mesma pasta), igual à cópia nativa:
// quem podia ler o original (a pasta de entrada privada da folha, o --add-dir do Claude) lê a cópia,
// e a retenção de 6 h da pasta temporária apaga as duas juntas (24/09: na pasta imagem-leve da casa
// a folha da casa de cliente recebia um caminho fora das raízes dela). Refeita só quando o original muda.
const LADO_MAX_LEVE = 1200;
function imagemLeveLigada(envSource = process.env) {
  return String((envSource && envSource.LEON_IMAGEM_LEVE) || '0').trim() === '1';
}
function copiaLeve(abs, envSource = process.env) {
  try {
    const ext = path.extname(abs).toLowerCase();
    if (ext === '.gif') return abs;
    const st = fs.statSync(abs);
    const { createHash } = require('node:crypto');
    const chave = createHash('sha256').update(`${abs}\0${st.size}\0${st.mtimeMs}`).digest('hex').slice(0, 16);
    const base = path.basename(abs);
    if (base.startsWith('nativa-') || base.startsWith('leve1200-')) return abs;
    const destino = path.join(path.dirname(abs), `leve1200-${chave}${ext === '.jpeg' ? '.jpg' : ext}`);
    try { if (fs.statSync(destino).size > 0) return destino; } catch {}
    const ffmpeg = String((envSource && envSource.FFMPEG_BIN) || 'ffmpeg');
    const { spawnSync } = require('node:child_process');
    const tmp = path.join(path.dirname(abs), `.leve1200-${chave}-${process.pid}${ext === '.jpeg' ? '.jpg' : ext}`);
    const r = spawnSync(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-i', abs,
      '-vf', `scale=w='min(${LADO_MAX_LEVE},iw)':h='min(${LADO_MAX_LEVE},ih)':force_original_aspect_ratio=decrease`,
      ...(ext === '.jpg' || ext === '.jpeg' ? ['-q:v', '3'] : []), '-frames:v', '1', tmp],
    { timeout: 30000, stdio: ['ignore', 'ignore', 'pipe'] });
    if (r.status !== 0) { try { fs.unlinkSync(tmp); } catch {} return abs; }
    const novo = fs.statSync(tmp).size;
    // cópia que não ficou menor não serve (imagem já pequena): o motor recebe o original
    if (!novo || novo >= st.size) { try { fs.unlinkSync(tmp); } catch {} return abs; }
    try { fs.chmodSync(tmp, 0o600); } catch {}
    fs.renameSync(tmp, destino);
    return destino;
  } catch {
    return abs;
  }
}

module.exports = { anexosDeImagem, motorVeImagemLigado, imagemReduzidaLigada, copiaReduzida, LADO_MAX, PIXELS_MAX, imagemLeveLigada, copiaLeve, LADO_MAX_LEVE, EXTENSOES };
