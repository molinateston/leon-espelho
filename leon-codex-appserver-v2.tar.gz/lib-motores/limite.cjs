// lib-motores/limite.cjs — UM DETECTOR DE FALHA DO MOTOR, UM ESTADO POR MOTOR (familia MOTOR, parte b).
//
// POR QUE ESTE MODULO EXISTE. Antes a mesma pergunta — "este turno morreu por cota? por login? ou
// foi coisa passageira?" — era respondida por QUATRO regex diferentes espalhadas:
//   - bridge isCotaMortaMsg  (usage limit|hit your usage|purchase more credits)
//   - bridge isLimitMsg      (< 280 chars, rate.?limit incluido)
//   - claude.cjs isLimitMessage
//   - codex-appserver.cjs (< 500 chars, usageLimitExceeded, balance is too low)
// So a do bridge levantava bandeira, e ela era a MAIS ESTREITA: um limite do Claude que so diz
// "hit your limit"/"usageLimitExceeded" nao levantava bandeira, o turno morria com texto generico
// e o dono repetia pra sempre. Este modulo e a fonte UNICA da classificacao, e le tambem o campo
// ESTRUTURADO out.cota/out.limiteAte/out.limiteTipo/out.limiteStatus que os dois motores ja
// entregam (claude.cjs, codex-appserver.cjs) — evidencia estruturada acima de regex de texto.
//
// SEM ESTADO, SEM DISCO, SEM require do bridge: funcao pura. O bridge decide o que fazer com a
// classificacao (levantar bandeira por motor, trocar de motor, renomear credencial revogada). Isso
// mantem o modulo testavel isolado e reusavel pelas duas familias.
//
// A ESCADA DE JANELA adota a do agente de referencia (classifyRateLimitWindow, retry-evidence.ts:104-132;
// MAX_SHORT_WINDOW_RETRY_AFTER_SECONDS=60): reset a mais de 60s / diario / rejected = LONGA; ate
// 60s ou so texto transitorio = CURTA; nada disso = DESCONHECIDA (kind unknown: sem numero chutado).

'use strict';

// Piso do "curto" em segundos: reset dentro disso e uma janela CURTA (transitoria), acima e LONGA.
// Espelha MAX_SHORT_WINDOW_RETRY_AFTER_SECONDS do agente de referencia.
const JANELA_CURTA_MAX_S = 60;

// Sinais de LOGIN (nao e cota: o motor precisa RECONECTAR, nao esperar o teto liberar). Captura o
// que os CLIs cospem quando a credencial foi revogada/expirou: "not logged in", "please run login",
// invalid_grant, 401/403/unauthorized, "no credentials". Fica separado da cota de proposito — a cura
// e diferente (renomear a credencial revogada e reconectar, nao esperar o reset).
//
// BUG-01 TROCA (13/09): o Codex, com o refresh token revogado, cospe "Your access token could not be
// refreshed because your refresh token was revoked". Antes esta frase NAO batia em NENHUMA alternativa
// do RE_AUTH (o gate), entao a classificacao caia em 'nenhuma': o turno morria mudo e a troca
// automatica nunca disparava (ela so trata classe de motor). "revoked" e "could not be refreshed"
// (com "token" na frase) sao sinais de auth: o RE_AUTH passa a reconhece-los, e como o RE_AUTH_PERMANENTE
// (consultado DENTRO do ramo auth) tambem os tem, a classe vira 'auth_permanent' — a cura e reconectar
// (ou trocar pro motor logado), nunca esperar teto.
const RE_AUTH = /not logged in|please run\s*\/?login|run codex login|no credentials|invalid_grant|token (has )?expired|refresh token|(access )?token (was |has been |could not be )?(revoked|refreshed)|revoked|unauthorized|authentication (failed|required)|\b401\b|\b403\b|n[ãa]o (est[áa] |estou )?logad/i;
// invalid_grant e token revogado NAO se cura sozinho com re-teste: e permanente ate reconectar.
const RE_AUTH_PERMANENTE = /invalid_grant|token (was |has been |has )?revoked|refresh token (was )?revoked|revoked|no credentials|not logged in|please run\s*\/?login|run codex login/i;

// Sinais de COTA/LIMITE de teto do plano (janela LONGA sem prazo quando nao ha horario). Uniao das
// quatro regex antigas, sem a limitacao de tamanho (o bridge tinha < 280, o appserver < 500 — e a
// mensagem estava sendo cortada e escapando).
// 21/09 (caso real de cliente por login do plano ChatGPT): faltava "session limit" e o
// "resets at/in" solto. O Codex diz "Your session limit resets in 2 hours" sem nunca escrever
// "usage limit", entao a classificacao caia em 'nenhuma': nenhuma bandeira subia, o aviso de
// limite repetia a cada mensagem do dono e a cada tarefa retomada. "resets at/in" so entra
// junto de "limit" na frase: sozinho ele aparece em texto normal e nao e evidencia de teto.
const RE_COTA_LONGA = /usage limit|hit your (usage )?limit|limit reached|session limit|limit[^.\n]{0,30}resets? (at|in)\b|purchase more credits|credit balance|balance is too low|usageLimitExceeded|insufficient_quota|quota exceeded/i;
// Sinais TRANSITORIOS (rate limit de burst, 429, too many requests): janela CURTA, re-testa logo.
const RE_TRANSITORIA = /rate.?limit|too many requests|\b429\b|overloaded|temporarily unavailable|try again/i;

// BUG TIMEOUT (13/09): o Codex, no mestre vivo (topico Incorporacao), cai REPETIDO com duas
// assinaturas de log — "Codex app-server thread/resume timed out after 15000ms" e "Codex encerrou
// o turno com status failed" — e o dono nao consegue trabalhar. Nenhuma delas batia em RE_AUTH,
// RE_COTA_LONGA nem RE_TRANSITORIA, entao a classe caia em 'nenhuma' e a troca automatica nunca
// disparava: a casa ficava presa no Codex morto. Estas frases sao TIMEOUT do motor (o app-server
// nao respondeu no prazo, ou o turno voltou 'failed' sem sinal de auth/cota) — NAO e permanente
// (pode ser transitorio), mas trocar pro outro motor resolve ESTE turno na hora. RE_STATUS_FAILED
// so vira timeout quando NAO ha sinal de auth/cota na mensagem (senao a causa real ganha).
const RE_TIMEOUT = /thread\/resume timed out|app-?server.*timed out|timed out after|resume timed out/i;
const RE_STATUS_FAILED = /encerrou o turno com status failed|turn (ended|finished) with status failed|status[:= ]+failed/i;

// tipos diarios/semanais do rateLimitType do Claude (claude.cjs colhe rateLimitType do evento).
const RE_TIPO_LONGO = /five_hour|seven_day|overage/i;
// PROMPT LONGO (thread cheia): "Prompt is too long"; a cura e HANDOFF (trocar thread), nao trocar motor.
const RE_PROMPT_LONGO = /prompt is too long|context (length|window) exceeded|maximum context|too many tokens|input is too long|compaction failed/i;

function _numFinite(v) { return (typeof v === 'number' && Number.isFinite(v)) ? v : null; }

// classificaFalhaDoMotor(out) -> { tipo, janela, ate, motor }
//   tipo:   'auth'          login precisa reconectar (curavel: renomear credencial + /login)
//           'auth_permanent' credencial revogada/expirada (nunca volta sozinha)
//           'cota'          teto do plano batido (janela longa/curta; volta no reset)
//           'transitoria'   burst/429 (janela curta, re-testa logo)
//           'timeout'       app-server nao respondeu no prazo, ou turno voltou 'failed' sem
//                           sinal de auth/cota. NAO e permanente (pode ser transitorio); trocar
//                           pro outro motor resolve ESTE turno. Repeticao rebaixa a casa.
//           'nenhuma'       nao e falha classificavel de motor
//   janela: 'longa' | 'curta' | 'desconhecida' | null   (so pra cota/transitoria)
//   ate:    epoch ms do reset, quando conhecido (out.limiteAte), senao null
// Recebe o `out` normalizado do motor: { erro, cota, limiteAte, limiteTipo, limiteStatus }.
function classificaFalhaDoMotor(out) {
  const o = out || {};
  const texto = String(o.erro || '');
  const ate = _numFinite(o.limiteAte);
  const tipo = String(o.limiteTipo || '');
  const status = String(o.limiteStatus || '');
  const diario = RE_TIPO_LONGO.test(tipo);

  // 1) LOGIN vem PRIMEIRO: um 401 nunca deve ser lido como "espera o teto liberar". A cura e
  //    reconectar, e ate um 401 dentro de uma mensagem que tambem fala de "limit" e login.
  if (RE_AUTH.test(texto)) {
    return {
      tipo: RE_AUTH_PERMANENTE.test(texto) ? 'auth_permanent' : 'auth',
      janela: null, ate: null,
    };
  }

  // 2) COTA por evidencia ESTRUTURADA (o motor ja decidiu): out.cota true, ou status rejected,
  //    ou horario de reset em banda, ou tipo diario/semanal.
  const cotaEstrutural = !!o.cota || status === 'rejected' || ate != null || diario;
  if (cotaEstrutural) {
    if (ate != null) {
      const faltaS = (ate - Date.now()) / 1000;
      if (faltaS > JANELA_CURTA_MAX_S || diario || status === 'rejected') return { tipo: 'cota', janela: 'longa', ate };
      return { tipo: 'cota', janela: 'curta', ate };
    }
    if (diario || status === 'rejected') return { tipo: 'cota', janela: 'longa', ate: null };
    // out.cota true sem mais nada: decide pelo texto abaixo, mas ja e cota.
    if (RE_COTA_LONGA.test(texto)) return { tipo: 'cota', janela: 'longa', ate: null };
    if (RE_TRANSITORIA.test(texto)) return { tipo: 'cota', janela: 'curta', ate: null };
    return { tipo: 'cota', janela: 'desconhecida', ate: null };
  }

  // 3) COTA por TEXTO (sem estrutura): "usage limit"/"hit your limit" = teto do plano, janela longa.
  if (RE_COTA_LONGA.test(texto)) return { tipo: 'cota', janela: 'longa', ate: null };

  // 4) TRANSITORIA: burst/429/overloaded — janela curta, re-testa logo.
  if (RE_TRANSITORIA.test(texto)) return { tipo: 'transitoria', janela: 'curta', ate: null };

  // 5) TIMEOUT: app-server nao respondeu no prazo, ou turno voltou 'failed' sem sinal de auth/cota
  //    (auth e cota ja retornaram acima, entao aqui a causa nao e nenhuma delas). Janela curta:
  //    NAO e permanente — trocar pro outro motor faz ESTE turno responder; a repeticao e que rebaixa.
  if (RE_PROMPT_LONGO.test(texto)) return { tipo: 'prompt_longo', janela: 'curta', ate: null };
  if (RE_TIMEOUT.test(texto) || RE_STATUS_FAILED.test(texto)) return { tipo: 'timeout', janela: 'curta', ate: null };

  // 6) Nada classificavel.
  return { tipo: 'nenhuma', janela: null, ate: null };
}

// Atalhos legiveis pro bridge, pra o call-site dizer a intencao (e nao repetir === 'auth').
function ehFalhaDeLogin(out) { const c = classificaFalhaDoMotor(out); return c.tipo === 'auth' || c.tipo === 'auth_permanent'; }
function ehFalhaDeCota(out) { return classificaFalhaDoMotor(out).tipo === 'cota'; }
function ehFalhaDeTimeout(out) { return classificaFalhaDoMotor(out).tipo === 'timeout'; }

module.exports = {
  classificaFalhaDoMotor,
  ehFalhaDeLogin,
  ehFalhaDeCota,
  ehFalhaDeTimeout,
  JANELA_CURTA_MAX_S,
  // exportadas pro teste cobrir as regex sem re-declarar
  _RE: { RE_AUTH, RE_AUTH_PERMANENTE, RE_COTA_LONGA, RE_TRANSITORIA, RE_TIPO_LONGO, RE_TIMEOUT, RE_STATUS_FAILED },
};
