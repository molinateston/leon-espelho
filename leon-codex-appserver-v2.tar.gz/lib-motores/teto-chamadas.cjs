'use strict';
// lib-motores/teto-chamadas.cjs — CORTE 2 (22/09): teto de chamadas por fala, com fecho honesto.
//
// Desenho: /root/DESENHO-LEON-ECONOMICO-22SET.md, "Corte 2". Medido em 1.570 falas: as chamadas
// depois da 30ª de cada fala somam 43% do custo equivalente. VALOR DA FROTA (2.6.8, 23/09): a flag
// LEON_TURNO_TETO_CHAMADAS ausente vale 30 (LIGADA); o padrao mora no bridge (tetoChamadasDaFala),
// e "0" no .env desliga. Ate a 2.6.7 nascia 0. Ao chegar em N chamadas de TRABALHO na
// mesma fala, o motor corta o turno (turn/interrupt no Codex, interrupt do handle no Claude) e o
// bridge fecha com uma linha ao dono: o que fez, onde parou, "sigo?". Nunca mudo.
//
// Este arquivo e SO a contagem, pura e isolada, pra que o corte 0 (que escuta as mesmas
// notificacoes em codex-appserver.cjs) e o corte 2 se unam sem conflito: quem escuta chama
// `registra(n)` e olha o retorno; nada aqui faz IO nem chama RPC.
//
// O que conta (fonte unica dos dois motores, paridade Codex = Claude). LISTA DE INCLUSAO: so
// o que e trabalho conta; tipo novo que o app-server inventar fica em 0 ate alguem decidir,
// porque contar a mais corta fala boa dentro da regua (revisao 22/09, schema do codex 0.154.0):
//   Codex (forma RPC do app-server, com barra):
//     item/completed de commandExecution, fileChange, mcpToolCall, dynamicToolCall, webSearch,
//       imageGeneration e collabAgentToolCall = 1. `sleep` e espera: meia (0,5). Mensagem,
//       raciocinio, plano, compactacao, hookPrompt, imageView, functionCallOutput (a saida de
//       uma chamada ja contada) e subAgentActivity (estado do sub-agente, que no Claude tambem
//       nao conta) = 0.
//     item/commandExecution/terminalInteraction (o write_stdin do unified exec) = 1 com `stdin`
//       nao vazio; `stdin` vazio e espera de processo longo, conta MEIA (0,5).
//     item/completed de commandExecution com source unifiedExecInteraction (a mesma interacao
//       vista como item): so conta se o terminalInteraction daquele item NAO chegou antes, pra
//       nunca contar a mesma espera duas vezes; sem entrada visivel no item, meia.
//   Claude (stream-json): cada bloco tool_use do fio PRINCIPAL = 1 (sub-agente nao conta: e a
//     mesma regra do usage, claude.cjs). BashOutput/TaskOutput sao a espera do Claude: meia.
//
// A "ultima acao" que vai pro dono, pro checkpoint e pro prompt de continuacao e SEMPRE um
// rotulo traduzido ("rodando um comando", "mexendo em x.cjs"), nunca o comando cru: saida
// limpa (17/09) e linha de comando pode carregar segredo.

const TRABALHO_CODEX = new Map([
  ['commandExecution', 1], ['fileChange', 1], ['mcpToolCall', 1], ['dynamicToolCall', 1],
  ['webSearch', 1], ['imageGeneration', 1], ['collabAgentToolCall', 1], ['sleep', 0.5],
]);
const FONTE_INTERACAO = new Set(['unifiedExecInteraction', 'unified_exec_interaction']);
const ESPERA_CLAUDE = new Set(['BashOutput', 'TaskOutput']);

// Le o VALOR da flag (o padrao da frota, 30, o bridge poe quando a chave esta ausente). Aqui:
// vazio, 0, negativo ou lixo = 0 (desligado).
function tetoDaFlag(valor) {
  const n = Math.floor(Number(String(valor == null ? '' : valor).trim()));
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function _entradaDoItem(item) {
  for (const campo of ['stdin', 'input', 'interactionInput', 'interaction_input', 'chars']) {
    if (item && typeof item[campo] === 'string') return item[campo];
  }
  return null;
}

function _base(caminho) {
  const b = String(caminho || '').split(/[\\/]/).filter(Boolean).pop() || '';
  const limpo = b.replace(/[^\p{L}\p{N}._-]/gu, '').slice(0, 60);
  return limpo || null;
}
function _nomeFerramenta(nome) {
  const n = String(nome || '').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 40);
  return n || null;
}

// Rotulo do passo em curso, na lingua do dono. Nunca o comando, a query ou o conteudo cru.
function _acaoCodex(item) {
  if (!item || typeof item !== 'object') return null;
  switch (item.type) {
    case 'commandExecution': return 'rodando um comando';
    case 'fileChange': {
      const alvo = Array.isArray(item.changes) && item.changes[0] && _base(item.changes[0].path);
      return alvo ? `mexendo em ${alvo}` : 'mexendo nos arquivos';
    }
    case 'mcpToolCall': case 'dynamicToolCall': {
      const n = _nomeFerramenta(item.tool);
      return n ? `usando a ferramenta ${n}` : 'usando uma ferramenta';
    }
    case 'webSearch': return 'pesquisando na web';
    case 'imageGeneration': return 'gerando uma imagem';
    case 'collabAgentToolCall': return 'coordenando um ajudante';
    case 'sleep': return 'esperando um processo longo';
    default: return null;
  }
}
function _acaoClaude(bloco) {
  const nome = String((bloco && bloco.name) || '');
  const input = (bloco && bloco.input) || {};
  if (ESPERA_CLAUDE.has(nome)) return 'esperando um processo longo';
  if (nome === 'Bash' || nome === 'KillShell' || nome === 'KillBash') return 'rodando um comando';
  if (['Edit', 'Write', 'MultiEdit', 'NotebookEdit'].includes(nome)) {
    const alvo = _base(input.file_path || input.notebook_path);
    return alvo ? `mexendo em ${alvo}` : 'mexendo nos arquivos';
  }
  if (nome === 'Read') { const alvo = _base(input.file_path); return alvo ? `lendo ${alvo}` : 'lendo arquivos'; }
  if (nome === 'Grep' || nome === 'Glob') return 'procurando nos arquivos';
  if (nome === 'WebFetch' || nome === 'WebSearch') return 'pesquisando na web';
  if (nome === 'Task' || nome === 'Agent') return 'coordenando um ajudante';
  const n = _nomeFerramenta(nome);
  return n ? `usando a ferramenta ${n}` : 'usando uma ferramenta';
}

function criaContadorTeto(teto) {
  const limite = tetoDaFlag(teto);
  let chamadas = 0;
  let esperas = 0;
  let estourou = false;
  let ultimaAcao = null;
  const interacaoVista = new Set();

  function soma(peso, acao) {
    chamadas += peso;
    if (peso < 1) esperas += 1;
    if (acao) ultimaAcao = acao;
    if (limite > 0 && !estourou && chamadas >= limite) {
      estourou = true;
      return { estourou: true, agora: true };
    }
    return { estourou, agora: false };
  }

  // Recebe UMA notificacao (Codex: {method, params}; Claude: evento {type, message}).
  // Devolve { estourou, agora }: `agora` e true so na notificacao que cruzou o teto.
  function registra(n) {
    try {
      if (!n || typeof n !== 'object') return { estourou, agora: false };
      if (n.method === 'item/commandExecution/terminalInteraction') {
        const p = n.params || {};
        if (p.itemId) interacaoVista.add(String(p.itemId));
        const vazio = !String(p.stdin == null ? '' : p.stdin).length;
        return soma(vazio ? 0.5 : 1, vazio ? 'esperando um processo longo' : null);
      }
      if (n.method === 'item/completed') {
        const item = n.params && n.params.item;
        const tipo = item && item.type;
        if (!tipo || !TRABALHO_CODEX.has(tipo)) return { estourou, agora: false };
        if (tipo === 'commandExecution' && FONTE_INTERACAO.has(item.source)) {
          if (item.id && interacaoVista.has(String(item.id))) return { estourou, agora: false };
          const entrada = _entradaDoItem(item);
          return soma(entrada && entrada.length ? 1 : 0.5, _acaoCodex(item));
        }
        return soma(TRABALHO_CODEX.get(tipo), _acaoCodex(item));
      }
      if (n.type === 'assistant' && n.message && !n.isSidechain
        && !n.parent_tool_use_id && !n.message.parent_tool_use_id) {
        const blocos = Array.isArray(n.message.content) ? n.message.content : [];
        let r = { estourou, agora: false };
        for (const b of blocos) {
          if (!b || b.type !== 'tool_use') continue;
          const nome = String(b.name || '');
          const x = soma(ESPERA_CLAUDE.has(nome) ? 0.5 : 1, _acaoClaude(b));
          if (x.agora) r = x;
        }
        return r.agora ? r : { estourou, agora: false };
      }
    } catch {}
    return { estourou, agora: false };
  }

  function estado() {
    return { teto: limite, chamadas, esperas, estourou, ultimaAcao };
  }

  return { registra, estado, ligado: limite > 0 };
}

// A linha ao dono. Uma so, na voz do agente: o que fez, onde parou, "sigo?". Sem jargao de motor.
function fraseFecho(estado, atividade = {}) {
  const e = estado || {};
  const feitas = Math.floor(Number(e.chamadas) || 0);
  const gravou = Number(atividade.mutationsSucceeded) || 0;
  const leu = Number(atividade.readsSucceeded) || 0;
  const partes = [];
  if (gravou) partes.push(`${gravou} ${gravou === 1 ? 'alteração' : 'alterações'}`);
  if (leu) partes.push(`${leu} ${leu === 1 ? 'leitura' : 'leituras'}`);
  const fez = partes.length ? partes.join(' e ') : `${feitas} passos de trabalho`;
  // So o rotulo traduzido do CONTADOR (ultimaAcao). O friendlyAction do painel cola o 1o argumento
  // cru do comando ("env API_KEY=sk-... node x" vira "Rodando um comando API_KEY=sk-..."), e esta
  // linha vai pro chat, pro checkpoint em disco e pro prompt da continuacao. Cinto extra: palavra
  // com "=" (atribuicao, flag com valor) cai fora mesmo que um rotulo futuro a traga.
  const limpo = String(e.ultimaAcao || '').replace(/\s+/g, ' ').trim().split(' ').filter((w) => w && !w.includes('=')).join(' ');
  const onde = (limpo || 'no último passo').slice(0, 120);
  return `Fiz ${fez} neste pedido e parei no teto de ${e.teto || feitas} chamadas pra não gastar à toa; parei em: ${onde}. Sigo?`;
}

module.exports = { criaContadorTeto, tetoDaFlag, fraseFecho };
