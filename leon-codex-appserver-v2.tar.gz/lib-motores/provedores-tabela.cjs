'use strict';
// lib-motores/provedores-tabela.cjs — LEITOR da tabela de motores por API (A1/A2, 21/09/2026).
//
// Modulo minusculo de proposito: ele e a UNICA porta de config/provedores.json, e nao depende
// de nenhum outro modulo de motor. Quem precisa da tabela (index.cjs pro catalogo e pro
// MOTORES_CONHECIDOS, codex-appserver.cjs pro LEAF_ALLOWED_SECRET_ENV, seletor.cjs pro teclado
// do /motor, provedor-api.cjs pro adaptador) carrega daqui sem circulo de require — se a tabela
// morasse no provedor-api.cjs, o codex-appserver teria que requerer quem ja o requer.
//
// LEI DA CASA MUDA (18/09, caso do Carlos): tabela quebrada NAO pode derrubar o boot. Um JSON
// invalido aqui deixaria a casa sem subir por causa de um motor OPCIONAL. Por isso todo erro
// de leitura vira tabela vazia com um aviso no log: a casa sobe nos motores nativos (codex e
// claude) e o dono ve o motivo, em vez de ficar muda.

const fs = require('node:fs');
const path = require('node:path');

const CAMINHO_PADRAO = path.resolve(__dirname, '..', 'config', 'provedores.json');

let cache = null;
let cacheDe = null;

function caminhoDaTabela(envSource = process.env) {
  const bruto = String((envSource && envSource.LEON_PROVEDORES_JSON) || '').trim();
  return bruto ? path.resolve(bruto) : CAMINHO_PADRAO;
}

// Uma linha so entra na tabela se estiver COMPLETA. Linha pela metade (sem base_url, sem
// variavel de chave) viraria um motor que aparece no /motor e morre no primeiro turno — pior
// que motor ausente, porque o dono escolhe e nao entende.
function normaliza(nome, bruto) {
  if (!bruto || typeof bruto !== 'object') return null;
  const linha = {
    nome: String(nome || '').toLowerCase().trim(),
    rotulo: String(bruto.rotulo || '').trim(),
    base_url: String(bruto.base_url || '').trim(),
    wire_api: String(bruto.wire_api || '').trim().toLowerCase(),
    variavel_chave: String(bruto.variavel_chave || '').trim(),
    credencial: String(bruto.credencial || '').trim(),
    env_arquivo_credencial: String(bruto.env_arquivo_credencial || '').trim() || null,
    modelo_padrao: String(bruto.modelo_padrao || '').trim(),
    modelos: Array.isArray(bruto.modelos) ? bruto.modelos.map(String).filter(Boolean) : [],
    efforts: Array.isArray(bruto.efforts) && bruto.efforts.length
      ? bruto.efforts.map(String) : ['medium'],
  };
  if (!linha.nome || !linha.rotulo || !linha.base_url || !linha.variavel_chave
      || !linha.credencial || !linha.modelo_padrao || !linha.modelos.length) return null;
  if (!linha.modelos.includes(linha.modelo_padrao)) linha.modelos.unshift(linha.modelo_padrao);
  if (!/^https:\/\//i.test(linha.base_url)) return null;   // chave de API so viaja em TLS
  linha.modelos = Object.freeze([...new Set(linha.modelos)]);
  linha.efforts = Object.freeze(linha.efforts);
  return Object.freeze(linha);
}

function carrega(envSource = process.env) {
  const arquivo = caminhoDaTabela(envSource);
  if (cache && cacheDe === arquivo) return cache;
  let tabela = Object.freeze({});
  try {
    const dados = JSON.parse(fs.readFileSync(arquivo, 'utf8'));
    const cru = (dados && dados.provedores) || {};
    const saida = {};
    for (const nome of Object.keys(cru)) {
      const linha = normaliza(nome, cru[nome]);
      if (linha) saida[linha.nome] = linha;
      else try { console.error(`[provedores] linha "${nome}" incompleta em ${arquivo}; ignorada`); } catch {}
    }
    tabela = Object.freeze(saida);
  } catch (erro) {
    try { console.error(`[provedores] tabela ilegivel em ${arquivo} (${erro && erro.message}); seguindo so com os motores nativos`); } catch {}
  }
  cache = tabela;
  cacheDe = arquivo;
  return tabela;
}

function provedores(envSource) { return carrega(envSource); }
function nomesDeProvedores(envSource) { return Object.keys(carrega(envSource)); }
function linhaDoProvedor(nome, envSource) {
  return carrega(envSource)[String(nome || '').toLowerCase().trim()] || null;
}
function ehProvedorApi(nome, envSource) { return Boolean(linhaDoProvedor(nome, envSource)); }

// As chaves de todos os provedores da tabela, pra quem monta allowlist derivada (A2/A6).
function variaveisDeChave(envSource) {
  const tabela = carrega(envSource);
  return Object.keys(tabela).map((nome) => tabela[nome].variavel_chave);
}

// So os testes: a tabela e lida uma vez por processo, e a prova troca o arquivo entre casos.
function _limpaCache() { cache = null; cacheDe = null; }

module.exports = {
  CAMINHO_PADRAO,
  caminhoDaTabela,
  provedores,
  nomesDeProvedores,
  linhaDoProvedor,
  ehProvedorApi,
  variaveisDeChave,
  _limpaCache,
  _normaliza: normaliza,
};
