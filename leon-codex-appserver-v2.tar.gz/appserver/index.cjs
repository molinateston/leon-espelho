'use strict';

module.exports = require('./adapter.cjs');
