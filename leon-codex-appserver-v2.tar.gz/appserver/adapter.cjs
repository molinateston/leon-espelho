'use strict';

const { spawn: nodeSpawn } = require('node:child_process');
const { EventEmitter } = require('node:events');

const DEFAULT_ENV_ALLOWLIST = Object.freeze([
  'PATH',
  'HOME',
  'USER',
  'LOGNAME',
  'SHELL',
  'LANG',
  'TERM',
  'COLORTERM',
  'NO_COLOR',
  'TZ',
  'TMPDIR',
  'TMP',
  'TEMP',
  'CODEX_HOME',
  'RUST_LOG',
  'RUST_BACKTRACE',
]);

const DEFAULT_ENV_ALLOW_PREFIXES = Object.freeze(['LC_']);

// The deny pattern wins over the ordinary allowlist. Only names explicitly
// listed in allowedSecretEnv may bypass it; that list is empty by default.
const DEFAULT_ENV_DENY_PATTERN = /(?:TOKEN|SECRET|PASSWORD|PASSWD|API[_-]?KEY|PRIVATE[_-]?KEY|CREDENTIAL|AUTH|COOKIE|SESSION|TELEGRAM|BOT[_-]?TOKEN|WEBHOOK|DATABASE[_-]?URL|SUPABASE|STRIPE|SLACK|DISCORD|GITHUB|GITLAB|ANTHROPIC|OPENAI[_-]?API|GOOGLE[_-]?(?:KEY|TOKEN|CREDENTIAL)|AWS[_-]|AZURE[_-]|REDIS|POSTGRES|MYSQL|MONGO|NODE_OPTIONS|NODE_PATH|LD_PRELOAD|LD_LIBRARY_PATH|DYLD_|BASH_ENV|PROMPT_COMMAND|RUBYOPT|PERL5OPT)/i;

class CodexAdapterError extends Error {
  constructor(message, options = {}) {
    super(message, options.cause ? { cause: options.cause } : undefined);
    this.name = this.constructor.name;
    if (Object.prototype.hasOwnProperty.call(options, 'method')) this.method = options.method;
    if (Object.prototype.hasOwnProperty.call(options, 'code')) this.code = options.code;
    if (Object.prototype.hasOwnProperty.call(options, 'data')) this.data = options.data;
    if (Object.prototype.hasOwnProperty.call(options, 'dispatched')) this.dispatched = Boolean(options.dispatched);
    if (Object.prototype.hasOwnProperty.call(options, 'rpcMessage')) this.rpcMessage = options.rpcMessage;
  }
}

class RpcError extends CodexAdapterError {
  constructor(method, error = {}) {
    const rpcMessage = error.message || 'unknown error';
    super(`Codex app-server ${method} failed (${error.code ?? -1}): ${rpcMessage}`, {
      method,
      code: error.code ?? -1,
      data: error.data,
      dispatched: true,
      rpcMessage,
    });
  }
}

class RpcTimeoutError extends CodexAdapterError {
  constructor(method, timeoutMs) {
    super(`Codex app-server ${method} timed out after ${timeoutMs}ms`, {
      method,
      code: null,
      data: undefined,
      rpcMessage: null,
    });
    this.timeoutMs = timeoutMs;
  }
}

class TurnTimeoutError extends CodexAdapterError {
  constructor(threadId, turnId, timeoutMs) {
    super(`Codex turn ${turnId || '<starting>'} on thread ${threadId} timed out after ${timeoutMs}ms`);
    this.threadId = threadId;
    this.turnId = turnId || null;
    this.timeoutMs = timeoutMs;
  }
}

class ProtocolError extends CodexAdapterError {}

class ChildProcessError extends CodexAdapterError {
  constructor(message, details = {}) {
    super(message, details.cause ? { cause: details.cause } : undefined);
    this.code = details.code ?? null;
    this.signal = details.signal ?? null;
    this.stderr = details.stderr || [];
  }
}

class BoundedRing {
  constructor(maxItems, maxBytes) {
    this.maxItems = maxItems;
    this.maxBytes = maxBytes;
    this.items = [];
    this.bytes = 0;
    this.dropped = 0;
  }

  push(value, size) {
    const bytes = Number.isFinite(size) ? Math.max(0, size) : estimateBytes(value);
    if (this.maxItems === 0 || this.maxBytes === 0 || bytes > this.maxBytes) {
      this.dropped += 1;
      return false;
    }
    while (this.items.length >= this.maxItems || this.bytes + bytes > this.maxBytes) {
      const removed = this.items.shift();
      this.bytes -= removed.bytes;
      this.dropped += 1;
    }
    this.items.push({ value, bytes });
    this.bytes += bytes;
    return true;
  }

  values() {
    return this.items.map((entry) => entry.value);
  }
}

class TurnHandle extends EventEmitter {
  constructor(adapter, threadId, generation, options) {
    super();
    this.adapter = adapter;
    this.threadId = threadId;
    this.turnId = null;
    this.generation = generation;
    this.startResponse = null;
    this.finalText = '';
    this.status = 'starting';
    this._settled = false;
    this._settlementError = null;
    this._agentItems = new Map();
    this._lastUnknownAgentText = '';
    this._onDelta = typeof options.onDelta === 'function' ? options.onDelta : null;
    this._onNotification = typeof options.onNotification === 'function' ? options.onNotification : null;
    this._timeoutMs = options.timeoutMs;
    this._maxAgentItems = options.maxAgentItems;
    this._maxAgentTextBytes = options.maxAgentTextBytes;
    this._agentTextBytes = 0;
    this._earlyNotifications = [];
    this._earlyNotificationBytes = 0;
    this._maxEarlyNotifications = options.maxEarlyNotifications;
    this._maxEarlyNotificationBytes = options.maxEarlyNotificationBytes;
    this._resolveCompletion = null;
    this._rejectCompletion = null;
    this.completion = new Promise((resolve, reject) => {
      this._resolveCompletion = resolve;
      this._rejectCompletion = reject;
    });
    // A turn may fail before startTurn returns the handle. Keep that race from
    // becoming an unhandled rejection while preserving rejection for callers.
    this.completion.catch(() => {});
    this._timeout = setTimeout(() => this._onTimeout(), this._timeoutMs);
    this._timeout.unref?.();
  }

  async steer(input, options = {}) {
    if (!this.turnId || this._settled) {
      throw new CodexAdapterError('Cannot steer a turn that is not active');
    }
    return this.adapter.steer(this.threadId, this.turnId, input, {
      ...options,
      generation: this.generation,
    });
  }

  async interrupt(options = {}) {
    if (!this.turnId || this._settled) {
      return {};
    }
    return this.adapter.interrupt(this.threadId, this.turnId, {
      ...options,
      generation: this.generation,
    });
  }

  _bindTurnId(turnId) {
    if (!turnId || typeof turnId !== 'string') {
      throw new ProtocolError('Codex app-server returned an invalid turn id');
    }
    if (this.turnId && this.turnId !== turnId) {
      throw new ProtocolError(`Turn id mismatch: ${this.turnId} != ${turnId}`);
    }
    if (!this.turnId) {
      this.turnId = turnId;
      this.status = 'inProgress';
      this.adapter._indexTurn(this);
    }
  }

  _consume(notification) {
    if (this._settled) return;
    const method = notification.method;
    const params = notification.params || {};
    if (method === 'item/started') {
      this._rememberAgentItem(params.item);
    } else if (method === 'item/agentMessage/delta') {
      this._consumeAgentDelta(params);
    } else if (method === 'item/completed') {
      this._completeAgentItem(params.item);
    } else if (method === 'turn/completed') {
      this._completeTurn(params.turn || {});
    }
    // Observers run only after internal routing. A callback may mutate its
    // object, but cannot rewrite the state machine that consumed this event.
    safeCallback(this.adapter, this._onNotification, notification, this);
  }

  _queueEarly(notification) {
    if (this._settled) return;
    const bytes = estimateBytes(notification);
    if (this._earlyNotifications.length >= this._maxEarlyNotifications
      || this._earlyNotificationBytes + bytes > this._maxEarlyNotificationBytes) {
      throw new ProtocolError('Early turn-notification buffer limit exceeded');
    }
    this._earlyNotifications.push({ notification, bytes });
    this._earlyNotificationBytes += bytes;
  }

  _flushEarly() {
    const queued = this._earlyNotifications;
    this._earlyNotifications = [];
    this._earlyNotificationBytes = 0;
    for (const entry of queued) {
      const scope = notificationScope(entry.notification);
      if (scope.threadId === this.threadId && scope.turnId === this.turnId) {
        this._consume(entry.notification);
      }
    }
  }

  _rememberAgentItem(item) {
    if (!item || item.type !== 'agentMessage' || typeof item.id !== 'string') return;
    const existing = this._agentItem(item.id);
    const wasFinal = existing.phase === 'final_answer';
    existing.phase = item.phase ?? existing.phase;
    if (typeof item.text === 'string' && (item.text || !existing.text)) {
      this._replaceAgentText(existing, item.text);
    }
    this._agentItems.set(item.id, existing);
    if (!wasFinal && existing.phase === 'final_answer' && existing.text && !existing.emitted) {
      existing.emitted = existing.text;
      this._emitDelta(existing.text, item.id);
    }
  }

  _consumeAgentDelta(params) {
    if (typeof params.itemId !== 'string' || typeof params.delta !== 'string') return;
    const item = this._agentItem(params.itemId);
    this._reserveAgentText(Buffer.byteLength(params.delta));
    item.text += params.delta;
    this._agentItems.set(params.itemId, item);
    if (item.phase === 'final_answer') {
      item.emitted += params.delta;
      this._emitDelta(params.delta, params.itemId);
    }
  }

  _completeAgentItem(item) {
    if (!item || item.type !== 'agentMessage' || typeof item.id !== 'string') return;
    const tracked = this._agentItem(item.id);
    tracked.phase = item.phase ?? tracked.phase;
    if (typeof item.text === 'string') this._replaceAgentText(tracked, item.text);
    this._agentItems.set(item.id, tracked);

    if (tracked.phase === 'commentary') return;
    if (tracked.phase === 'final_answer') {
      this._adoptFinalItem(item.id, tracked.text, tracked);
      return;
    }
    this._lastUnknownAgentText = tracked.text;
  }

  _adoptFinalItem(itemId, text, tracked = null) {
    const value = typeof text === 'string' ? text : '';
    const state = tracked || this._agentItem(itemId);
    if (state.text !== value) this._replaceAgentText(state, value);
    if (!state.emitted && value) {
      state.emitted = value;
      this._emitDelta(value, itemId);
    } else if (value.startsWith(state.emitted)) {
      const suffix = value.slice(state.emitted.length);
      if (suffix) {
        state.emitted = value;
        this._emitDelta(suffix, itemId);
      }
    } else if (value !== state.emitted) {
      safeEmit(this.adapter, 'streamMismatch', {
        threadId: this.threadId,
        turnId: this.turnId,
        itemId,
      });
    }
    state.phase = 'final_answer';
    this._agentItems.set(itemId, state);
    this.finalText = value;
  }

  _agentItem(itemId) {
    let item = this._agentItems.get(itemId);
    if (item) return item;
    if (this._agentItems.size >= this._maxAgentItems) {
      throw new ProtocolError(`Agent item count for one turn exceeded ${this._maxAgentItems}`);
    }
    item = emptyAgentItem();
    this._agentItems.set(itemId, item);
    return item;
  }

  _replaceAgentText(item, text) {
    const previousBytes = Buffer.byteLength(item.text);
    const nextBytes = Buffer.byteLength(text);
    this._reserveAgentText(nextBytes - previousBytes);
    item.text = text;
  }

  _reserveAgentText(additionalBytes) {
    const next = this._agentTextBytes + additionalBytes;
    if (next > this._maxAgentTextBytes) {
      throw new ProtocolError(`Agent text for one turn exceeded ${this._maxAgentTextBytes} bytes`);
    }
    this._agentTextBytes = Math.max(0, next);
  }

  _completeTurn(turn) {
    const items = Array.isArray(turn.items) ? turn.items : [];
    const finalItems = items.filter((item) => item?.type === 'agentMessage' && item.phase === 'final_answer');
    const unknownItems = items.filter((item) => item?.type === 'agentMessage' && item.phase == null);
    const canonical = finalItems.at(-1) || null;

    if (canonical) {
      this._adoptFinalItem(canonical.id, canonical.text);
    } else if (!this.finalText) {
      const fallback = unknownItems.at(-1)?.text ?? this._lastUnknownAgentText;
      if (fallback) {
        this.finalText = fallback;
        this._emitDelta(fallback, unknownItems.at(-1)?.id || null);
      }
    }

    const result = {
      threadId: this.threadId,
      turnId: this.turnId || turn.id || null,
      status: turn.status || 'completed',
      finalText: this.finalText,
      error: turn.error || null,
      turn,
      startResponse: this.startResponse,
    };
    this.status = result.status;
    this._settle(null, result);
  }

  _emitDelta(delta, itemId) {
    if (!delta) return;
    safeCallback(this.adapter, this._onDelta, delta, {
      threadId: this.threadId,
      turnId: this.turnId,
      itemId,
    });
    try {
      safeEmit(this, 'delta', delta, {
        threadId: this.threadId,
        turnId: this.turnId,
        itemId,
      });
    } catch {}
  }

  _onTimeout() {
    if (this._settled) return;
    const error = new TurnTimeoutError(this.threadId, this.turnId, this._timeoutMs);
    this._settle(error);
    this.adapter._handleTurnTimeout(this, error);
  }

  _fail(error) {
    this._settle(error instanceof Error ? error : new CodexAdapterError(String(error)));
  }

  _settle(error, result) {
    if (this._settled) return;
    this._settled = true;
    this._settlementError = error || null;
    this._earlyNotifications = [];
    this._earlyNotificationBytes = 0;
    clearTimeout(this._timeout);
    this.adapter._unindexTurn(this);
    if (error) {
      this.status = 'failed';
      this._rejectCompletion(error);
    } else {
      this._resolveCompletion(result);
    }
  }
}

class CodexAppServerAdapter extends EventEmitter {
  constructor(options = {}) {
    super();
    this.command = requireString(options.command ?? 'codex', 'command');
    this.args = Array.isArray(options.args) ? options.args.map(String) : ['app-server'];
    this.cwd = options.cwd || process.cwd();
    this.spawnImpl = options.spawnImpl || nodeSpawn;
    this.killImpl = options.killImpl || process.kill.bind(process);
    this.envSource = options.envSource || process.env;
    this.envOverrides = options.env || {};
    this.envAllowlist = options.envAllowlist || DEFAULT_ENV_ALLOWLIST;
    this.envAllowPrefixes = options.envAllowPrefixes || DEFAULT_ENV_ALLOW_PREFIXES;
    this.envDenyPattern = options.envDenyPattern || DEFAULT_ENV_DENY_PATTERN;
    this.allowedSecretEnv = options.allowedSecretEnv || [];
    this.clientInfo = {
      name: 'leon_codex',
      title: 'Leon Codex',
      version: '1.0.0',
      ...(options.clientInfo || {}),
    };
    this.capabilities = options.capabilities || {};
    this.requestTimeoutMs = positiveInt(options.requestTimeoutMs ?? 10_000, 'requestTimeoutMs');
    this.turnTimeoutMs = positiveInt(options.turnTimeoutMs ?? 600_000, 'turnTimeoutMs');
    this.spawnTimeoutMs = positiveInt(options.spawnTimeoutMs ?? 5_000, 'spawnTimeoutMs');
    this.shutdownTimeoutMs = positiveInt(options.shutdownTimeoutMs ?? 2_000, 'shutdownTimeoutMs');
    this.interruptTimeoutMs = positiveInt(options.interruptTimeoutMs ?? 2_000, 'interruptTimeoutMs');
    this.maxPendingRequests = positiveInt(options.maxPendingRequests ?? 128, 'maxPendingRequests');
    this.maxActiveTurns = positiveInt(options.maxActiveTurns ?? 16, 'maxActiveTurns');
    this.maxAgentItemsPerTurn = positiveInt(options.maxAgentItemsPerTurn ?? 64, 'maxAgentItemsPerTurn');
    this.maxAgentTextBytesPerTurn = positiveInt(options.maxAgentTextBytesPerTurn ?? 4_194_304, 'maxAgentTextBytesPerTurn');
    this.maxEarlyNotificationsPerTurn = positiveInt(options.maxEarlyNotificationsPerTurn ?? 128, 'maxEarlyNotificationsPerTurn');
    this.maxEarlyNotificationBytesPerTurn = positiveInt(options.maxEarlyNotificationBytesPerTurn ?? 1_048_576, 'maxEarlyNotificationBytesPerTurn');
    this.maxMessageBytes = positiveInt(options.maxMessageBytes ?? 1_048_576, 'maxMessageBytes');
    this.maxQueuedWrites = positiveInt(options.maxQueuedWrites ?? 256, 'maxQueuedWrites');
    this.maxQueuedWriteBytes = positiveInt(options.maxQueuedWriteBytes ?? 8_388_608, 'maxQueuedWriteBytes');
    this.serverRequestTimeoutMs = positiveInt(options.serverRequestTimeoutMs ?? 30_000, 'serverRequestTimeoutMs');
    this.maxServerRequests = positiveInt(options.maxServerRequests ?? 4, 'maxServerRequests');
    this.serverRequestHandler = typeof options.serverRequestHandler === 'function'
      ? options.serverRequestHandler
      : null;
    this.autoRestart = options.autoRestart !== false;
    this.restartDelayMs = positiveInt(options.restartDelayMs ?? 250, 'restartDelayMs');
    this.restartLimit = positiveInt(options.restartLimit ?? 3, 'restartLimit');
    this.restartWindowMs = positiveInt(options.restartWindowMs ?? 60_000, 'restartWindowMs');

    this._notifications = new BoundedRing(
      nonNegativeInt(options.maxBufferedNotifications ?? 256, 'maxBufferedNotifications'),
      nonNegativeInt(options.maxBufferedNotificationBytes ?? 1_048_576, 'maxBufferedNotificationBytes'),
    );
    this._stderr = new BoundedRing(
      nonNegativeInt(options.maxStderrLines ?? 200, 'maxStderrLines'),
      nonNegativeInt(options.maxStderrBytes ?? 262_144, 'maxStderrBytes'),
    );

    this._state = 'idle';
    this._generation = 0;
    this._nextId = 1;
    this._record = null;
    this._startPromise = null;
    this._retirePromise = null;
    this._retireShouldRestart = false;
    this._retireError = null;
    this._closePromise = null;
    this._restartTimer = null;
    this._crashTimes = [];
    this._pending = new Map();
    this._turnsByThread = new Map();
    this._turnsById = new Map();
    this._unsubscribingThreads = new Set();
    this._deletingThreads = new Set();
    this._serverRequestsInFlight = 0;
    this._closed = false;
  }

  async start() {
    if (this._closed) throw new CodexAdapterError('Codex app-server adapter is closed');
    if (this._state === 'ready' && this._record && isAlive(this._record.proc)) {
      return this._record.initializeResult;
    }
    if (this._startPromise) return this._startPromise;
    if (this._retirePromise) {
      await this._retirePromise;
      // Re-enter from the top: another waiter may already have started the
      // replacement, or close() may have won while retirement was pending.
      return this.start();
    }
    if (this._closed) throw new CodexAdapterError('Codex app-server adapter is closed');
    this._cancelScheduledRestart();

    const operation = this._spawnAndInitialize();
    this._startPromise = operation;
    try {
      return await operation;
    } finally {
      if (this._startPromise === operation) this._startPromise = null;
    }
  }

  async startThread(params = {}, options = {}) {
    await this.start();
    const result = await this._requestReady('thread/start', params, options.timeoutMs);
    return normalizeThreadResult(result, 'thread/start');
  }

  async resumeThread(threadId, params = {}, options = {}) {
    requireString(threadId, 'threadId');
    await this.start();
    const result = await this._requestReady('thread/resume', { ...params, threadId }, options.timeoutMs);
    return normalizeThreadResult(result, 'thread/resume');
  }

  async injectItems(threadId, items, options = {}) {
    requireString(threadId, 'threadId');
    if (!Array.isArray(items) || items.length === 0) {
      throw new TypeError('items must be a non-empty array');
    }
    await this.start();
    return this._requestReady('thread/inject_items', { threadId, items }, options.timeoutMs);
  }

  async unsubscribeThread(threadId, options = {}) {
    requireString(threadId, 'threadId');
    if (this._turnsByThread.has(threadId)) {
      throw new CodexAdapterError(`Cannot unsubscribe thread ${threadId} while it has an active local turn`);
    }
    if (this._unsubscribingThreads.has(threadId)) {
      throw new CodexAdapterError(`Thread ${threadId} is already being unsubscribed`);
    }
    this._unsubscribingThreads.add(threadId);
    try {
      await this.start();
      if (this._turnsByThread.has(threadId)) {
        throw new CodexAdapterError(`Cannot unsubscribe thread ${threadId} while it has an active local turn`);
      }
      return await this._requestReady('thread/unsubscribe', { threadId }, options.timeoutMs);
    } finally {
      this._unsubscribingThreads.delete(threadId);
    }
  }

  async deleteThread(threadId, options = {}) {
    requireString(threadId, 'threadId');
    let dispatched = false;
    let deleting = false;
    try {
      if (this._turnsByThread.has(threadId)) {
        throw new CodexAdapterError(`Cannot delete thread ${threadId} while it has an active local turn`);
      }
      if (this._deletingThreads.has(threadId) || this._unsubscribingThreads.has(threadId)) {
        throw new CodexAdapterError(`Thread ${threadId} is already being retired`);
      }
      this._deletingThreads.add(threadId);
      deleting = true;
      await this.start();
      if (this._turnsByThread.has(threadId)) {
        throw new CodexAdapterError(`Cannot delete thread ${threadId} while it has an active local turn`);
      }
      return await this._requestReady('thread/delete', { threadId }, options.timeoutMs, {
        onDispatch: () => { dispatched = true; },
      });
    } catch (error) {
      throw annotateDeleteFailure(error, dispatched);
    } finally {
      if (deleting) this._deletingThreads.delete(threadId);
    }
  }

  async startTurn(params, options = {}) {
    if (!params || typeof params !== 'object') throw new TypeError('params must be an object');
    const threadId = requireString(params.threadId, 'params.threadId');
    const input = normalizeInput(params.input);
    if (this._unsubscribingThreads.has(threadId) || this._deletingThreads.has(threadId)) {
      throw new CodexAdapterError(`Thread ${threadId} is being retired`);
    }
    await this.start();
    if (this._unsubscribingThreads.has(threadId) || this._deletingThreads.has(threadId)) {
      throw new CodexAdapterError(`Thread ${threadId} is being retired`);
    }
    if (this._turnsByThread.has(threadId)) {
      throw new CodexAdapterError(`Thread ${threadId} already has an active local turn`);
    }
    if (this._turnsByThread.size >= this.maxActiveTurns) {
      throw new CodexAdapterError(`Active turn limit (${this.maxActiveTurns}) reached`);
    }

    const record = this._requireReadyRecord();
    const handle = new TurnHandle(this, threadId, record.generation, {
      ...options,
      timeoutMs: positiveInt(options.timeoutMs ?? this.turnTimeoutMs, 'turn timeoutMs'),
      maxAgentItems: this.maxAgentItemsPerTurn,
      maxAgentTextBytes: this.maxAgentTextBytesPerTurn,
      maxEarlyNotifications: this.maxEarlyNotificationsPerTurn,
      maxEarlyNotificationBytes: this.maxEarlyNotificationBytesPerTurn,
    });
    this._turnsByThread.set(threadId, handle);

    try {
      const response = await this._requestRaw(record, 'turn/start', {
        ...params,
        threadId,
        input,
      }, positiveInt(options.requestTimeoutMs ?? this.requestTimeoutMs, 'turn requestTimeoutMs'));
      if (handle._settlementError) throw handle._settlementError;
      const turnId = response?.turn?.id || response?.turnId;
      handle._bindTurnId(turnId);
      handle.startResponse = response;
      handle._flushEarly();
      return handle;
    } catch (error) {
      const finalError = handle._settlementError || error;
      handle._fail(finalError);
      if (finalError instanceof RpcTimeoutError) void this._retireForFault(finalError);
      throw finalError;
    }
  }

  async runTurn(params, options = {}) {
    const handle = await this.startTurn(params, options);
    return handle.completion;
  }

  async steer(threadId, turnId, input, options = {}) {
    requireString(threadId, 'threadId');
    requireString(turnId, 'turnId');
    const record = this._requireReadyRecord(options.generation);
    return this._requestRaw(record, 'turn/steer', {
      threadId,
      turnId: undefined,
      expectedTurnId: turnId,
      input: normalizeInput(input),
    }, positiveInt(options.timeoutMs ?? this.requestTimeoutMs, 'steer timeoutMs'));
  }

  async interrupt(threadId, turnId, options = {}) {
    requireString(threadId, 'threadId');
    requireString(turnId, 'turnId');
    const record = this._requireReadyRecord(options.generation);
    return this._requestRaw(record, 'turn/interrupt', { threadId, turnId },
      positiveInt(options.timeoutMs ?? this.interruptTimeoutMs, 'interrupt timeoutMs'));
  }

  async restart(reason = 'manual restart') {
    if (this._closed) throw new CodexAdapterError('Codex app-server adapter is closed');
    this._crashTimes = [];
    await this.retire(reason);
    return this.start();
  }

  async retire(reason = 'retired') {
    this._cancelScheduledRestart();
    const error = reason instanceof Error ? reason : new ChildProcessError(String(reason));
    return this._retireCurrent(error, false);
  }

  close() {
    if (this._closePromise) return this._closePromise;
    this._closed = true;
    this._state = 'closed';
    this._cancelScheduledRestart();
    const error = new ChildProcessError('Codex app-server adapter closed');
    this._closePromise = (async () => {
      await this._retireCurrent(error, false);
      this._rejectAllPending(error);
      this._failAllTurns(error);
      this._state = 'closed';
    })();
    return this._closePromise;
  }

  getRecentNotifications() {
    return this._notifications.values();
  }

  stderrTail(lines = 20) {
    return this._stderr.values().slice(-Math.max(0, lines));
  }

  status() {
    return {
      state: this._state,
      generation: this._generation,
      pid: this._record?.proc.pid || null,
      pendingRequests: this._pending.size,
      activeTurns: this._turnsByThread.size,
      bufferedNotifications: this._notifications.items.length,
      droppedNotifications: this._notifications.dropped,
      stderrLines: this._stderr.items.length,
    };
  }

  async _spawnAndInitialize() {
    this._state = 'starting';
    const generation = ++this._generation;
    const env = buildChildEnv({
      source: this.envSource,
      overrides: this.envOverrides,
      allowlist: this.envAllowlist,
      allowPrefixes: this.envAllowPrefixes,
      denyPattern: this.envDenyPattern,
      allowedSecretEnv: this.allowedSecretEnv,
    });
    const proc = this.spawnImpl(this.command, this.args, {
      cwd: this.cwd,
      env,
      stdio: ['pipe', 'pipe', 'pipe'],
      detached: true,
      windowsHide: true,
    });
    const record = createChildRecord(proc, generation);
    this._record = record;
    this._attachChild(record);

    try {
      await this._waitForSpawn(record);
      const initializeResult = await this._requestRaw(record, 'initialize', {
        clientInfo: this.clientInfo,
        capabilities: this.capabilities,
      }, this.requestTimeoutMs);
      await this._notifyRaw(record, 'initialized', {});
      if (this._record !== record || !isAlive(proc)) {
        throw new ChildProcessError('Codex app-server exited during initialization', {
          stderr: this.stderrTail(),
        });
      }
      record.initializeResult = initializeResult;
      record.readyAt = Date.now();
      this._state = 'ready';
      safeEmit(this, 'ready', { generation, pid: proc.pid, initializeResult });
      return initializeResult;
    } catch (error) {
      const wrapped = error instanceof Error ? error : new ChildProcessError(String(error));
      await this._retireRecord(record, wrapped);
      throw wrapped;
    }
  }

  _attachChild(record) {
    const { proc } = record;
    proc.stdout?.on('data', (chunk) => this._consumeStdout(record, chunk));
    proc.stderr?.on('data', (chunk) => this._consumeStderr(record, chunk));
    proc.stdin?.on('error', (error) => {
      safeEmit(this, 'writeError', error);
      if (this._record === record && !record.cleaned && !record.retiring) {
        void this._retireForFault(this._childDiedError(record, `Codex app-server stdin failed: ${error.message}`, error));
      }
    });
    proc.stdout?.on('error', (error) => {
      if (this._record === record && !record.cleaned && !record.retiring) {
        void this._retireForFault(this._childDiedError(record, `Codex app-server stdout failed: ${error.message}`, error));
      }
    });
    proc.stderr?.on('error', (error) => safeEmit(this, 'childStderrError', error));
    proc.once('spawn', () => {
      record.spawned = true;
      record.resolveSpawn();
    });
    proc.once('error', (error) => {
      if (!record.spawned) {
        record.rejectSpawn(new ChildProcessError(`Unable to spawn ${this.command}: ${error.message}`, { cause: error }));
        this._finishRecord(record, null, null, error);
      } else {
        safeEmit(this, 'childError', error);
      }
    });
    proc.once('exit', (code, signal) => this._finishRecord(record, code, signal));
  }

  async _waitForSpawn(record) {
    let timer;
    try {
      await Promise.race([
        record.spawnPromise,
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(new ChildProcessError(`Spawning ${this.command} timed out`)), this.spawnTimeoutMs);
        }),
      ]);
    } finally {
      clearTimeout(timer);
    }
  }

  _consumeStdout(record, chunk) {
    if (record.cleaned) return;
    const incoming = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    let data = record.stdoutBuffer.length
      ? Buffer.concat([record.stdoutBuffer, incoming])
      : incoming;
    let offset = 0;

    for (;;) {
      const newline = data.indexOf(0x0a, offset);
      if (newline === -1) break;
      let line = data.subarray(offset, newline);
      offset = newline + 1;
      if (line.length && line.at(-1) === 0x0d) line = line.subarray(0, -1);
      if (!line.length) continue;
      if (line.length > this.maxMessageBytes) {
        this._protocolFault(record, new ProtocolError(`Codex message exceeded ${this.maxMessageBytes} bytes`));
        return;
      }
      let message;
      try {
        message = JSON.parse(line.toString('utf8'));
      } catch (error) {
        this._protocolFault(record, new ProtocolError(`Invalid JSON from Codex app-server: ${error.message}`));
        return;
      }
      if (!message || typeof message !== 'object' || Array.isArray(message)) {
        this._protocolFault(record, new ProtocolError('Codex app-server emitted a non-object message'));
        return;
      }
      this._dispatch(record, message, line.length);
    }

    data = data.subarray(offset);
    if (data.length > this.maxMessageBytes) {
      this._protocolFault(record, new ProtocolError(`Codex message exceeded ${this.maxMessageBytes} bytes`));
      return;
    }
    record.stdoutBuffer = Buffer.from(data);
  }

  _consumeStderr(record, chunk) {
    if (record.cleaned) return;
    record.stderrBuffer += Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk);
    const lines = record.stderrBuffer.split(/\r?\n/);
    record.stderrBuffer = lines.pop() || '';
    for (const line of lines) {
      if (line) this._stderr.push(line, Buffer.byteLength(line));
    }
    if (Buffer.byteLength(record.stderrBuffer) > this.maxMessageBytes) {
      this._stderr.push(record.stderrBuffer.slice(-4096), 4096);
      record.stderrBuffer = '';
    }
  }

  _dispatch(record, message, bytes) {
    if (this._record !== record || record.cleaned) return;
    const hasId = Object.prototype.hasOwnProperty.call(message, 'id');
    if (hasId && (Object.prototype.hasOwnProperty.call(message, 'result')
      || Object.prototype.hasOwnProperty.call(message, 'error'))) {
      const key = rpcIdKey(message.id);
      if (!key) return;
      const pending = this._pending.get(key);
      if (!pending || pending.generation !== record.generation) return;
      this._pending.delete(key);
      clearTimeout(pending.timer);
      if (message.error) pending.reject(new RpcError(pending.method, message.error));
      else pending.resolve(message.result ?? {});
      return;
    }

    if (hasId && typeof message.method === 'string') {
      this._handleServerRequest(record, message);
      return;
    }

    if (typeof message.method === 'string') {
      this._notifications.push(message, bytes);
      this._routeTurnNotification(record, message);
      safeEmit(this, 'notification', message);
      return;
    }

    this._protocolFault(record, new ProtocolError('Unrecognized Codex app-server message shape'));
  }

  _routeTurnNotification(record, notification) {
    const scope = notificationScope(notification);
    if (!scope.threadId || !scope.turnId) return;
    let handle = scope.turnId ? this._turnsById.get(turnKey(scope.threadId, scope.turnId)) : null;
    handle ||= this._turnsByThread.get(scope.threadId);
    if (!handle || handle.generation !== record.generation) return;
    try {
      if (!handle.turnId && scope.turnId) {
        handle._queueEarly(notification);
        return;
      }
      if (scope.turnId && handle.turnId !== scope.turnId) return;
      handle._consume(notification);
    } catch (error) {
      handle._fail(error);
      void this._retireForFault(error);
    }
  }

  _handleServerRequest(record, message) {
    safeEmit(this, 'serverRequest', message);
    if (!this.serverRequestHandler) {
      void this._respondError(record, message.id, -32601, `Client does not implement ${message.method}`);
      return;
    }
    if (this._serverRequestsInFlight >= this.maxServerRequests) {
      void this._respondError(record, message.id, -32001, 'Client server-request queue is full');
      return;
    }

    this._serverRequestsInFlight += 1;
    const handlerPromise = Promise.resolve().then(() => this.serverRequestHandler({
        id: message.id,
        method: message.method,
        params: message.params || {},
      }));
    // A timed-out handler still owns its bounded slot until it actually
    // settles; otherwise a sequence of hung handlers would grow unbounded.
    handlerPromise.finally(() => {
      this._serverRequestsInFlight -= 1;
    }).catch(() => {});
    void withTimeout(
      handlerPromise,
      this.serverRequestTimeoutMs,
      () => new RpcTimeoutError(`server request ${message.method}`, this.serverRequestTimeoutMs),
    ).then(
      (result) => this._respondResult(record, message.id, result ?? {}),
      (error) => this._respondError(record, message.id, -32000, error?.message || 'Client handler failed'),
    );
  }

  async _requestReady(method, params, timeoutMs, lifecycle = {}) {
    const record = this._requireReadyRecord();
    try {
      return await this._requestRaw(record, method, params,
        positiveInt(timeoutMs ?? this.requestTimeoutMs, `${method} timeoutMs`), lifecycle);
    } catch (error) {
      if (error instanceof RpcTimeoutError) void this._retireForFault(error);
      throw error;
    }
  }

  _requestRaw(record, method, params, timeoutMs, lifecycle = {}) {
    if (this._pending.size >= this.maxPendingRequests) {
      return Promise.reject(new CodexAdapterError(`Pending RPC limit (${this.maxPendingRequests}) reached`));
    }
    if (record.cleaned || !isAlive(record.proc)) {
      return Promise.reject(this._childDiedError(record, 'Codex app-server is not running'));
    }

    const id = this._nextId++;
    const key = rpcIdKey(id);
    let resolvePromise;
    let rejectPromise;
    const promise = new Promise((resolve, reject) => {
      resolvePromise = resolve;
      rejectPromise = reject;
    });
    const timer = setTimeout(() => {
      const pending = this._pending.get(key);
      if (!pending || pending.generation !== record.generation) return;
      this._pending.delete(key);
      rejectPromise(new RpcTimeoutError(method, timeoutMs));
    }, timeoutMs);
    timer.unref?.();
    this._pending.set(key, {
      generation: record.generation,
      method,
      timer,
      resolve: resolvePromise,
      reject: rejectPromise,
    });

    this._write(record, { id, method, params: params || {} }, {
      valid: () => {
        const pending = this._pending.get(key);
        return pending?.generation === record.generation;
      },
      onDispatch: lifecycle.onDispatch,
    }).catch((error) => {
      const pending = this._pending.get(key);
      if (!pending || pending.generation !== record.generation) return;
      this._pending.delete(key);
      clearTimeout(timer);
      rejectPromise(error);
    });
    return promise;
  }

  _notifyRaw(record, method, params) {
    return this._write(record, { method, params: params || {} });
  }

  _respondResult(record, id, result) {
    if (record.cleaned) return Promise.resolve();
    return this._write(record, { id, result }).catch((error) => safeEmit(this, 'writeError', error));
  }

  _respondError(record, id, code, message) {
    if (record.cleaned) return Promise.resolve();
    return this._write(record, { id, error: { code, message } }).catch((error) => safeEmit(this, 'writeError', error));
  }

  _write(record, message, options = {}) {
    let payload;
    try {
      payload = `${JSON.stringify(message)}\n`;
    } catch (error) {
      return Promise.reject(new ProtocolError(`Unable to serialize Codex request: ${error.message}`));
    }
    const payloadBytes = Buffer.byteLength(payload);
    if (payloadBytes > this.maxMessageBytes) {
      return Promise.reject(new ProtocolError(`Codex request exceeded ${this.maxMessageBytes} bytes`));
    }
    if (record.queuedWrites >= this.maxQueuedWrites
      || record.queuedWriteBytes + payloadBytes > this.maxQueuedWriteBytes) {
      return Promise.reject(new CodexAdapterError('Codex app-server write queue is full'));
    }
    record.queuedWrites += 1;
    record.queuedWriteBytes += payloadBytes;
    const operation = record.writeChain.catch(() => {}).then(() => new Promise((resolve, reject) => {
      if (record.cleaned || this._record !== record || !record.proc.stdin || record.proc.stdin.destroyed) {
        reject(this._childDiedError(record, 'Codex app-server stdin is unavailable'));
        return;
      }
      if (options.valid && !options.valid()) {
        reject(new CodexAdapterError('Codex request expired before it was written'));
        return;
      }
      let settled = false;
      const done = (error) => {
        if (settled) return;
        settled = true;
        if (error) reject(this._childDiedError(record, `Codex app-server write failed: ${error.message}`, error));
        else resolve();
      };
      try {
        if (typeof options.onDispatch === 'function') options.onDispatch();
        record.proc.stdin.write(payload, done);
      } catch (error) {
        done(error);
      }
    })).finally(() => {
      record.queuedWrites -= 1;
      record.queuedWriteBytes -= payloadBytes;
    });
    record.writeChain = operation;
    return operation;
  }

  _requireReadyRecord(generation) {
    const record = this._record;
    if (this._state !== 'ready' || !record || !isAlive(record.proc)) {
      throw new ChildProcessError('Codex app-server is not ready', { stderr: this.stderrTail() });
    }
    if (generation != null && generation !== record.generation) {
      throw new ChildProcessError('Codex app-server generation changed; the turn was retired');
    }
    return record;
  }

  _indexTurn(handle) {
    this._turnsById.set(turnKey(handle.threadId, handle.turnId), handle);
  }

  _unindexTurn(handle) {
    if (this._turnsByThread.get(handle.threadId) === handle) this._turnsByThread.delete(handle.threadId);
    if (handle.turnId && this._turnsById.get(turnKey(handle.threadId, handle.turnId)) === handle) {
      this._turnsById.delete(turnKey(handle.threadId, handle.turnId));
    }
  }

  _handleTurnTimeout(handle, error) {
    void this._retireCurrent(error, this.autoRestart, async (record) => {
      if (record.generation === handle.generation && handle.turnId && isAlive(record.proc)) {
        try {
          await this._requestRaw(record, 'turn/interrupt', {
            threadId: handle.threadId,
            turnId: handle.turnId,
          }, this.interruptTimeoutMs);
        } catch {
          // Process-group retirement below is the hard stop.
        }
      }
    });
  }

  _protocolFault(record, error) {
    if (record.cleaned || record.faulted) return;
    record.faulted = true;
    safeEmit(this, 'protocolError', error);
    void this._retireForFault(error);
  }

  async _retireForFault(error) {
    await this._retireCurrent(error, this.autoRestart);
  }

  async _retireCurrent(error, restart, beforeRetire = null) {
    if (this._retirePromise) {
      if (!restart) this._retireShouldRestart = false;
      return this._retirePromise;
    }
    this._retireShouldRestart = Boolean(restart);
    this._retireError = error;
    const record = this._record;
    if (!record) {
      if (!this._closed) this._state = 'idle';
      if (this._retireShouldRestart) this._scheduleRestart(error);
      this._retireShouldRestart = false;
      this._retireError = null;
      return;
    }
    // Fence the generation before any interrupt/kill wait so callers cannot
    // start work that is guaranteed to be killed by this retirement.
    if (!this._closed) this._state = 'retiring';
    record.retiring = true;
    record.expected = true;
    record.retireError ||= error;
    this._rejectGeneration(record.generation, error);
    this._failGenerationTurns(record.generation, error);
    const operation = (async () => {
      if (beforeRetire) await beforeRetire(record);
      await this._retireRecord(record, error);
      if (this._retireShouldRestart && !this._closed) this._scheduleRestart(this._retireError || error);
    })();
    this._retirePromise = operation;
    try {
      await operation;
    } finally {
      if (this._retirePromise === operation) {
        this._retirePromise = null;
        this._retireShouldRestart = false;
        this._retireError = null;
      }
    }
  }

  _retireRecord(record, error) {
    if (record.retirePromise) return record.retirePromise;
    record.retirePromise = this._performRetireRecord(record, error);
    return record.retirePromise;
  }

  async _performRetireRecord(record, error) {
    record.retiring = true;
    record.expected = true;
    record.retireError = error;
    if (!this._closed) this._state = 'retiring';
    this._rejectGeneration(record.generation, error);
    this._failGenerationTurns(record.generation, error);

    try {
      record.proc.stdin?.end();
    } catch {}
    this._signalGroup(record, 'SIGTERM');
    await settleWithin(record.exitPromise, this.shutdownTimeoutMs);
    const groupGone = await waitForProcessGroupExit(record.pgid, this.shutdownTimeoutMs, this.killImpl);
    if (!groupGone) {
      this._signalGroup(record, 'SIGKILL');
      await Promise.all([
        settleWithin(record.exitPromise, 1_000),
        waitForProcessGroupExit(record.pgid, 1_000, this.killImpl),
      ]);
    }
    this._cleanupRecord(record, error);
  }

  _finishRecord(record, code, signal, cause = null) {
    if (record.exitResolved) return;
    record.exitResolved = true;
    record.exitCode = code;
    record.exitSignal = signal;
    record.resolveExit({ code, signal });

    const error = record.retireError || new ChildProcessError(
      `Codex app-server exited unexpectedly (code=${code ?? 'null'}, signal=${signal || 'none'})`,
      { code, signal, cause, stderr: this.stderrTail() },
    );
    const unexpected = !record.expected && !this._closed;
    this._cleanupRecord(record, error);
    if (unexpected) {
      // The leader may have died while grandchildren remain. Since the child
      // was detached, -pid targets only its process group.
      this._signalGroup(record, 'SIGKILL');
      safeEmit(this, 'childExit', { generation: record.generation, code, signal, error });
      if (this.autoRestart) this._scheduleRestart(error);
    }
  }

  _cleanupRecord(record, error) {
    if (record.cleaned) return;
    record.cleaned = true;
    if (record.stderrBuffer) this._stderr.push(record.stderrBuffer, Buffer.byteLength(record.stderrBuffer));
    this._rejectGeneration(record.generation, error);
    this._failGenerationTurns(record.generation, error);
    if (this._record === record) {
      this._record = null;
      if (!this._closed) this._state = 'idle';
    }
  }

  _signalGroup(record, signal) {
    const pid = record.proc.pid;
    if (!Number.isInteger(pid) || pid <= 0) return false;
    if (process.platform !== 'win32') {
      try {
        this.killImpl(-pid, signal);
        return true;
      } catch (error) {
        if (error?.code !== 'ESRCH') safeEmit(this, 'killError', error);
      }
    }
    try {
      return record.proc.kill(signal);
    } catch (error) {
      if (error?.code !== 'ESRCH') safeEmit(this, 'killError', error);
      return false;
    }
  }

  _scheduleRestart(error) {
    if (this._closed || !this.autoRestart || this._restartTimer) return;
    const now = Date.now();
    this._crashTimes = this._crashTimes.filter((time) => now - time < this.restartWindowMs);
    this._crashTimes.push(now);
    if (this._crashTimes.length > this.restartLimit) {
      safeEmit(this, 'retired', { error, crashes: this._crashTimes.length });
      return;
    }
    const delayMs = Math.min(5_000, this.restartDelayMs * (2 ** (this._crashTimes.length - 1)));
    safeEmit(this, 'restartScheduled', { delayMs, error });
    this._restartTimer = setTimeout(() => {
      this._restartTimer = null;
      this.start().catch((restartError) => {
        safeEmit(this, 'restartFailed', restartError);
        this._scheduleRestart(restartError);
      });
    }, delayMs);
    this._restartTimer.unref?.();
  }

  _cancelScheduledRestart() {
    if (this._restartTimer) clearTimeout(this._restartTimer);
    this._restartTimer = null;
  }

  _rejectGeneration(generation, error) {
    for (const [key, pending] of this._pending) {
      if (pending.generation !== generation) continue;
      this._pending.delete(key);
      clearTimeout(pending.timer);
      pending.reject(error);
    }
  }

  _rejectAllPending(error) {
    for (const [key, pending] of this._pending) {
      this._pending.delete(key);
      clearTimeout(pending.timer);
      pending.reject(error);
    }
  }

  _failGenerationTurns(generation, error) {
    for (const handle of [...this._turnsByThread.values()]) {
      if (handle.generation === generation) handle._fail(error);
    }
  }

  _failAllTurns(error) {
    for (const handle of [...this._turnsByThread.values()]) handle._fail(error);
  }

  _childDiedError(record, message, cause = null) {
    return new ChildProcessError(message, {
      code: record.exitCode,
      signal: record.exitSignal,
      cause,
      stderr: this.stderrTail(),
    });
  }
}

function annotateDeleteFailure(value, dispatched) {
  const error = value instanceof Error
    ? value
    : new CodexAdapterError(String(value || 'thread/delete failed'));
  try {
    if (error.method === undefined) error.method = 'thread/delete';
    if (!Object.prototype.hasOwnProperty.call(error, 'code')) error.code = null;
    if (!Object.prototype.hasOwnProperty.call(error, 'data')) error.data = undefined;
    if (!Object.prototype.hasOwnProperty.call(error, 'rpcMessage')) error.rpcMessage = null;
    error.dispatched = Boolean(dispatched || error.dispatched === true);
  } catch {}
  return error;
}

function buildChildEnv({
  source = process.env,
  overrides = {},
  allowlist = DEFAULT_ENV_ALLOWLIST,
  allowPrefixes = DEFAULT_ENV_ALLOW_PREFIXES,
  denyPattern = DEFAULT_ENV_DENY_PATTERN,
  allowedSecretEnv = [],
} = {}) {
  const allowed = new Set(Array.from(allowlist, String));
  const allowedSecrets = new Set(Array.from(allowedSecretEnv, String));
  const prefixes = Array.from(allowPrefixes, String);
  const candidates = { ...source, ...overrides };
  const result = Object.create(null);
  for (const [name, value] of Object.entries(candidates)) {
    if (value == null) continue;
    if (!allowedSecrets.has(name) && !allowed.has(name) && !prefixes.some((prefix) => name.startsWith(prefix))) continue;
    denyPattern.lastIndex = 0;
    if (!allowedSecrets.has(name) && denyPattern.test(name)) continue;
    result[name] = String(value);
  }
  return result;
}

function createChildRecord(proc, generation) {
  let resolveSpawn;
  let rejectSpawn;
  let resolveExit;
  const spawnPromise = new Promise((resolve, reject) => {
    resolveSpawn = resolve;
    rejectSpawn = reject;
  });
  // Prevent the spawn promise from surfacing as unhandled if the process emits
  // error and exit in the same tick.
  spawnPromise.catch(() => {});
  const exitPromise = new Promise((resolve) => { resolveExit = resolve; });
  return {
    proc,
    pgid: Number.isInteger(proc.pid) && proc.pid > 0 ? proc.pid : null,
    generation,
    spawned: false,
    expected: false,
    retiring: false,
    cleaned: false,
    faulted: false,
    exitResolved: false,
    exitCode: null,
    exitSignal: null,
    retireError: null,
    initializeResult: null,
    readyAt: null,
    stdoutBuffer: Buffer.alloc(0),
    stderrBuffer: '',
    writeChain: Promise.resolve(),
    queuedWrites: 0,
    queuedWriteBytes: 0,
    retirePromise: null,
    spawnPromise,
    resolveSpawn,
    rejectSpawn,
    exitPromise,
    resolveExit,
  };
}

function normalizeThreadResult(result, method) {
  const threadId = result?.thread?.id
    || result?.thread?.sessionId
    || result?.threadId
    || result?.sessionId;
  if (!threadId || typeof threadId !== 'string') {
    throw new ProtocolError(`${method} returned no thread id`);
  }
  return { ...result, threadId };
}

function normalizeInput(input) {
  if (typeof input === 'string') {
    if (!input.trim()) throw new TypeError('turn input must not be empty');
    return [{ type: 'text', text: input }];
  }
  if (!Array.isArray(input) || input.length === 0) {
    throw new TypeError('turn input must be a string or a non-empty array');
  }
  return input;
}

function notificationScope(notification) {
  const params = notification.params || {};
  return {
    threadId: typeof params.threadId === 'string' ? params.threadId : null,
    turnId: typeof params.turnId === 'string'
      ? params.turnId
      : (typeof params.turn?.id === 'string' ? params.turn.id : null),
  };
}

function emptyAgentItem() {
  return { phase: null, text: '', emitted: '' };
}

function turnKey(threadId, turnId) {
  return `${threadId}\u0000${turnId}`;
}

function rpcIdKey(id) {
  if (typeof id === 'number' && Number.isFinite(id)) return `n:${id}`;
  if (typeof id === 'string') return `s:${id}`;
  return null;
}

function isAlive(proc) {
  return proc && proc.exitCode == null && proc.signalCode == null;
}

function safeCallback(adapter, callback, ...args) {
  if (!callback) return;
  try {
    const result = callback(...args);
    if (result && typeof result.then === 'function') {
      Promise.resolve(result).catch((error) => safeEmit(adapter, 'callbackError', error));
    }
  } catch (error) {
    safeEmit(adapter, 'callbackError', error);
  }
}

function safeEmit(emitter, eventName, ...args) {
  const listeners = emitter.rawListeners(eventName);
  for (const listener of listeners) {
    try {
      const result = listener.apply(emitter, args);
      if (result && typeof result.then === 'function') {
        Promise.resolve(result).catch((error) => {
          if (eventName !== 'listenerError') safeEmit(emitter, 'listenerError', error, eventName);
        });
      }
    } catch (error) {
      if (eventName !== 'listenerError') safeEmit(emitter, 'listenerError', error, eventName);
    }
  }
}

function estimateBytes(value) {
  try {
    return Buffer.byteLength(JSON.stringify(value));
  } catch {
    return 0;
  }
}

function requireString(value, name) {
  if (typeof value !== 'string' || value.length === 0) throw new TypeError(`${name} must be a non-empty string`);
  return value;
}

function positiveInt(value, name) {
  if (!Number.isSafeInteger(value) || value <= 0) throw new TypeError(`${name} must be a positive integer`);
  return value;
}

function nonNegativeInt(value, name) {
  if (!Number.isSafeInteger(value) || value < 0) throw new TypeError(`${name} must be a non-negative integer`);
  return value;
}

function settleWithin(promise, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(false);
      }
    }, timeoutMs);
    promise.then(() => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(true);
    });
  });
}

async function waitForProcessGroupExit(pgid, timeoutMs, killImpl) {
  if (process.platform === 'win32' || !Number.isInteger(pgid) || pgid <= 0) return true;
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!processGroupExists(pgid, killImpl)) return true;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  return !processGroupExists(pgid, killImpl);
}

function processGroupExists(pgid, killImpl) {
  try {
    killImpl(-pgid, 0);
    return true;
  } catch (error) {
    return error?.code !== 'ESRCH';
  }
}

function withTimeout(promise, timeoutMs, errorFactory) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(errorFactory()), timeoutMs);
      timer.unref?.();
    }),
  ]).finally(() => clearTimeout(timer));
}

module.exports = {
  CodexAppServerAdapter,
  TurnHandle,
  CodexAdapterError,
  RpcError,
  RpcTimeoutError,
  TurnTimeoutError,
  ProtocolError,
  ChildProcessError,
  buildChildEnv,
  DEFAULT_ENV_ALLOWLIST,
  DEFAULT_ENV_ALLOW_PREFIXES,
  DEFAULT_ENV_DENY_PATTERN,
};
