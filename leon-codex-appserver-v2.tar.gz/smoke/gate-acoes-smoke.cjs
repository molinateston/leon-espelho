#!/usr/bin/env node
// SMOKE DO GATE DE INTENÇÃO (emagrecimento 10/09) — prova que os blocos de AÇÃO RARA (criar/apagar
// sala, config) só entram no dossiê quando a fala do dono pede, e que a funcionalidade NÃO some
// (fala que pede a ação => bloco presente). Kill-switch LEON_GATE_ACOES=0 traz tudo de volta.
// Sai 0 se todos os casos passam.
process.env.LEON_BRIDGE_TEST_MODE = '1';
const os = require('os'), fs = require('fs'), path = require('path');
const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'gate-acoes-smoke-'));
process.env.WORK_DIR = casa;
const envP = path.join(casa, '.env');
fs.writeFileSync(envP, 'TELEGRAM_BOT_TOKEN=000:fake\nOWNER_CHAT_ID=' + String(1) + '\n'); fs.chmodSync(envP, 0o600);

const B = require(path.join(__dirname, '..', 'bridge.cjs'));
const cfg = { label: 'Geral', persona: 'principal' };
const sys = '# doutrina fake\n'.repeat(10);
const D = (fala) => String(B.codexDossier(sys, cfg, fala) || '');

let falhas = 0;
function ok(nome, cond) { console.log(`  ${cond ? '✓' : '✗'} ${nome}`); if (!cond) falhas++; }

console.log('GATE DE INTENÇÃO — blocos raros só quando a fala pede:');

// bate-papo: nenhum bloco raro
const chat = D('Tá, vamos pensar juntos na estratégia do lançamento, o que você acha?');
ok('bate-papo NÃO traz bloco AÇÃO DE SALAS', !/# AÇÃO DE SALAS/.test(chat));
ok('bate-papo NÃO traz bloco APAGAR SALA', !/# AÇÃO DE APAGAR SALA/.test(chat));
ok('bate-papo NÃO traz bloco CONFIGURAR AMBIENTE', !/CONFIGURAR O AMBIENTE/.test(chat));

// fala que pede a ação: o bloco correspondente ENTRA (funcionalidade preservada)
ok('"cria as salas X e Y" TRAZ o bloco AÇÃO DE SALAS', /# AÇÃO DE SALAS/.test(D('cria as salas Financeiro e Clientes')));
ok('"apaga a sala X" TRAZ o bloco APAGAR SALA', /# AÇÃO DE APAGAR SALA/.test(D('apaga a sala Achadinhos')));
ok('"só responde quando me marcarem" TRAZ o bloco CONFIG', /CONFIGURAR O AMBIENTE/.test(D('aqui você só responde quando me marcarem')));

// o dossiê de bate-papo é MENOR que o de ação (economia real)
ok('dossiê de bate-papo é menor que o de criar-sala', D('oi, tudo bem?').length < D('cria as salas A e B').length);

// kill-switch: gate desligado traz TODOS os blocos mesmo em bate-papo
process.env.LEON_GATE_ACOES = '0';
const off = D('oi');
ok('LEON_GATE_ACOES=0 traz o bloco SALAS de volta (kill-switch)', /# AÇÃO DE SALAS/.test(off));
delete process.env.LEON_GATE_ACOES;

try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}
console.log(falhas === 0 ? `\n✅ gate de ações: ${8 - falhas}/8 OK` : `\n🔴 ${falhas} falha(s)`);
process.exit(falhas === 0 ? 0 : 1);
