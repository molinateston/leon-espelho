#!/usr/bin/env node
// SMOKE: TETO DA MENSAGEM DO DONO (cura 10/09, o LEON morreu) — mensagem gigante (colar 60-72KB)
// afogava o motor (somava com o dossiê e estourava o timeout de 600s -> turno morto, fallback caindo).
// Agora fala acima do teto vira arquivo + o motor recebe começo + ponteiro. Testa a lógica de corte.
process.env.LEON_BRIDGE_TEST_MODE = '1';
const os = require('os'), fs = require('fs'), path = require('path');
const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'teto-msg-smoke-'));
process.env.WORK_DIR = casa;
process.env.LEON_TMPDIR = path.join(casa, 'tmp');
const envP = path.join(casa, '.env');
fs.writeFileSync(envP, 'TELEGRAM_BOT_TOKEN=000:fake\nOWNER_CHAT_ID=' + String(1) + '\n'); fs.chmodSync(envP, 0o600);

let falhas = 0;
function ok(n, c) { console.log(`  ${c ? '✓' : '✗'} ${n}`); if (!c) falhas++; }

// a lógica do teto (espelha o call-site em ask()): fala > MAX vira arquivo + ponteiro
const _MSG_MAX = 24000;
function aplicaTeto(text) {
  if (typeof text !== 'string' || text.length <= _MSG_MAX) return { text, cortou: false };
  const dir = path.join(process.env.LEON_TMPDIR, 'mensagens-grandes');
  fs.mkdirSync(dir, { recursive: true });
  const arq = path.join(dir, `msg-${Date.now()}.txt`);
  fs.writeFileSync(arq, text);
  const corte = text.slice(0, _MSG_MAX);
  return { text: `${corte}\n\n[… cortada, inteiro em ${arq}]`, cortou: true, arq, original: text.length };
}

console.log('TETO DA MENSAGEM DO DONO:');
// mensagem normal: passa intacta
const normal = aplicaTeto('faz um carrossel de 10 headlines sobre precificação');
ok('mensagem normal passa intacta (não corta)', normal.cortou === false);

// mensagem gigante (72KB, o que matou): corta
const gigante = aplicaTeto('x'.repeat(72000));
ok('mensagem de 72KB é cortada', gigante.cortou === true);
ok('o que vai pro motor fica <= 24.5KB (não afoga)', gigante.text.length <= 24500);
ok('o texto INTEIRO foi salvo em arquivo (dono não perde nada)', fs.existsSync(gigante.arq) && fs.readFileSync(gigante.arq, 'utf8').length === 72000);
ok('o motor recebe o ponteiro pro arquivo', /inteiro em .*msg-\d+\.txt/.test(gigante.text));

// borda: exatamente no teto passa
const borda = aplicaTeto('y'.repeat(24000));
ok('mensagem no limite exato passa intacta', borda.cortou === false);

try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}
console.log(falhas === 0 ? `\n✅ teto mensagem: ${6 - falhas}/6 OK` : `\n🔴 ${falhas} falha(s)`);
process.exit(falhas === 0 ? 0 : 1);
