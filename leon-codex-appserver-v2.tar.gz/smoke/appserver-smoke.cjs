#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { randomBytes } = require('node:crypto');

const { createMotor } = require('../lib-motores/codex-appserver.cjs');

const runtime = path.resolve(process.env.LEON_RUNTIME_DIR || path.join(__dirname, '..'));
const smokeDir = path.resolve(process.env.LEON_SMOKE_DIR || path.join(os.homedir(), 'trabalho', '.leon-appserver-smoke'));
const model = process.env.CODEX_MODEL || 'gpt-5.6-sol';
const effort = process.env.CODEX_SMOKE_EFFORT || 'low';
const nonce = `L${randomBytes(5).toString('hex').toUpperCase()}`;
fs.mkdirSync(smokeDir, { recursive: true, mode: 0o700 });

const motor = createMotor({
  command: process.env.CODEX_BIN || undefined,
  processCwd: runtime,
  envSource: process.env,
  approvalPolicy: 'never',
  permissionProfile: 'leon',
  requestTimeoutMs: 15000,
  turnTimeoutMs: Number(process.env.CODEX_SMOKE_TIMEOUT_SEG || 240) * 1000,
  maxTrackedThreads: 2,
  version: '2.0.0-smoke',
});
let smokeThreadId = null;

(async () => {
  try {
    const first = await motor.responder({
      dossie: 'Você valida o runtime do LEON. Siga literalmente o formato de resposta solicitado e não use ferramentas.',
      fala: `Guarde o código ${nonce} nesta conversa. Responda somente PRIMEIRO_OK.`,
      modelo: model,
      effort,
      cwd: smokeDir,
      diretorios: [smokeDir],
      timeoutMs: Number(process.env.CODEX_SMOKE_TIMEOUT_SEG || 240) * 1000,
    });
    if (first.erro || first.texto.trim() !== 'PRIMEIRO_OK.' && first.texto.trim() !== 'PRIMEIRO_OK') {
      throw new Error(`primeiro turno inválido: ${String(first.erro || first.texto).slice(-240)}`);
    }
    smokeThreadId = first.sessaoId;
    const second = await motor.responder({
      sessaoId: first.sessaoId,
      dossie: 'Você valida o runtime do LEON. Siga literalmente o formato de resposta solicitado e não use ferramentas.',
      fala: `Qual foi o código guardado? Responda somente SEGUNDO_OK:${nonce}`,
      modelo: model,
      effort,
      cwd: smokeDir,
      diretorios: [smokeDir],
      timeoutMs: Number(process.env.CODEX_SMOKE_TIMEOUT_SEG || 240) * 1000,
    });
    if (second.erro || second.texto.trim() !== `SEGUNDO_OK:${nonce}`) {
      throw new Error(`retomada inválida: ${String(second.erro || second.texto).slice(-240)}`);
    }
    if (!smokeThreadId || !(await motor.resetar(smokeThreadId))) {
      throw new Error('o smoke não conseguiu apagar a thread temporária');
    }
    smokeThreadId = null;
    process.stdout.write(`${JSON.stringify({ ok: true, persistentSession: true, model })}\n`);
  } finally {
    if (smokeThreadId) {
      try { await motor.resetar(smokeThreadId); } catch {}
    }
    await motor.encerrar();
  }
})().catch((error) => {
  console.error(String(error && error.message || error).replace(/[A-Za-z0-9_-]{32,}/g, '<redacted>'));
  process.exitCode = 1;
});
