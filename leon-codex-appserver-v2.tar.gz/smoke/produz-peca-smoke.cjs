#!/usr/bin/env node
// SMOKE: PRODUZIR PEÇA PENSA (cura 10/09) — pedido de FAZER peça sobe pra high (pensa o melhor
// caminho, a lei dos 30s de orquestração); ajuste cirúrgico segue rápido. Prova a distinção real.
process.env.LEON_BRIDGE_TEST_MODE = '1';
const os = require('os'), fs = require('fs'), path = require('path');
const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'produz-smoke-'));
process.env.WORK_DIR = casa;
const envP = path.join(casa, '.env');
fs.writeFileSync(envP, 'TELEGRAM_BOT_TOKEN=000:fake\nOWNER_CHAT_ID=' + String(1) + '\n'); fs.chmodSync(envP, 0o600);
const B = require(path.join(__dirname, '..', 'bridge.cjs'));

let falhas = 0;
function ok(n, c) { console.log(`  ${c ? '✓' : '✗'} ${n}`); if (!c) falhas++; }

console.log('PRODUZIR PEÇA PENSA (high) vs AJUSTE (rápido):');
// fazer peça = pensa
for (const t of ['faz um carrossel de 10 headlines', 'cria a série de posts', 'refaz aqueles carrosseis', 'monta a página da imersão', 'escreve a copy do anúncio', 'gera o banner da promo'])
  ok(`"${t}" pensa (high)`, B.produzPeca(t) === true);
// ajuste cirúrgico = rápido (não repensa)
for (const t of ['muda o título do slide 4', 'troca a cor do botão', 'arruma o espaçamento', 'tira essa palavra da linha'])
  ok(`"${t}" segue rápido`, B.produzPeca(t) === false);
// conversa/consulta = rápido
for (const t of ['qual o melhor horário', 'oi tudo bem', 'o que você acha'])
  ok(`"${t}" não é produção`, B.produzPeca(t) === false);
// kill-switch
process.env.CODEX_PRODUCAO_HIGH = '0';
ok('CODEX_PRODUCAO_HIGH=0 desliga (volta ao antigo)', B.produzPeca('faz um carrossel') === false);
delete process.env.CODEX_PRODUCAO_HIGH;

try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}
console.log(falhas === 0 ? `\n✅ produzir peça: ${14 - falhas}/14 OK` : `\n🔴 ${falhas} falha(s)`);
process.exit(falhas === 0 ? 0 : 1);
