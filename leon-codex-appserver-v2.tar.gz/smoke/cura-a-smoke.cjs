#!/usr/bin/env node
// SMOKE DA CURA A — prova o comportamento "confirma antes de obra longa" pelo código REAL do bridge
// (funções exportadas), não por cópia. 4 casos:
//   1. ordem longa de obra  -> NÃO abre direto (propõe e espera)
//   2. confirmação curta ("pode") -> abre direto
//   3. modo autônomo ligado (flag no .env) -> abre direto mesmo com ordem longa
//   4. ordem curta que já é confirmação -> abre direto
// Não abre Telegram, não chama motor: só a decisão. Sai 0 se 4/4 passam, 1 se algum falha.
process.env.LEON_BRIDGE_TEST_MODE = '1';
const os = require('os'), fs = require('fs'), path = require('path');

// casa de teste isolada pro .env (a flag do /autonomo grava aqui, não no .env real)
const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'cura-a-smoke-'));
process.env.WORK_DIR = casa;
// .env precisa ser 0600 e do próprio uid, senão readSafeEnvFile recusa (mesma trava do agente real).
const envPath = path.join(casa, '.env');
fs.writeFileSync(envPath, 'TELEGRAM_BOT_TOKEN=000:fake-smoke-token\nOWNER_CHAT_ID=' + String(1) + '\n');
fs.chmodSync(envPath, 0o600);

const B = require(path.join(__dirname, '..', 'bridge.cjs'));

let falhas = 0;
function ok(nome, cond) {
  console.log(`  ${cond ? '✓' : '✗'} ${nome}`);
  if (!cond) falhas++;
}

const ordemLonga = 'Reconstrói a página da imersão inteira do zero com nova estrutura, copy, seções de prova e checkout';
const confirmacaoCurta = 'pode';
const ordemCurtaConfirma = 'manda ver';

// A decisão real do gate: abre a missão SÓ se (confirmação curta) OU (autônomo). Espelha o
// call-site (bridge L~8773): if (!_ehConfirmacaoCurta && !_autonomo) { propõe } else { abre }.
function abreDireto(texto) {
  return B.ehConfirmacaoCurtaObra(texto) || B.modoAutonomoLigado();
}

console.log('CURA A — confirma antes de obra longa:');

// garante flag DESLIGADA no começo
B.gravaFlagEnv('LEON_MISSAO_SEM_CONFIRMA', '');

// caso 1: ordem longa -> NÃO abre
ok('ordem longa de obra NÃO abre direto (propõe e espera)', abreDireto(ordemLonga) === false);

// caso 2: "pode" -> abre
ok('confirmação curta "pode" abre direto', abreDireto(confirmacaoCurta) === true);

// caso 4: "manda ver" -> abre
ok('ordem curta "manda ver" abre direto', abreDireto(ordemCurtaConfirma) === true);

// caso 3: liga o autônomo -> ordem longa passa a abrir
B.gravaFlagEnv('LEON_MISSAO_SEM_CONFIRMA', '1');
ok('modo autônomo LIGADO faz ordem longa abrir direto', abreDireto(ordemLonga) === true);
ok('/autonomo gravou a flag no .env', /LEON_MISSAO_SEM_CONFIRMA=1/.test(fs.readFileSync(path.join(casa, '.env'), 'utf8')));

// desliga de novo -> volta a NÃO abrir
B.gravaFlagEnv('LEON_MISSAO_SEM_CONFIRMA', '');
ok('modo autônomo DESLIGADO volta a NÃO abrir ordem longa', abreDireto(ordemLonga) === false);

try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}

console.log(falhas === 0 ? `\n✅ cura A: ${6 - falhas}/6 OK` : `\n🔴 cura A: ${falhas} falha(s)`);
process.exit(falhas === 0 ? 0 : 1);
