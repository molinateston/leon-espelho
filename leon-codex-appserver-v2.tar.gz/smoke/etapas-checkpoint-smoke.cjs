#!/usr/bin/env node
// SMOKE DO ITEM 2-B — etapas persistidas + outbox de intencao, pelo CODIGO REAL do bridge
// (funcoes exportadas), sem copia, sem Telegram, sem motor. Prova as costuras que fazem o
// C07 asercao 3 (3 etapas nunca viram 8 execucoes) passar POR DESENHO:
//   1. parseMarcoEtapa reconhece o marco "Etapa N/M ..." e extrai a prova entre crases
//   2. registraEtapaConcluida grava a etapa e e IDEMPOTENTE (2a passada nao duplica)
//   3. blocoRetomadaPorEtapa lista as concluidas com a prova e manda NAO refazer
//   4. intencao: abre, confirma; reconciliaIntencoesNoBoot marca INCERTO a que ficou aberta
//   5. checkMissions guard: missao incerta NAO reexecuta (contagem de retomada = 0)
//   6. missionPanelText mostra o titulo de incerto (o painel avisa, mesmo message_id)
//   7. kill-switch LEON_ETAPAS=0 desliga a escrita de etapa e a reconciliacao
//   8. round-trip de schema: registro com etapas+intencao salva e le de volta (validador aceita)
// Sai 0 se todas passam, 1 se alguma falha.
process.env.LEON_BRIDGE_TEST_MODE = '1';
process.env.LEON_PULSO_EM_TESTE = '0';
const os = require('os'), fs = require('fs'), path = require('path');

const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'etapas-2b-smoke-'));
process.env.WORK_DIR = casa;
process.env.LEON_DATA_DIR = path.join(casa, 'data');
process.env.LEON_STATE_DIR = path.join(casa, 'data', 'state');
process.env.LEON_MISSIONS_DIR = path.join(casa, 'data', 'state', 'missions');
process.env.LEON_MISSION_OUTPUT_DIR = path.join(casa, 'data', 'mission-output');
process.env.OWNER_CHAT_ID = '555';
for (const d of [process.env.LEON_MISSIONS_DIR, process.env.LEON_MISSION_OUTPUT_DIR]) {
  fs.mkdirSync(d, { recursive: true });
}
const envPath = path.join(casa, '.env');
fs.writeFileSync(envPath, 'TELEGRAM_BOT_TOKEN=000:fake-smoke-token\nOWNER_CHAT_ID=' + String(555) + '\n');
fs.chmodSync(envPath, 0o600);

const B = require(path.resolve(__dirname, '..', 'bridge.cjs'));

let falhas = 0;
function ok(nome, cond, extra) {
  console.log(`  ${cond ? '✓' : '✗'} ${nome}${extra ? ` — ${extra}` : ''}`);
  if (!cond) falhas++;
}

// registro base valido (mesmos campos que startMission grava, status running).
function novaMissao(id, patch = {}) {
  const reg = {
    id, chatId: '555', threadId: null, prompt: 'monte o dossie em 3 etapas',
    seed: '', status: 'running', createdAt: Date.now(), startedAt: Date.now(),
    lastHeartbeat: Date.now(), sid: null, retries: 0, model: 'm', persona: 'p',
    maxRodadas: 5, gateBounces: 0, ...patch,
  };
  if (!B.saveMission(reg, { senderId: '555' })) throw new Error(`saveMission recusou ${id}`);
  return reg;
}

// ---- 1. parseMarcoEtapa -----------------------------------------------------
{
  const m = B.parseMarcoEtapa('Etapa 2/3 ok: os 3 depoimentos processados `/trab/dossie-2.md`');
  ok('1. parse reconhece "Etapa 2/3" e extrai n=2', !!m && m.n === 2 && m.total === 3, m && `n=${m.n} total=${m.total}`);
  ok('1b. parse extrai a prova entre crases', !!m && m.prova === '/trab/dossie-2.md', m && `prova=${m.prova}`);
  const nao = B.parseMarcoEtapa('baixando os arquivos da fonte');
  ok('1c. linha solta (sem "Etapa N") NAO vira etapa', nao === null);
}

// ---- 2 e 3. registra + idempotencia + bloco de retomada ---------------------
{
  const id = 'mcheck000001';
  novaMissao(id);
  const a = B.registraEtapaConcluida(id, { n: 1, total: 3, descricao: 'Etapa 1/3 ok: plano', prova: '/trab/p1' });
  const b = B.registraEtapaConcluida(id, { n: 2, total: 3, descricao: 'Etapa 2/3 ok: corpo', prova: '/trab/p2' });
  ok('2. duas etapas distintas gravadas', a === true && b === true);
  // 2a passada da MESMA etapa 1 (o que uma retomada faria ao reler o .progress): nao duplica
  const rep = B.registraEtapaConcluida(id, { n: 1, total: 3, descricao: 'Etapa 1/3 ok: plano', prova: '/trab/p1' });
  const m1 = B.loadMission(id);
  const e1 = (m1.etapas || []).filter((e) => e.id === 'e_1');
  ok('2b. reprocessar a etapa 1 e IDEMPOTENTE (nao duplica)', rep === false && e1.length === 1, `e_1 aparece ${e1.length}x`);
  ok('2c. as duas etapas ficaram concluidas com prova', (m1.etapas || []).length === 2 && m1.etapas.every((e) => e.estado === 'concluida' && e.prova));

  const bloco = B.blocoRetomadaPorEtapa(m1);
  ok('3. bloco de retomada cita as concluidas', /Etapa 1\/3 ok: plano/.test(bloco) && /Etapa 2\/3 ok: corpo/.test(bloco), bloco.length + ' chars');
  ok('3b. bloco manda NAO refazer e cita a prova', /NAO refaça/.test(bloco) && /\/trab\/p1/.test(bloco));
}

// ---- 4 e 5. intencao -> incerto -> nao reexecuta ----------------------------
{
  const id = 'mintent00001';
  novaMissao(id);
  const ab = B.registraIntencaoDaLinha(id, '[INTENCAO id=i_pub7 publicar no telegram]');
  ok('4. intencao abre com id', ab === true && B.loadMission(id).intencao.id === 'i_pub7');
  // segunda intencao nao entra enquanto a primeira nao fecha
  const ab2 = B.registraIntencaoDaLinha(id, '[INTENCAO id=i_outro faz outra]');
  ok('4b. segunda intencao NAO entra com a primeira aberta', ab2 === false && B.loadMission(id).intencao.id === 'i_pub7');
  // confirma: fecha
  const okc = B.registraIntencaoDaLinha(id, '[INTENCAO-OK id=i_pub7]');
  ok('4c. INTENCAO-OK confirma a intencao', okc === true && B.loadMission(id).intencao.confirmada === true);

  // caso que fica incerto: abre e NAO confirma; reconcilia no boot
  const id2 = 'mincerto0001';
  novaMissao(id2);
  B.registraIntencaoDaLinha(id2, '[INTENCAO id=i_pgto cobrar cliente]');
  const n = B.reconciliaIntencoesNoBoot();
  const mi = B.loadMission(id2);
  ok('5. boot marca INCERTO a missao com intencao aberta', n >= 1 && mi.incerto === true, `reconciliadas=${n}`);
  // a que confirmou NAO vira incerto
  ok('5b. missao com intencao CONFIRMADA nao vira incerto', B.loadMission(id).incerto !== true);
  // checkMissions nao pode reexecutar a incerta: a prova e o retries NAO subir (sem motor, so a guarda)
  const antes = B.loadMission(id2).retries || 0;
  B.checkMissions();
  const depois = B.loadMission(id2).retries || 0;
  ok('5c. checkMissions NAO reexecuta a incerta (retries intacto)', depois === antes, `retries ${antes}->${depois}`);
}

// ---- 6. painel avisa o incerto ----------------------------------------------
{
  const txt = B.missionPanelText({ status: 'running', incerto: true }, [], '2min', false, '');
  ok('6. painel de incerto avisa (nao finge "trabalhando")',
    /(?:Não consegui confirmar|Aguardando confirmação)/.test(txt) && !/^⏳ Trabalhando/.test(txt),
    txt.split('\n')[0]);
}

// ---- 7. kill-switch LEON_ETAPAS=0 -------------------------------------------
{
  process.env.LEON_ETAPAS = '0';
  const id = 'mkillsw00001';
  novaMissao(id);
  const grav = B.registraEtapaConcluida(id, { n: 1, total: 3, descricao: 'Etapa 1/3', prova: '/x' });
  ok('7. LEON_ETAPAS=0 nao grava etapa', grav === false && !(B.loadMission(id).etapas || []).length);
  const abre = B.registraIntencaoDaLinha(id, '[INTENCAO id=i_z faz]');
  ok('7b. LEON_ETAPAS=0 nao abre intencao', abre === false && !B.loadMission(id).intencao);
  ok('7c. LEON_ETAPAS=0 bloco de retomada vazio', B.blocoRetomadaPorEtapa({ etapas: [{ id: 'e_1', estado: 'concluida', descricao: 'x' }] }) === '');
  delete process.env.LEON_ETAPAS;
}

// ---- 8. round-trip de schema ------------------------------------------------
{
  const id = 'mschema00001';
  const reg = novaMissao(id, {
    etapas: [
      { id: 'e_1', descricao: 'plano', estado: 'concluida', prova: '/p1', concluida_em: Date.now() },
      { id: 'e_2', descricao: 'corpo', estado: 'pendente', prova: null, concluida_em: null },
    ],
    intencao: { id: 'i_a', descricao: 'publica', aberta_em: Date.now(), confirmada: false },
  });
  const lido = B.loadMission(id);
  ok('8. registro com etapas+intencao salva e le de volta', !!lido && (lido.etapas || []).length === 2 && lido.intencao.id === 'i_a');
  // validador recusa campo desconhecido dentro de etapa
  const mau = { ...reg, etapas: [{ id: 'e_9', descricao: 'x', estado: 'concluida', prova: null, concluida_em: Date.now(), lixo: 1 }] };
  ok('8b. validador recusa campo estranho dentro de etapa', B.validMissionRecord(mau, { senderId: '555' }) === false);
  // validador recusa estado de etapa fora do enum
  const mau2 = { ...reg, etapas: [{ id: 'e_9', descricao: 'x', estado: 'voando', prova: null, concluida_em: null }] };
  ok('8c. validador recusa estado de etapa fora do enum', B.validMissionRecord(mau2, { senderId: '555' }) === false);
}

try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}
console.log(falhas ? `\nFALHOU: ${falhas} asercao(oes)` : '\nOK: todas as asercoes passaram');
process.exit(falhas ? 1 : 0);
