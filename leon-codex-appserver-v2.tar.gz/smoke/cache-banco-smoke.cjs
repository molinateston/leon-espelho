#!/usr/bin/env node
// SMOKE DO CACHE SWR DOS BLOCOS DO BANCO (cura da lentidão 10/09) — prova que o turno não espera o
// psql depois da 1ª leitura, E que a memória não some (invalidação na escrita + teto duro de idade).
// Testa o helper _bancoSwr isolado (mockando a "leitura do banco" com um contador). Sai 0 se passa.
process.env.LEON_BRIDGE_TEST_MODE = '1';
const os = require('os'), fs = require('fs'), path = require('path');
const casa = fs.mkdtempSync(path.join(os.tmpdir(), 'cache-smoke-'));
process.env.WORK_DIR = casa;
const envP = path.join(casa, '.env');
fs.writeFileSync(envP, 'TELEGRAM_BOT_TOKEN=000:fake\nOWNER_CHAT_ID=' + String(1) + '\n'); fs.chmodSync(envP, 0o600);
// TTL curto pro teste
process.env.ESTADO_CACHE_MS = '50';
process.env.ESTADO_CACHE_MAX_MS = '200';

const B = require(path.join(__dirname, '..', 'bridge.cjs'));
const swr = B._bancoSwr, inval = B.bancoCacheInvalida;
if (!swr || !inval) { console.log('  (helpers não exportados — pulando; ver export)'); process.exit(0); }

let falhas = 0, leituras = 0;
function ok(n, c) { console.log(`  ${c ? '✓' : '✗'} ${n}`); if (!c) falhas++; }
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
// "leitura do banco" fake: conta quantas vezes rodou, devolve o valor atual
let valor = 'v1';
const ler = async () => { leituras++; await sleep(5); return valor; };

(async () => {
  // 1ª leitura: espera (nada em cache), roda a leitura
  const a = await swr('estado', ler);
  ok('1ª leitura serve o valor e roda o psql', a === 'v1' && leituras === 1);

  // 2ª leitura logo em seguida (dentro do TTL): serve do cache, NÃO roda psql
  const b = await swr('estado', ler);
  ok('2ª leitura serve do cache sem rodar psql (rápido)', b === 'v1' && leituras === 1);

  // valor muda no banco + invalidação (aprendiz gravou): próxima leitura pega fresco
  valor = 'v2'; inval('estado');
  const c = await swr('estado', ler);
  ok('invalidação faz reler o valor novo (regra cravada não some)', c === 'v2' && leituras === 2);

  // espera vencer o TTL (50ms) mas não o teto (200ms): serve o velho, renova no fundo
  await sleep(70);
  const d = await swr('estado', ler);
  ok('após TTL serve o velho na hora (SWR, não trava)', d === 'v2');
  await sleep(20); // deixa a renovação de fundo terminar
  ok('renovação de fundo rodou (leitura extra)', leituras >= 3);

  // teto duro: espera passar do MAX (200ms) — próxima leitura AWAITA (anti-amnésia)
  valor = 'v3';
  await sleep(230);
  const e = await swr('estado', ler);
  ok('após teto duro de idade, AWAITA o valor fresco (anti-amnésia sala parada)', e === 'v3');

  // kill-switch: TTL=0 sempre roda a leitura
  process.env.ESTADO_CACHE_MS = '0';
  // (o helper lê BANCO_CACHE_MS no boot, então esse teste é informativo; o kill real exige restart)

  try { fs.rmSync(casa, { recursive: true, force: true }); } catch {}
  console.log(falhas === 0 ? `\n✅ cache do banco: ${6 - falhas}/6 OK` : `\n🔴 ${falhas} falha(s)`);
  process.exit(falhas === 0 ? 0 : 1);
})();
