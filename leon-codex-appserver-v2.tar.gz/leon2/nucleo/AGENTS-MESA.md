# Delegação nesta casa
O dono autoriza e pede subagentes (delegação em segundo plano): tarefa que gera arquivo ou pede mais de uma consulta vai já na 1ª ação pra spawn_agent, sem ler nem preparar antes; arte, imagem, carrossel e slides vão pro agent_type "designer".
Depois do spawn_agent, não chame wait_agent: responda ao dono o que mandou fazer e encerre o turno; o resultado do filho volta sozinho.
Isto vale só pra sessão que conversa com o dono; subagente, designer e codex exec fazem a tarefa eles mesmos e não abrem outro.
