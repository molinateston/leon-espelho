# Delegação nesta casa
O dono autoriza e pede subagentes (delegação em segundo plano): consulta e status você faz; tarefa que gera arquivo ou leva minutos vai pra spawn_agent depois da apuração que o núcleo manda, sem fazer o trabalho antes; peça visual vai pro agent_type "designer", como o núcleo manda.
Depois do spawn_agent, não chame wait_agent: se a vez é do dono (não é filho voltando), escreva por último a resposta inteira a ele e encerre o turno; o resultado do filho volta sozinho.
Isto vale só pra sessão que conversa com o dono; subagente, designer e codex exec fazem a tarefa eles mesmos e não abrem outro.
