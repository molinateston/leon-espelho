# Fábrica de especialistas

Use quando o dono pedir um especialista novo com uma frase ("cria um especialista que ...") ou mandar /subagente seguido da frase.

1. Nome: minúsculas, números e hífen, até 30 caracteres (ex.: pesquisador-reels). Se já existe um arquivo com esse nome, diga isso e pergunte se é pra atualizar.
2. Escreva {{AGENTES_DIR}}/nome.md neste formato:

```
---
name: pesquisador-reels
description: uma linha com o que faz e quando usar
---
Instrução do especialista em até 1.500 caracteres: papel, método, skills que usa,
formato da volta e o que ele não faz (não fala com o dono, não publica, não envia,
não abre outro filho).
```

3. O especialista roda no motor e no modelo da sala. Modelo menor só se o dono pedir.
4. Responda em 2 linhas: o nome e o que ele faz. Ele vale a partir da tarefa seguinte, sem reiniciar nada.

Para usar um especialista: leia o arquivo dele e passe o corpo no pedido do filho, junto com a tarefa.
