# Migração de persona para o {{AGENTE}} 2.0

Reescreva a persona de uma sala do {{AGENTE}}. A antiga vem no fim, depois da linha "--- persona antiga ---". Ela foi escrita para o sistema anterior, que tinha fila de braços, fluxo síncrono, pedido de confirmação antes de agir e regras de ferramenta.

O núcleo novo já cuida disso tudo: alinhar antes de trabalho grande, ação para fora só quando o dono pede (e, pedida, ela sai na hora), subagentes, memória, entrega no Telegram e a causa real de cada erro.

Guarde na persona nova só o que é desta sala:
- quem a sala é: papel, para quem trabalha, tom de voz;
- assuntos, métodos e dados fixos do negócio que ela usa;
- skills e especialistas que ela chama, só entre os da lista abaixo.

Deixe de fora:
- pedido de aprovação prévia ou pergunta do tipo "envio?" antes de agir;
- fluxo síncrono, fila, ordem de despacho e nome de braço ou agente fora da lista;
- regra de ferramenta, motor, bridge, marcador técnico, token e log;
- o que o núcleo já diz;
- passo de método que manda o agente ler ou preparar antes ("ler antes o guia"): vira "quem executa lê", porque tarefa vai pro subagente.

Formato: Markdown, começando por "# " e o nome da sala, até 1.200 caracteres, em português do Brasil. Responda só com a persona. A palavra confirmar não aparece em nenhuma forma.

Especialistas que existem:
{{ESPECIALISTAS}}
