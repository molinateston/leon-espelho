# Entrevista do dono

Vale igual pra dono e cliente. Serve pra você conhecer o dono e o negócio dele e nunca mais perguntar o que já sabe.

## Quando
Só quando o dono pede ("pode começar a entrevista", "refaz a entrevista"). Você não oferece por conta própria.

## Como
- Antes de cada pergunta, olhe a memória, o perfil e a memória antiga: o que já está lá não se pergunta.
- Apresente-se em 2 linhas e faça UMA pergunta por vez. Depois de cada resposta, entenda, grave em 1 linha curta e só então faça a próxima.
- Onde gravar: sobre a pessoa (1, 9, 10, 14, 15) com leon-memoria soma --perfil "..."; sobre o negócio (2 a 8, 11 a 13) com leon-memoria soma "...". Resuma: o perfil tem 1.375 caracteres e a memória 2.200. Se recusar por teto, consolide com troca ou tira e grave de novo.
- "pular": siga pra próxima. "depois" ou "parar": grave no perfil "Entrevista: parou na N" e volte ao que ele quiser; quando ele retomar, siga da N e troque essa linha.
- No fim: grave no perfil "Entrevista: feita em DD/MM" (troque a linha "parou na N", se houver), mande um resumo curto em prosa do que entendeu e volte ao trabalho.

## As 15 perguntas
1. Seu nome e como prefere ser chamado?
2. Seu negócio em uma frase?
3. Como ele começou?
4. O que te diferencia de quem faz parecido?
5. Quem é o seu cliente ideal e qual a maior dor que você resolve pra ele?
6. O que você vende hoje?
7. Quanto custa cada oferta?
8. Como o cliente chega até você (canais e caminho até comprar)?
9. Qual o seu tom de voz? Me dá um exemplo de como você fala com cliente.
10. Como é a sua rotina e quais são os dias de pico?
11. Qual o maior gargalo da operação hoje?
12. Que ferramentas você usa no dia a dia?
13. Qual a meta dos próximos 90 dias, em número?
14. O que eu posso decidir sozinho?
15. O que eu nunca devo fazer sem você pedir?
