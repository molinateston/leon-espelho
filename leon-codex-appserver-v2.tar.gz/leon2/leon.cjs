#!/usr/bin/env node
'use strict';
// LEON 2.0, M0: sobe tudo, segura uma instância só, roda o laço do Telegram e desliga limpo.
const fs = require('fs'), path = require('path');
const config = require('./lib/config.cjs');
const { log, tgOut } = require('./lib/log.cjs');
const estadoMod = require('./lib/estado.cjs'), telegram = require('./lib/telegram.cjs'), entradaMod = require('./lib/entrada.cjs'), vozMod = require('./lib/voz.cjs');
const promptMod = require('./lib/prompt.cjs'), motorClaude = require('./lib/motor-claude.cjs'), motorCodex = require('./lib/motor-codex.cjs');
const salaMod = require('./lib/sala.cjs'), comandosMod = require('./lib/comandos.cjs');

const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const vivo = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
const erro = (e) => String((e && (e.stack || e.descricao || e.message)) || e);
process.on('uncaughtException', (e) => log('ponte', `exceção solta: ${erro(e)}`));
process.on('unhandledRejection', (e) => log('ponte', `promessa rejeitada solta: ${erro(e)}`));

let cfg;
try { cfg = config.carregar(process.env); } catch (e) { log('ponte', `não subi: ${e.message}`); process.exit(1); }

for (const s of ['SIGTERM', 'SIGINT']) process.on(s, () => desliga(s));   // antes do cadeado: stop no boot não o deixa órfão
// Cadeado: um processo só lê o bot (dois dão 409 e brigam pelo sessions.json).
const PID = path.join(cfg.pastas.leon2Estado, 'leon2.pid');
try { fs.writeFileSync(PID, String(process.pid), { flag: 'wx', mode: 0o600 }); }
catch (e) {
  if (e.code !== 'EEXIST') throw e;
  const velho = Number(fs.readFileSync(PID, 'utf8')) || 0;
  if (velho && velho !== process.pid && vivo(velho)) {
    log('ponte', `já tem um LEON rodando (pid ${velho}); saio pra não ler o bot em dobro`);
    process.exit(1);
  }
  fs.writeFileSync(PID, String(process.pid), { mode: 0o600 });
  log('ponte', `cadeado órfão (pid ${velho} morto) retomado`);
}
const soltaCadeado = () => { try { if (Number(fs.readFileSync(PID, 'utf8')) === process.pid) fs.unlinkSync(PID); } catch {} };

const estado = estadoMod.criar(cfg);
const tg = telegram.criar({ token: cfg.envVal('TELEGRAM_BOT_TOKEN'), base: cfg.envVal('TELEGRAM_API_BASE') || 'https://api.telegram.org', log, tgOut });
const voz = vozMod.criar({ cfg, log }), prompt = promptMod.criar({ cfg, log });
const entrada = entradaMod.criar({ cfg, estado, tg, voz, log });
let salas = null;   // os motores só chamam de volta depois do 1º turno, quando salas já existe
const ligaMotor = (mod, nome) => mod.criar({ cfg, log,
  aoTurnoSolto: (s, f) => salas.turnoSolto(nome, s, f), aoFundo: (s, l) => salas.fundo(nome, s, l) });
const motores = { claude: ligaMotor(motorClaude, 'claude'), codex: ligaMotor(motorCodex, 'codex') };
salas = salaMod.criar({ cfg, estado, tg, voz, prompt, motores, log });
const cmds = comandosMod.criar({ cfg, estado, tg, salas, motores, voz, log });

// Uma cadeia de promessa por sala: mensagens da mesma sala entram na ordem em que chegaram.
const cadeias = new Map();
function naCadeia(chave, fn) {
  const agora = (cadeias.get(chave) || Promise.resolve()).then(fn).catch((e) => log('ponte', `sala=${chave} falhou: ${erro(e)}`));
  cadeias.set(chave, agora);
  agora.then(() => { if (cadeias.get(chave) === agora) cadeias.delete(chave); });
}

// Toque num botão: roda o comando sem inflight; a sala vem do dado (@tópico).
function toque(u) {
  const q = u.callback_query, m = q.message || {}, d = /^(.*)@(\d*)$/.exec(String(q.data || ''));
  if (!m.chat || (!d && !m.date)) return m.chat && tg.responde(q.id, 'Mande o comando de novo nesta sala.').catch(() => {});   // inline não é nosso; sem saber a sala, não age
  const t = m.date ? (m.message_thread_id ? String(m.message_thread_id) : null) : d ? d[2] || null : null, sala = estado.sala(m.chat.id, t);
  naCadeia(sala.chave, () => cmds.botao(d ? { ...q, data: d[1] } : q, sala, entrada.aceita({ update_id: u.update_id, message: { chat: m.chat, message_thread_id: +t || undefined, from: q.from, text: '/botao', entities: [{ type: 'mention' }] } })));
}

function recebe(u) {
  if (u.callback_query) return toque(u);
  if (!entrada.aceita(u)) return;
  const msg = u.message;
  const sala = estado.sala(msg.chat.id, msg.message_thread_id ? String(msg.message_thread_id) : null);
  estado.inflight.soma(sala, u);   // antes do offset: reinício não perde a mensagem
  naCadeia(sala.chave, async () => {
    const pedido = await entrada.normaliza(u);
    entrada.rajada(pedido, async (lista) => {
      try {
        const p = await cmds.trata(entradaMod.juntar(lista));
        if (p) salas.receber(p); else estado.inflight.tira(sala, lista.map((x) => x.updateId));   // consumido: não volta no boot
      }
      catch (e) { log('ponte', `sala=${sala.chave} rajada falhou: ${erro(e)}`); }
    });
  });
}

let parando = false;
const ALIVE = path.join(cfg.pastas.raiz, '.alive');   // batimento lido pelo atualizador e pelo vigia
async function laco() {
  let offset = estado.offset(), pausa = 3000;
  while (!parando) {
    let ups;
    try {
      ups = await tg.receber(offset + 1, 30);
      if (!Array.isArray(ups)) throw ups || new Error('getUpdates sem resposta');
      pausa = 3000;
      fs.writeFile(ALIVE, String(Date.now()), () => {});
    } catch (e) {
      if (parando) break;
      const causa = String((e && (e.descricao || e.message)) || e);
      if (/409|conflict/i.test(causa)) { log('ponte', `409: outro processo lê este bot; espero 30 s (${causa})`); await espera(30000); }
      else { log('ponte', `getUpdates falhou: ${causa}; tento de novo em ${pausa / 1000} s`); await espera(pausa); pausa = Math.min(pausa * 2, 60000); }
      continue;
    }
    for (const u of ups) {
      if (parando) break;
      try { recebe(u); } catch (e) { log('ponte', `update ${u.update_id} falhou: ${erro(e)}`); }
      offset = u.update_id;
      estado.gravaOffset(offset);
    }
  }
}

async function desliga(sinal) {
  if (parando) return;
  parando = true;
  setTimeout(() => { soltaCadeado(); process.exit(0); }, 20000).unref();   // teto: desligar nunca pendura
  log('ponte', `${sinal}: desligando (o que estava em curso fica no inflight pro próximo boot)`);
  try { cmds.encerrar(); await salas.encerrar(); } catch (e) { log('ponte', `salas.encerrar: ${erro(e)}`); }
  await Promise.all(Object.values(motores).map((m) => Promise.resolve().then(() => m.encerrar()).catch((e) => log('ponte', `${m.nome}.encerrar: ${erro(e)}`))));
  soltaCadeado();
  process.exit(0);
}

(async () => {
  const { memoria: mem0, perfil: perf0 } = cfg.pastas;   // casa nova (sem memória nem perfil): o perfil nasce com a entrevista pendente
  if (mem0 && perf0 && !fs.existsSync(mem0) && !fs.existsSync(perf0)) { fs.mkdirSync(path.dirname(perf0), { recursive: true }); fs.writeFileSync(perf0, 'Entrevista: pendente (casa nova)\n'); log('ponte', 'casa nova: entrevista pendente'); }
  await tg.comandos(cmds.lista);
  await salas.retomar();
  log('ponte', `${cfg.agente} 2.0 no ar (pid ${process.pid})`);
  cmds.aoSubir().catch((e) => log('ponte', `aoSubir: ${erro(e)}`));
  await laco();
})().catch((e) => { log('ponte', `boot falhou: ${erro(e)}`); soltaCadeado(); process.exit(1); });
