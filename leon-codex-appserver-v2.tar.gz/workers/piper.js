#!/usr/bin/env node
'use strict';

// Piper TTS local. A raiz de dados acompanha a instalação do LEON e pode ser
// movida por LEON_DATA_DIR sem gravar caminhos específicos do servidor.
const { spawn } = require('node:child_process');
const { existsSync, unlinkSync, statSync } = require('node:fs');
const { homedir } = require('node:os');

const dataDir = process.env.LEON_DATA_DIR || `${homedir()}/.leon`;
const piperBin = process.env.PIPER_BIN || `${dataDir}/piper-venv/bin/piper`;
const piperModel = process.env.PIPER_MODEL || `${dataDir}/voices/piper/pt_BR-faber-medium.onnx`;
const ffmpegBin = process.env.FFMPEG_BIN || 'ffmpeg';

function succeed(value) {
  process.stdout.write(`${JSON.stringify({ ok: true, ...value })}\n`);
  process.exit(0);
}

function fail(message) {
  process.stdout.write(`${JSON.stringify({ ok: false, error: String(message) })}\n`);
  process.exit(1);
}

function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['pipe', 'pipe', 'pipe'], ...options });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    if (options.input != null) {
      child.stdin.write(options.input);
      child.stdin.end();
    }
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error(`${command} exit ${code}: ${stderr.slice(0, 300)}`));
    });
  });
}

async function check() {
  if (!existsSync(piperBin)) throw new Error(`piper não encontrado em ${piperBin}`);
  if (!existsSync(piperModel)) throw new Error(`modelo de voz não encontrado em ${piperModel}`);
  await run(piperBin, ['--help']);
  return { bin: piperBin, model: piperModel };
}

async function synthesize({ text, out, voice, speed }) {
  if (!text) throw new Error('--text obrigatório');
  if (!out) throw new Error('--out obrigatório');
  const modelPath = voice || piperModel;
  if (!existsSync(piperBin)) throw new Error(`piper não encontrado em ${piperBin}`);
  if (!existsSync(modelPath)) throw new Error(`modelo não encontrado em ${modelPath}`);

  const wav = out.replace(/\.mp3$/i, '') + `.piper-${Date.now()}.wav`;
  const args = ['-m', modelPath, '-f', wav];
  if (speed) args.push('--length-scale', String(1 / Number(speed)));

  await run(piperBin, args, { input: String(text) });
  try {
    await run(ffmpegBin, ['-y', '-i', wav, '-codec:a', 'libmp3lame', '-qscale:a', '4', out]);
  } finally {
    try { unlinkSync(wav); } catch {}
  }
  return {
    path: out,
    chars: String(text).length,
    model: modelPath,
    bytes: statSync(out).size,
  };
}

function parseArgs() {
  const parsed = {};
  for (let index = 2; index < process.argv.length; index += 1) {
    const key = process.argv[index];
    if (key.startsWith('--')) parsed[key.slice(2)] = process.argv[++index] ?? true;
  }
  return parsed;
}

(async () => {
  try {
    const args = parseArgs();
    const action = args.action || 'tts';
    if (action === 'check') return succeed(await check());
    if (action === 'tts') {
      return succeed(await synthesize({
        text: args.text,
        out: args.out,
        voice: args.voice,
        speed: args.speed,
      }));
    }
    return fail(`ação desconhecida: ${action}`);
  } catch (error) {
    return fail(error.message);
  }
})();
