#!/usr/bin/env python3
"""Builder offline e autocontido do designer LEON Codex."""

import base64
import html
import re
from pathlib import Path


FONTS_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"
FONT_COMBOS = {
    "inter_bruto": (
        "Inter",
        [
            ("inter-latin-400-normal.woff2", 400),
            ("inter-latin-700-normal.woff2", 700),
            ("inter-latin-800-normal.woff2", 800),
        ],
    ),
    "fraunces_premium": (
        "Fraunces",
        [
            ("fraunces-latin-400-normal.woff2", 400),
            ("fraunces-latin-700-normal.woff2", 700),
            ("fraunces-latin-900-normal.woff2", 900),
        ],
    ),
    "bricolage_honesto": (
        "Bricolage Grotesque",
        [
            ("bricolage-grotesque-latin-400-normal.woff2", 400),
            ("bricolage-grotesque-latin-700-normal.woff2", 700),
            ("bricolage-grotesque-latin-800-normal.woff2", 800),
        ],
    ),
    "caveat_anotacao": (
        "Caveat",
        [
            ("caveat-latin-600-normal.woff2", 600),
            ("caveat-latin-700-normal.woff2", 700),
        ],
    ),
}


def escape_text(value):
    """Escapa texto do usuário antes de inseri-lo no HTML."""
    return html.escape(str(value), quote=True)


def _embedded_fonts(font_combo):
    if font_combo not in FONT_COMBOS:
        raise ValueError(f"combo de fonte desconhecido: {font_combo}")
    family, files = FONT_COMBOS[font_combo]
    rules = []
    for filename, weight in files:
        path = FONTS_DIR / filename
        data = path.read_bytes()
        encoded = base64.b64encode(data).decode("ascii")
        rules.append(
            "@font-face{"
            f"font-family:'{family}';font-style:normal;font-weight:{weight};"
            f"src:url(data:font/woff2;base64,{encoded}) format('woff2');"
            "font-display:block;}"
        )
    return family, "".join(rules)


def make_symmetric_slide(content_html, bg_color, max_width=880, text_align="left", extra_style=""):
    """Monta um card 1080 por 1350 com margens simétricas."""
    if text_align not in {"left", "center", "right"}:
        raise ValueError("alinhamento inválido")
    if not isinstance(max_width, int) or not 320 <= max_width <= 880:
        raise ValueError("largura inválida")
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", bg_color):
        raise ValueError("cor de fundo inválida")
    if re.search(r"url\s*\(|@import|expression\s*\(|behavior\s*:", extra_style, re.I):
        raise ValueError("CSS externo ou ativo rejeitado")
    return (
        '<section class="slide" style="'
        f'background:{bg_color};{extra_style}">'
        f'<div class="content" style="max-width:{max_width}px;text-align:{text_align}">'
        f"{content_html}</div></section>"
    )


def build_html(slides_html, font_combo="inter_bruto"):
    """Monta um preview HTML sem rede, script externo ou instalação dinâmica."""
    if not isinstance(slides_html, (list, tuple)) or not slides_html:
        raise ValueError("slides_html precisa conter ao menos um card")
    family, font_css = _embedded_fonts(font_combo)
    cards = []
    for index, slide in enumerate(slides_html, start=1):
        cards.append(
            f'<div class="slide-wrapper"><div class="slide-label">CARD {index:02d}</div>{slide}</div>'
        )
    return """<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Preview LEON</title><style>
%s
*{box-sizing:border-box}body{margin:0;padding:32px;background:#ddd;color:#111;font-family:'%s',sans-serif}
.slide-wrapper{margin:0 auto 32px;width:1080px}.slide-label{font:700 18px system-ui;margin:0 0 8px}
.slide{width:1080px;height:1350px;padding:100px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.content{width:100%%}h1,h2,p{margin-top:0}img{max-width:100%%;height:auto}
</style></head><body>%s</body></html>""" % (font_css, family, "".join(cards))
