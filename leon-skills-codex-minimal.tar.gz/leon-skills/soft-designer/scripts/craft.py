#!/usr/bin/env python3
"""Gate offline de segurança, contraste e órfãs para HTML do designer."""

import re
import sys
from html.parser import HTMLParser


NB = " "
FORBIDDEN_TAGS = {
    "script", "iframe", "object", "embed", "form", "base", "link",
    "foreignobject", "animate", "animatemotion", "animatetransform", "set",
    "audio", "video", "source", "track",
}
URL_ATTRS = {
    "src", "href", "xlink:href", "action", "formaction", "poster", "data",
    "srcset", "imagesrcset", "ping", "background", "longdesc", "cite",
}
REMOTE = re.compile(r"(?:https?:)?//", re.I)
DANGEROUS_SCHEME = re.compile(r"^\s*(?:javascript|vbscript):", re.I)
CSS_ACTIVE = re.compile(r"@import|expression\s*\(|behavior\s*:", re.I)
CSS_URL = re.compile(r"url\s*\(\s*(['\"]?)(.*?)\1\s*\)", re.I | re.S)
SAFE_DATA_IMAGE = re.compile(r"^data:image/(?:png|jpeg|webp|gif|avif);base64,[A-Za-z0-9+/=\s]+$", re.I)


def nw(value):
    """Une as duas últimas palavras para reduzir órfã tipográfica."""
    text = str(value)
    parts = text.rsplit(" ", 1)
    return NB.join(parts) if len(parts) == 2 else text


def _hex(value):
    match = re.fullmatch(r"#([0-9a-fA-F]{6})", value.strip())
    if not match:
        raise ValueError(value)
    raw = match.group(1)
    return tuple(int(raw[index:index + 2], 16) / 255 for index in (0, 2, 4))


def _linear(channel):
    return channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4


def luminance(color):
    red, green, blue = (_linear(channel) for channel in _hex(color))
    return 0.2126 * red + 0.7152 * green + 0.0722 * blue


def contrast_ratio(foreground, background):
    first, second = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (first + 0.05) / (second + 0.05)


def legible(foreground, background, minimum=3.0):
    return contrast_ratio(foreground, background) >= minimum


def _css_failures(css, label):
    failures = []
    if "\\" in css:
        failures.append(f"escape CSS proibido em {label}")
    if CSS_ACTIVE.search(css):
        failures.append(f"CSS ativo proibido em {label}")
    for match in CSS_URL.finditer(css):
        target = match.group(2).strip()
        if target.startswith("data:font/woff2;base64,") or SAFE_DATA_IMAGE.fullmatch(target) or target.startswith("#"):
            continue
        failures.append(f"URL externa ou não autocontida em {label}")
    # Não examine o payload base64 de URLs locais: os bytes codificados podem
    # conter "//" por acaso. URLs remotas fora de url(...) continuam proibidas,
    # inclusive nos formatos image-set() e semelhantes.
    css_without_url_functions = CSS_URL.sub("", css)
    if REMOTE.search(css_without_url_functions):
        failures.append(f"URL remota proibida em {label}")
    return failures


class Auditor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.failures = []
        self.style_depth = 0

    def handle_starttag(self, tag, attrs):
        lowered = tag.casefold()
        attrs = [(name.casefold(), value or "") for name, value in attrs]
        if lowered in FORBIDDEN_TAGS:
            self.failures.append(f"tag proibida: {lowered}")
        if lowered == "meta":
            values = {name: value for name, value in attrs}
            if values.get("http-equiv", "").casefold() == "refresh":
                self.failures.append("meta refresh proibido")
        if lowered == "style":
            self.style_depth += 1
        for name, value in attrs:
            if not re.fullmatch(r"[a-z_:][a-z0-9_.:-]*", name):
                self.failures.append("nome de atributo inválido")
            if name.startswith("on"):
                self.failures.append(f"event handler proibido: {name}")
            if name == "srcdoc":
                self.failures.append("srcdoc proibido")
            compact = re.sub(r"[\x00-\x20\x7f]+", "", value)
            if DANGEROUS_SCHEME.search(compact):
                self.failures.append(f"protocolo ativo proibido em {name}")
            if name in URL_ATTRS:
                clean = value.strip()
                if name in {"srcset", "imagesrcset", "ping"} and clean:
                    self.failures.append(f"atributo de rede proibido: {name}")
                    continue
                allowed = clean.startswith("#") or SAFE_DATA_IMAGE.fullmatch(clean) or clean == ""
                if not allowed:
                    self.failures.append(f"URL não autocontida em {name}")
            if name == "style":
                self.failures.extend(_css_failures(value, "atributo style"))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        if tag.casefold() == "style" and self.style_depth:
            self.style_depth -= 1

    def handle_data(self, data):
        if self.style_depth:
            self.failures.extend(_css_failures(data, "bloco style"))


def _orphan_warnings(source):
    warnings = []
    for segment in re.findall(r">([^<>]+)<", source):
        plain = " ".join(segment.split())
        words = plain.split()
        if len(words) == 1 and len(plain) >= 3 and NB not in segment:
            warnings.append(f'órfã provável: "{plain[:30]}"')
    return warnings


def audit_html(source):
    auditor = Auditor()
    try:
        auditor.feed(source)
        auditor.close()
    except Exception as error:
        auditor.failures.append(f"HTML inválido: {error}")
    failures = list(dict.fromkeys(auditor.failures))
    warnings = list(dict.fromkeys(_orphan_warnings(source)))
    return failures, warnings


def audit_file(path):
    try:
        source = open(path, encoding="utf-8").read()
    except OSError as error:
        print(f"ERRO: não abriu {path}: {error}")
        return 2
    failures, warnings = audit_html(source)
    for warning in warnings:
        print(f"AVISO: {warning}")
    if failures:
        for failure in failures:
            print(f"FALHA: {failure}")
        return 1
    print(f"auditoria de craft passou: 0 falhas, {len(warnings)} avisos")
    return 0


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "audit":
        raise SystemExit(audit_file(sys.argv[2]))
    assert nw("uma ideia forte") == "uma ideia" + NB + "forte"
    assert legible("#1A1814", "#F5F2EC")
    assert not legible("#FFFFFF", "#F5F2EC")
    safe = '<svg><path d="M0 0L1 1"/></svg><img src="data:image/png;base64,AA==">'
    assert not audit_html(safe)[0]
    unsafe = '<script>x</script><img src="' + "https:" + "/" + '/example.invalid/x" onerror="x">'
    assert audit_html(unsafe)[0]
    print("craft self-test OK")
