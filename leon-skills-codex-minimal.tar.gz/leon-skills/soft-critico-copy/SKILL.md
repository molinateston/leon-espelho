---
name: soft-critico-copy
description: "Gate local de critica de copy para LEON Codex. Recebe texto pronto, roda lint e avalia clareza, credibilidade, interesse, estrutura, voz e lastro. Nao gera fatos, nao usa fonte de outro cliente, nao chama conector e nao coleta credencial."
---

# Crítico de Copy para LEON Codex

Use esta skill para revisar copy pronta antes da entrega. Ela não substitui a skill autora e não inventa conteúdo do negócio.

## Entrada

- texto completo;
- tipo da peça;
- contexto fornecido pelo usuário;
- fonte de lastro para afirmação factual.

Sem texto, peça o texto. Sem fonte para número, case, prazo, mecanismo ou promessa, marque a afirmação como `SEM LASTRO`. Nunca use exemplo interno como prova do cliente.

## Limites

- Não pesquise nem acione conector.
- Não leia configuração, credencial ou arquivo protegido.
- Não use dado de outro usuário.
- Não transforme exemplo em fato.
- Não edite o texto original.

## Processo

### 1. Rode o lint

Salve uma cópia do texto em `@@LEON_WORK_AREA@@` e rode:

```bash
python3 @@LEON_SKILLS_DIR@@/soft-critico-copy/scripts/lint_copy.py <arquivo>
```

Falha dura reprova. Aviso exige revisão editorial, mas não reprova sozinho.

### 2. Avalie clareza, credibilidade e interesse

- Clareza: alguém frio entende sem reler?
- Credibilidade: a promessa tem proporção e fonte?
- Interesse: a linha traz uma leitura concreta ou repete lugar comum?

### 3. Avalie a estrutura

Verifique a sequência aplicável ao tamanho da peça:

- diagnóstico;
- nomeação;
- polaridade;
- nova interpretação;
- consequência;
- movimento.

Peça curta pode comprimir etapas, mas não pode depender de contexto ausente.

### 4. Avalie a forma

Procure repetição mecânica, simetria excessiva, transição genérica, fechamento que resume, lista de três sem função e densidade uniforme.

### 5. Avalie o lastro

Para cada número, case, prazo, garantia, mecanismo ou resultado:

- cite a fonte indicada pelo usuário;
- marque `COM LASTRO` quando a fonte sustentar;
- marque `SEM LASTRO` quando faltar ou divergir;
- não busque substituto em referência interna.

### 6. Entregue o veredito

```text
VEREDITO: PASSOU
ACERTO CENTRAL: <uma linha>
LASTRO: <completo ou nao aplicavel>
```

```text
VEREDITO: REPROVADA
FALHAS:
- FILTRO: <clareza, credibilidade, interesse, estrutura, forma, lint ou lastro>
  TRECHO: <trecho curto>
  MOTIVO: <uma linha>
  AJUSTE: <sugestao curta>
```

Não reescreva a peça inteira. A skill autora aplica os ajustes. Limite o ciclo a três revisões antes de pedir decisão editorial do usuário.

## Recurso empacotado

- `scripts/lint_copy.py` executa o gate local.

Não há outra dependência ou referência nesta skill.
