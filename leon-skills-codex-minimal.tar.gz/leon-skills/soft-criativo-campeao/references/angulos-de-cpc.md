# Arsenal de ângulos: 6 técnicas de CPC baixo

Estes 6 ângulos entram no Passo 1 do lote. Cada peça continua nascendo de UMA
dor (a regra de ouro do lote não muda), mas o ângulo escolhe COMO essa dor vira
gancho. O princípio por trás de todos: comunicação que o mercado não está usando,
somada a comunicação que o público quer consumir, tira o anúncio do leilão
saturado. O Meta lê como qualidade alta e o CPC cai. Comunicação única, menos
concorrência, leilão limpo, CPC menor.

Você não usa os seis na mesma peça. Escolhe um por gancho, e no lote de 4 pode
variar os ângulos pra descobrir qual fala com o avatar. Todo gancho, seja qual
for o ângulo, ainda passa pelo lint anti-IA e pela régua de lastro.

## A RÉGUA DE LASTRO (lê antes dos ângulos)

Dois destes ângulos invertem a dor ou contam uma história: o Patinho Feio e o
Plot Twist. Eles só valem com VERDADE REAL. A inversão precisa de lastro: dizer
que uma condição do avatar é vantagem só entra no gancho se o PORQUÊ for
verdadeiro e do perfil do dono. A história só entra se aconteceu de verdade.

Reprova na hora:
- inversão sem prova (o "porque X" que ninguém sustenta)
- choque vazio, sem o lastro que o justifica
- história que não aconteceu, montada só pra prender o clique

O sexto, a Frase do cliente, tem a régua mais simples de todas: a frase foi dita
ou escrita por cliente de verdade, ou não entra (seção 6).

A régua zero-inventado da skill manda aqui igual manda no resto. Todo dado, toda
prova, toda virada sai do material do dono, ou sai marcada `[A CONFIRMAR]`. Um
gancho que precisa de um fato que o dono não tem não vira peça: vira pergunta pro
dono. Choque que atropela a verdade não é ângulo campeão, é passivo.

E o filtro de tom continua de pé: nada de promessa de renda mágica nem gatilho
que manipula. Os exemplos abaixo são todos honestos e ancorados na Renata.

---

## Avatar de referência dos exemplos: Renata

Studio Base 40, fitness pra mulheres de 40 a 55 anos. Dor-mãe do avatar dela:
"eu começo e paro". Método dela: Protocolo Base 40. Os exemplos abaixo saem daí,
e cada um só vale se o fato que ele usa for real no material da Renata.

---

## 1. Falar sem dizer (camuflagem do gancho)

**O que faz:** reformula um gancho que já funciona com camuflagem, sem entregar a
promessa óbvia. O gancho continua vendendo a mesma coisa, mas foge do padrão de
frase que o leilão já saturou. O leitor precisa de meio segundo a mais pra
entender, e é esse meio segundo que segura o olho.

**Quando usar:** quando o ângulo direto ("emagreça depois dos 40") está caro
porque todo concorrente escreve igual. A camuflagem sai do padrão e limpa o leilão.

**Exemplo (Renata):** em vez de "Volte a treinar depois dos 40", o gancho vira:
"Não comece esse treino de segunda se você não quiser voltar a caber na roupa de
três anos atrás." A promessa está lá, camuflada.

**Régua de lastro:** a camuflagem esconde a promessa, nunca inventa uma nova. O
resultado prometido no fundo do gancho tem que ser o que o Protocolo Base 40
entrega de verdade. Camuflar não libera exagerar.

## 2. Segmentação reversa (segmentação dentro do criativo)

**O que faz:** o próprio anúncio filtra o público, EXCLUINDO quem não é o avatar.
Em vez de mirar por interesse caro no gerenciador, a peça diz pra quem não é pra
parar de ler. Quem fica é quem se identifica, e o algoritmo aprende com quem
reagiu.

**Quando usar:** quando o público aberto traz clique de gente errada, ou quando
você quer o avatar exato sem pagar o preço da segmentação forçada por interesse.

**Exemplo (Renata):** "Se você tem 20 anos e nunca parou um treino no meio, pode
fechar esse anúncio. Isso aqui é pra quem já começou e parou umas cinco vezes
depois dos 40." Fala direto com a dor "eu começo e paro".

**Régua de lastro:** o corte exclui de verdade, não humilha ninguém. Filtra por
identificação com a dor real do avatar, sem debochar de quem fica de fora.

## 3. Storytelling com plot twist

**O que faz:** gancho, tensão, e uma resolução que surpreende e conecta no
produto. O twist reordena o que o leitor achava que a história ia dizer, e a
virada é a ponte pro método.

**Quando usar:** quando o avatar já ouviu todo argumento racional e não reage
mais. A história entra por baixo da defesa que o argumento não passa.

**Exemplo (Renata):** "Ela desmarcou a matrícula três vezes. Na quarta, não
apareceu na aula, apareceu pedindo pra pagar o ano inteiro adiantado. O que mudou
não foi a força de vontade dela." O twist puxa pro Protocolo Base 40.

**Régua de lastro (dura):** a história TEM que ter acontecido. Se a Renata não
tem essa aluna, esse gancho não existe. História montada pra prender clique
reprova, mesmo bem escrita. Verdade real ou não vai. O que mudou de fato
("não foi a força de vontade") só entra se for o que o método faz de verdade.

## 4. O Patinho Feio (inverter a dor em vantagem)

**O que faz:** pega a dor que o avatar carrega como maldição e mostra ela como
vantagem. A estrutura: reconhece a dor funda, revela a inversão, prova a inversão
com lógica ou dado, mostra o resultado ao contrário do esperado, e fecha no
alívio de quem carregava aquilo à toa.

**Quando usar:** quando a dor do avatar é uma crença que emperra a compra ("já é
tarde", "meu corpo não responde mais"). Inverter a crença abre a porta que o
argumento direto não abre.

**Exemplo (Renata):** "Começar aos 48 é vantagem sobre quem começou aos 25." E aí
o porquê: mulher que treina depois dos 40 responde ao estímulo de força mais
rápido porque parte de uma base menos condicionada, e ganha densidade óssea numa
janela em que isso importa mais. (Isso SÓ entra no gancho se for real e a
Renata sustentar o dado.)

**Régua de lastro (dura, é onde o ângulo mais escorrega):** a inversão só vale com
o PORQUÊ real. "Ser mais velha é vantagem PORQUE X" só entra se o X for
real e do perfil da Renata. Inversão sem prova, ou "porque" inventado pra soar
esperto, REPROVA. Choque de inverter a dor sem lastro é passivo, não é ângulo.
Sem o dado na mão da dona, o gancho vira `[A CONFIRMAR]` e para ali.

## 5. Trends virais (gancho nativo do feed)

**O que faz:** usa o formato ou o gancho de uma trend que já provou engajar no
orgânico, aplicado no criativo pago. O anúncio parece conteúdo nativo do feed, não
propaganda, e o custo de atenção cai porque o público consome sem a guarda de
"isso é anúncio".

**Quando usar:** quando existe uma trend viva que casa com o avatar. Trend fria ou
forçada não engaja, e trend fora do perfil queima a marca.

**Os 3 jeitos de levar um viral pro pago, do menor pro maior risco.** O viral do
orgânico já passou no teste mais difícil, que é segurar atenção sem verba.

1. O roteiro inteiro do viral, com o fim trocado pelo CTA do dono (vale quando o
   viral é do próprio dono ou quando a estrutura é genérica o bastante pra ser
   reescrita com fala dele).
2. Só o formato, com roteiro novo.
3. Só o jeito de abrir dos primeiros 5 a 10 segundos (enquadramento, ação,
   ritmo), regravado pelo dono, na frente de um corpo que já vende (é um
   microlead, ver `playbook-video-ads.md`, seção 4). Vídeo de terceiro nunca
   entra no anúncio do dono.

**Onde procurar.** Busque formato também FORA do nicho (conta grande que prende
atenção com qualquer assunto): o concorrente do nicho só devolve o que o mercado
já satura. Pesquise na rede onde o comprador está, e a rede muda com a idade do
avatar. O caminho de volta vale igual: o anúncio vencedor sobe no perfil do dono
com o CTA trocado.

**Conferência:** a peça de trend declara `viral: <link> · jeito: 1, 2 ou 3 ·
frases literais de terceiro na peça: 0`. Roteiro inteiro de viral alheio só
passa com a fala reescrita na voz do dono.

**Exemplo (Renata):** pega o formato de "coisas que eu faria diferente se
recomeçasse" que está rodando no nicho fitness e aplica: "3 coisas que eu diria
pra mim aos 40, antes de começar e parar de novo." Formato emprestado, dor da
Renata dentro.

**Régua de lastro:** a trend é o formato, o conteúdo é real. O que a peça
diz dentro da trend segue a régua zero-inventado. Emprestar o formato não libera
copiar uma marca alheia nem prometer o que o método não faz.

## 6. Frase do cliente (a fala real como gancho)

**O que faz:** usa como gancho a frase que o cliente escreve ou fala quando
descreve o problema, com as palavras dele, sem polir. Quem lê reconhece a
própria voz antes de perceber que é anúncio. A frase abre; o corpo fecha com o
mecanismo do dono pelo nome, porque a mesma frase qualquer concorrente do nicho
também ouve dos clientes dele.

**De onde vem:** só da lista `conferencia/frases-do-cliente.txt` do Passo 1, com
origem e contagem. Comece pela frase que mais se repete nas fontes. A frase entra
sem nome e sem detalhe que identifique quem disse; frase de uma pessoa só, com
cena ou detalhe dela, segue a regra de autorização do material do dono.

**Quando usar:** quando o dono tem conversas, comentários ou transcrições de
cliente e o lote quer saber se a fala do público prende mais que o gancho escrito
por ele. Se ela custa menos no seu público é premissa a testar com o seu dado,
nunca promessa.

**Exemplo (Renata):** se as mensagens das alunas trazem a dor-mãe do avatar com
as mesmas palavras, "eu começo e paro", e ela fica no topo da contagem, o gancho
é a frase inteira, entre aspas e sem nome, e o sub diz pra quem é: "Pra quem já
recomeçou o treino mais vezes do que gostaria." Sem essas mensagens na lista, o
exemplo não vale.

**O teste:** a mesma arte roda com 2 a 3 frases da lista e só o texto muda
(`metodo-4-campos.md`: trocar só o texto é o teste mais barato quando a peça já
vende), dentro do plano de teste do lote, com objetivo de venda. Frase que só
junta clique não ganha a rodada.

**Régua de lastro (dura):** frase escrita pela IA ou pelo dono no lugar do
cliente fica na lista como `HIPÓTESE` e vira pergunta pro dono ("algum cliente
já te disse algo parecido?"); sem a resposta, este ângulo sai do lote. Polir a
frase também tira o lastro: dá pra cortar o começo ou o fim, nunca trocar a
palavra do cliente por uma mais bonita.

---

## Como o ângulo entra no lote (não muda o fluxo)

- Cada peça é uma combinação distinta (persona, curiosidade, dor), com UMA dor. O
  ângulo escolhe como essa dor vira gancho.
- No lote de 4, dá pra testar ângulos diferentes pra achar o que fala com o avatar.
- Todo gancho, de qualquer ângulo, passa pelo lint anti-IA e pela régua de lastro
  antes de virar peça. O ângulo não é atalho pra fugir do gate.
- Patinho Feio e Plot Twist são os que mais reprovam por lastro. Na dúvida sobre
  a verdade da inversão ou da história, o gancho vira pergunta pro dono, não peça.
- Frase do cliente nasce da lista do Passo 1: sem frase real com origem, o
  ângulo fica fora do lote e os outros cinco seguem.
