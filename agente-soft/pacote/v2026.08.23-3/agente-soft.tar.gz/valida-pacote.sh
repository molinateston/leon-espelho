#!/usr/bin/env bash
# valida-pacote.sh — portao obrigatorio antes de publicar QUALQUER pacote da frota.
#
# POR QUE EXISTE (14/08/2026): a reestruturacao de 12/08 publicou pacote sem scripts/
# e o update propagou a ausencia: clientes perderam backup-diario, health-check e o
# PROPRIO atualizador. A ferida matou o medico — maquinas congeladas sem socorro
# automatico, descobertas dias depois por acaso. O publicador antigo tinha travas e
# foi aposentado junto com elas. Esta aqui e a trava que volta, standalone: um pacote
# que saia sem as pecas vitais NAO PUBLICA, nao importa quem empacotou nem como.
#
# Uso:  bash valida-pacote.sh pacote/vAAAA.MM.DD-N/agente-soft.tar.gz
#       exit 0 = pode publicar · exit 1 = pacote capenga, NAO publique
set -u
TAR="${1:-}"
[ -f "$TAR" ] || { echo "PARE: passe o caminho do tarball"; exit 1; }

# As pecas sem as quais o cliente fica sem rede de seguranca ou sem motor.
# Tirar item daqui exige decisao consciente do dono, nunca conveniencia de empacote.
VITAIS="
./bridge.cjs
./update.sh
./bootstrap.sh
./healthcheck.sh
./rollback.sh
./scripts/backup-diario.sh
./scripts/health-check.sh
./scripts/update-verdict.sh
./agente-update.timer
./agente-health.timer
./VERSAO
./.pacote.json
./doutrina-nucleo/NUCLEO-LEON.md
./doutrina-nucleo/_MOTOR-CLAUDE.md
./doutrina-nucleo/_MOTOR-CODEX.md
"

LISTA="$(tar tzf "$TAR" 2>/dev/null)" || { echo "PARE: tarball ilegivel"; exit 1; }
FALTA=""
for v in $VITAIS; do
  echo "$LISTA" | grep -qx "$v" || FALTA="$FALTA $v"
done
if [ -n "$FALTA" ]; then
  echo "PARE: pacote SEM peca vital —$FALTA"
  echo "Publicar isto amputa a frota de novo (foi exatamente o acidente de 12/08)."
  exit 1
fi

# segredo nunca viaja no pacote
if tar xzf "$TAR" -O 2>/dev/null | grep -qE "sk-ant-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{32,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}|AIza[0-9A-Za-z_-]{30,}|BEGIN [A-Z ]*PRIVATE KEY"; then
  echo "PARE: credencial dentro do pacote"; exit 1
fi

# o codigo tem que ser sao. A extensao .cjs no temporario NAO e detalhe: sem ela o node
# trata o arquivo como outro tipo de modulo e reprova bridge PERFEITO — aconteceu na
# primeira rodada desta trava, acusando falso quebrado o pacote v2026.08.14-2 que estava
# integro. Trava que grita a toa e trava que alguem irritado apaga.
TMPB="$(mktemp --suffix=.cjs)"; trap 'rm -f "$TMPB"' EXIT
tar xzf "$TAR" -O ./bridge.cjs > "$TMPB" 2>/dev/null
node --check "$TMPB" >/dev/null 2>&1 || { echo "PARE: bridge.cjs do pacote nao passa no node --check"; exit 1; }

echo "OK: pacote integro ($(echo "$LISTA" | wc -l) arquivos, pecas vitais completas, sem credencial, bridge valido)"
