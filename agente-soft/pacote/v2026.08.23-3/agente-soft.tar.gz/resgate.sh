#!/usr/bin/env bash
# resgate.sh — repara uma instalacao ferida do agente e a migra pro fluxo de pacote.
#
# POR QUE EXISTE (14/08/2026): a reestruturacao de 12/08 tirou arquivos da raiz do repo.
# Instalacao antiga (feita por git clone) atualizava por git pull, e o pull APAGOU da
# maquina do cliente o que saiu do repo: scripts/ inteiro, com backup-diario.sh,
# health-check.sh e o proprio atualizador. A ferida mata o medico: sem atualizador,
# o conserto publicado depois nunca chega sozinho. Este script e o empurrao manual.
#
# O que ele faz, nesta ordem:
#   1. Baixa o pacote ATUAL publicado (VERSAO + tarball + sha256 conferido).
#   2. Troca a pasta do agente pela do pacote, guardando a antiga em .anterior.
#      Estado local que morar dentro dela (.env, data/) e preservado por copia.
#   3. Religa a rede de seguranca: cron antigo volta a achar os scripts; se a
#      maquina usa timers do systemd, recarrega.
#   4. Roda UM backup na hora, pra fechar o buraco dos dias parados.
#
# Uso (na maquina do cliente, como o usuario do agente):
#   bash resgate.sh            (usa $HOME/agente-soft)
#   bash resgate.sh /caminho   (instalacao fora do padrao)
set -u

# FONTE DA VERSAO PUBLICADA (20/08/2026): a central, nao mais o raw do GitHub.
# O repo molinateston/agente-soft virou PRIVADO e o raw passou a responder 404 pra
# todo mundo — este resgate nascia morto no primeiro passo, justamente na hora em
# que o cliente mais precisava dele. A central serve o mesmo VERSAO e o mesmo
# pacote, sem exigir licenca (a linha artesanal nao tem licenca).
RAW="${AGENTE_SOFT_BASE:-https://licenca.leonardomolina.com.br/agente-soft}"
REPO_DIR="${1:-$HOME/agente-soft}"
diga(){ printf '%s\n' "$*"; }

diga "== Resgate do agente =="
[ -d "$REPO_DIR" ] || { diga "PARE: $REPO_DIR nao existe. Passe o caminho da instalacao."; exit 1; }

# 1) versao publicada e download conferido
PUB="$(curl -fsSL --max-time 20 "$RAW/VERSAO" | tr -d '[:space:]')"
[ -n "$PUB" ] || { diga "PARE: nao consegui ler a VERSAO publicada (sem internet?)"; exit 1; }
diga "   versao publicada: $PUB"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
curl -fsSL --max-time 120 "$RAW/pacote/$PUB/agente-soft.tar.gz" -o "$TMP/p.tar.gz" \
  || { diga "PARE: download do pacote falhou"; exit 1; }
SHA_PUB="$(curl -fsSL --max-time 20 "$RAW/pacote/$PUB/agente-soft.tar.gz.sha256" | awk '{print $1}')"
SHA_LOC="$(sha256sum "$TMP/p.tar.gz" | awk '{print $1}')"
[ "$SHA_PUB" = "$SHA_LOC" ] || { diga "PARE: sha256 nao bate — download corrompido ou adulterado"; exit 1; }
mkdir -p "$TMP/novo" && tar -xzf "$TMP/p.tar.gz" -C "$TMP/novo" || { diga "PARE: tarball invalido"; exit 1; }
[ -f "$TMP/novo/update.sh" ] && [ -f "$TMP/novo/scripts/backup-diario.sh" ] \
  || { diga "PARE: o pacote baixado esta INCOMPLETO — nao aplico pacote capenga por cima de ferida"; exit 1; }

# 2) preserva estado local que more dentro da pasta do codigo, e troca
for f in .env data brain sessions.json topics.json .pacote-local.json; do
  [ -e "$REPO_DIR/$f" ] && cp -a "$REPO_DIR/$f" "$TMP/novo/" 2>/dev/null
done
rm -rf "$REPO_DIR.anterior"
mv "$REPO_DIR" "$REPO_DIR.anterior"
mv "$TMP/novo" "$REPO_DIR"
printf '%s\n' "$PUB" > "$REPO_DIR/VERSAO"
chmod +x "$REPO_DIR"/*.sh "$REPO_DIR/scripts/"*.sh 2>/dev/null
diga "   pasta trocada (a antiga ficou em $REPO_DIR.anterior)"

# 3) religa a rede de seguranca sem duplicar: cron antigo volta a funcionar sozinho
#    porque os caminhos existem de novo; timer do systemd so recarrega se ja estava la.
if systemctl --user list-unit-files 2>/dev/null | grep -q "agente-update.timer"; then
  systemctl --user daemon-reload 2>/dev/null
  systemctl --user restart agente-update.timer agente-health.timer 2>/dev/null
  diga "   timers do systemd recarregados"
else
  diga "   sem timers systemd nesta maquina — o cron existente volta a achar os scripts"
fi

# 4) um backup agora, pra fechar o buraco dos dias sem rede
if bash "$REPO_DIR/scripts/backup-diario.sh" >/dev/null 2>&1; then
  diga "   backup rodado agora: OK"
else
  diga "   AVISO: o backup manual falhou — rode 'bash $REPO_DIR/scripts/backup-diario.sh' e olhe o erro"
fi

diga ""
diga "✅ Resgate concluido na versao $PUB. A partir de agora o update automatico volta a rodar sozinho."
diga "   Se algo estranhar, a pasta antiga inteira esta em $REPO_DIR.anterior"
